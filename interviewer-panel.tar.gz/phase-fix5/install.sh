#!/bin/bash
echo "═══════════════════════════════════════════"
echo "  INOVIT — Interviewer Panel Upgrade"
echo "═══════════════════════════════════════════"

DIR="$(cd "$(dirname "$0")" && pwd)"
cd /opt/inovit-recruitment

echo "📝 [1/2] Replacing Interviews page with full Interviewer Panel..."
cp "$DIR/Interviews.jsx" frontend/src/pages/

echo "🔨 [2/2] Building frontend + restarting..."
cd frontend && npm run build
pm2 restart all

echo ""
echo "═══════════════════════════════════════════"
echo "  ✅ Interviewer Panel INSTALLED!"
echo "═══════════════════════════════════════════"
echo ""
echo "Features:"
echo "  • Today / Upcoming / Completed tabs"
echo "  • Candidate profile preview (popup)"
echo "  • Quick Score button (Poor/Avg/Good/Excellent)"
echo "  • No-Show button (max 2, then Unreachable)"
echo "  • Reschedule button (with reason)"
echo "  • Join meeting link button"
echo "  • Shows: time, name, qualification, experience,"
echo "    phone, city, interviewer, type (virtual/physical)"
echo "  • Color-coded: orange=today, blue=upcoming,"
echo "    red=past/overdue, green=scored"
echo "  • All times in IST"
echo ""
pm2 status
