#!/bin/bash
echo "Quick Fix: Grouped statuses + Logo cache bust"
cd /opt/inovit-recruitment

# 1. Fix logo - add cache-busting version param
echo "🎨 [1/2] Fixing logo references with cache bust..."
node -e "
const fs = require('fs');

// Fix Layout sidebar logo
const layout = 'frontend/src/components/layout/Layout.jsx';
if (fs.existsSync(layout)) {
  let c = fs.readFileSync(layout, 'utf8');
  c = c.replace(/\/logo-small\.png/g, '/logo-small.png?v=2');
  c = c.replace(/\/logo-medium\.png/g, '/logo-medium.png?v=2');
  fs.writeFileSync(layout, c);
  console.log('  Layout logo cache-busted');
}

// Fix Login
const login = 'frontend/src/pages/Login.jsx';
if (fs.existsSync(login)) {
  let c = fs.readFileSync(login, 'utf8');
  c = c.replace(/\/logo-medium\.png/g, '/logo-medium.png?v=2');
  fs.writeFileSync(login, c);
  console.log('  Login logo cache-busted');
}

// Fix WalkIn
const walkin = 'frontend/src/pages/WalkInRegister.jsx';
if (fs.existsSync(walkin)) {
  let c = fs.readFileSync(walkin, 'utf8');
  c = c.replace(/\/logo-medium\.png/g, '/logo-medium.png?v=2');
  fs.writeFileSync(walkin, c);
  console.log('  WalkIn logo cache-busted');
}

// Fix DocumentUpload
const docup = 'frontend/src/pages/DocumentUpload.jsx';
if (fs.existsSync(docup)) {
  let c = fs.readFileSync(docup, 'utf8');
  c = c.replace(/\/logo-medium\.png/g, '/logo-medium.png?v=2');
  fs.writeFileSync(docup, c);
  console.log('  DocUpload logo cache-busted');
}

// Fix StatusTracker
const status = 'frontend/src/pages/StatusTracker.jsx';
if (fs.existsSync(status)) {
  let c = fs.readFileSync(status, 'utf8');
  c = c.replace(/\/logo-medium\.png/g, '/logo-medium.png?v=2');
  fs.writeFileSync(status, c);
  console.log('  StatusTracker logo cache-busted');
}
"

# Verify logo files exist in public
echo "  Checking logo files..."
ls -la frontend/public/logo*.png 2>/dev/null || echo "  WARNING: Logo files missing in public/"

# 2. Fix Candidates status dropdown - grouped
echo "📝 [2/2] Updating Candidates.jsx with grouped status dropdown..."
node -e "
const fs = require('fs');
const file = 'frontend/src/pages/Candidates.jsx';
let c = fs.readFileSync(file, 'utf8');

// Replace the status filter dropdown with optgroup version
const oldDropdown = '<select value={filters.status} onChange={e=>setFilters(f=>({...f,status:e.target.value}))} className=\"input-field w-auto text-sm\"><option value=\"\">All Status</option>{Object.keys(statusColors).map(s=><option key={s} value={s}>{s.replace(/_/g,\" \")}</option>)}</select>';

const newDropdown = \`<select value={filters.status} onChange={e=>setFilters(f=>({...f,status:e.target.value}))} className=\"input-field w-auto text-sm\">
                <option value=\"\">All Status</option>
                <optgroup label=\"── New / Registration ──\">
                  <option value=\"New\">New</option>
                  <option value=\"Walk_In_Registered\">Walk-In Registered</option>
                </optgroup>
                <optgroup label=\"── Outreach ──\">
                  <option value=\"Contacted\">Contacted</option>
                  <option value=\"Interested\">Interested</option>
                  <option value=\"Not_Interested\">Not Interested</option>
                  <option value=\"WhatsApp_Failed\">WhatsApp Failed</option>
                  <option value=\"Unreachable\">Unreachable</option>
                </optgroup>
                <optgroup label=\"── Screening ──\">
                  <option value=\"Screening\">Screening</option>
                  <option value=\"Screened\">Screened</option>
                  <option value=\"Portal_Applied\">Portal Applied</option>
                </optgroup>
                <optgroup label=\"── Interview ──\">
                  <option value=\"Interview_Scheduled\">Interview Scheduled</option>
                  <option value=\"Interview_Pending_Technical\">Technical Pending</option>
                  <option value=\"Interview_Done\">Interview Done</option>
                </optgroup>
                <optgroup label=\"── Selection ──\">
                  <option value=\"Selected\">Selected</option>
                  <option value=\"Rejected\">Rejected</option>
                  <option value=\"On_Hold\">On Hold</option>
                  <option value=\"Waitlisted\">Waitlisted</option>
                </optgroup>
                <optgroup label=\"── Offer ──\">
                  <option value=\"Offered\">Offered</option>
                  <option value=\"Offer_Accepted\">Offer Accepted</option>
                  <option value=\"Offer_Declined\">Offer Declined</option>
                </optgroup>
                <optgroup label=\"── Onboarding ──\">
                  <option value=\"Onboarding\">Onboarding</option>
                </optgroup>
                <optgroup label=\"── Training & Deploy ──\">
                  <option value=\"Training\">Training</option>
                  <option value=\"Training_Completed\">Training Completed</option>
                  <option value=\"Training_Failed\">Training Failed</option>
                  <option value=\"Deployed\">Deployed</option>
                </optgroup>
                <optgroup label=\"── Other ──\">
                  <option value=\"Blacklisted\">Blacklisted</option>
                  <option value=\"Archived\">Archived</option>
                </optgroup>
              </select>\`;

if (c.includes('Object.keys(statusColors).map')) {
  c = c.replace(oldDropdown, newDropdown);
  fs.writeFileSync(file, c);
  console.log('  Status dropdown grouped by lifecycle stage');
} else {
  console.log('  Could not find exact dropdown pattern — trying alternate');
  // Try a more flexible replacement
  c = c.replace(
    /\{Object\.keys\(statusColors\)\.map\(s=><option key=\{s\} value=\{s\}>\{s\.replace\(\/_\/g,' '\)\}<\/option>\)\}/,
    \`<optgroup label=\"── New / Registration ──\">
                  <option value=\"New\">New</option>
                  <option value=\"Walk_In_Registered\">Walk-In Registered</option>
                </optgroup>
                <optgroup label=\"── Outreach ──\">
                  <option value=\"Contacted\">Contacted</option>
                  <option value=\"Interested\">Interested</option>
                  <option value=\"Not_Interested\">Not Interested</option>
                  <option value=\"WhatsApp_Failed\">WhatsApp Failed</option>
                  <option value=\"Unreachable\">Unreachable</option>
                </optgroup>
                <optgroup label=\"── Screening ──\">
                  <option value=\"Screening\">Screening</option>
                  <option value=\"Screened\">Screened</option>
                  <option value=\"Portal_Applied\">Portal Applied</option>
                </optgroup>
                <optgroup label=\"── Interview ──\">
                  <option value=\"Interview_Scheduled\">Interview Scheduled</option>
                  <option value=\"Interview_Pending_Technical\">Technical Pending</option>
                  <option value=\"Interview_Done\">Interview Done</option>
                </optgroup>
                <optgroup label=\"── Selection ──\">
                  <option value=\"Selected\">Selected</option>
                  <option value=\"Rejected\">Rejected</option>
                  <option value=\"On_Hold\">On Hold</option>
                  <option value=\"Waitlisted\">Waitlisted</option>
                </optgroup>
                <optgroup label=\"── Offer ──\">
                  <option value=\"Offered\">Offered</option>
                  <option value=\"Offer_Accepted\">Offer Accepted</option>
                  <option value=\"Offer_Declined\">Offer Declined</option>
                </optgroup>
                <optgroup label=\"── Onboarding ──\">
                  <option value=\"Onboarding\">Onboarding</option>
                </optgroup>
                <optgroup label=\"── Training & Deploy ──\">
                  <option value=\"Training\">Training</option>
                  <option value=\"Training_Completed\">Training Completed</option>
                  <option value=\"Training_Failed\">Training Failed</option>
                  <option value=\"Deployed\">Deployed</option>
                </optgroup>
                <optgroup label=\"── Other ──\">
                  <option value=\"Blacklisted\">Blacklisted</option>
                  <option value=\"Archived\">Archived</option>
                </optgroup>\`
  );
  fs.writeFileSync(file, c);
  console.log('  Status dropdown grouped (alternate method)');
}
"

echo "🔨 Building..."
cd frontend && npm run build
pm2 restart all

echo ""
echo "✅ Fixed!"
echo "  • Status dropdown now grouped by lifecycle stage"
echo "  • Logo cache-busted (add ?v=2 to force reload)"
echo ""
echo "If logo still doesn't show, clear browser cache or hard refresh (Ctrl+Shift+R)"
pm2 status
