#!/bin/bash
echo "Fixing import fields..."

DIR="$(cd "$(dirname "$0")" && pwd)"
cd /opt/inovit-recruitment

# Update frontend
cp "$DIR/ImportData.jsx" frontend/src/pages/

# Update backend system fields — replace the systemFields array
node -e "
const fs = require('fs');
const file = 'backend/src/controllers/importController.js';
let c = fs.readFileSync(file, 'utf8');

const oldFields = c.match(/const systemFields = \[[\s\S]*?\];/);
if (oldFields) {
  c = c.replace(oldFields[0], \`const systemFields = [
      { key: 'fullName', label: 'Full Name', required: true },
      { key: 'phone', label: 'Phone / WhatsApp Number', required: true },
      { key: 'externalCode', label: 'External ID / Unique Code', required: false },
      { key: 'alternatePhone', label: 'Alternate Phone', required: false },
      { key: 'email', label: 'Email', required: false },
      { key: 'qualification', label: 'Qualification', required: false },
      { key: 'experienceYears', label: 'Experience (Years)', required: false },
      { key: 'currentCity', label: 'Current City', required: false },
      { key: 'currentState', label: 'Current State', required: false },
      { key: 'preferredCity', label: 'Preferred Location / City', required: false },
      { key: 'dateOfBirth', label: 'Date of Birth', required: false },
      { key: 'gender', label: 'Gender', required: false },
      { key: 'fatherName', label: 'Father Name', required: false },
    ];\`);
  fs.writeFileSync(file, c);
  console.log('System fields updated');
} else { console.log('Could not find systemFields'); }
"

# Also update the process function to handle preferredCity as text (not ObjectId ref)
node -e "
const fs = require('fs');
const file = 'backend/src/controllers/importController.js';
let c = fs.readFileSync(file, 'utf8');

// Replace homeLocation block with simpler currentLocation + preferredCity
c = c.replace(
  /homeLocation: \{[\s\S]*?\},\n\s*currentLocation: \{[\s\S]*?\},/,
  \`currentLocation: {
            city: mapped.currentCity || '',
            state: mapped.currentState || '',
          },
          preferredCity: mapped.preferredCity || undefined,\`
);

fs.writeFileSync(file, c);
console.log('Process function updated');
"

# Add preferredCity field to Candidate model if not present
node -e "
const fs = require('fs');
const file = 'backend/src/models/Candidate.js';
let c = fs.readFileSync(file, 'utf8');
if (!c.includes('preferredCity')) {
  c = c.replace(
    'preferredLocation: { type: mongoose.Schema.Types.ObjectId',
    'preferredCity: { type: String, trim: true }, // Free text preferred city from import\n  preferredLocation: { type: mongoose.Schema.Types.ObjectId'
  );
  fs.writeFileSync(file, c);
  console.log('Added preferredCity to model');
} else { console.log('preferredCity already exists'); }
"

# Build and restart
cd frontend && npm run build
pm2 restart all

echo ""
echo "✅ Import fields fixed!"
echo ""
echo "Import mapping now shows:"
echo "  • Full Name *"
echo "  • Phone / WhatsApp Number *"
echo "  • External ID / Unique Code"
echo "  • Alternate Phone"
echo "  • Email"
echo "  • Qualification"
echo "  • Experience (Years)"
echo "  • Current City"
echo "  • Current State"
echo "  • Preferred Location / City"
echo "  • Date of Birth"
echo "  • Gender"
echo "  • Father Name"
echo ""
echo "Auto-detects: phone, mobile, contact, name, email, etc."
pm2 status
