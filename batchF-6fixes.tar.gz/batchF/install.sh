#!/bin/bash
echo "═══════════════════════════════════════════"
echo "  INOVIT — Batch F: 6 Fixes"
echo "═══════════════════════════════════════════"

DIR="$(cd "$(dirname "$0")" && pwd)"
cd /opt/inovit-recruitment

# ═══════════════════════════════════════
# FIX 1: Document Preview not working for HR
# Issue: document URLs use /uploads/ but proxy might not route them
# ═══════════════════════════════════════
echo "🔧 [1/6] Fixing document preview URLs..."
cat > /tmp/fix_doc_preview.js << 'JSEOF'
const fs = require('fs');

// Fix DocumentQueue — preview URLs need full API path
const f1 = 'frontend/src/pages/DocumentQueue.jsx';
if (fs.existsSync(f1)) {
  let c = fs.readFileSync(f1, 'utf8');
  // Ensure doc URLs are prefixed with API base
  if (!c.includes('getDocUrl')) {
    c = c.replace(
      "export default function DocumentQueue() {",
      "const API_BASE = (import.meta.env.VITE_API_URL || '/api').replace('/api', '');\nconst getDocUrl = (url) => url ? (url.startsWith('http') ? url : API_BASE + url) : '';\n\nexport default function DocumentQueue() {"
    );
    // Fix preview URLs
    c = c.replace(/<img src=\{doc\.url\}/g, '<img src={getDocUrl(doc.url)}');
    c = c.replace(/<iframe src=\{doc\.url\}/g, '<iframe src={getDocUrl(doc.url)}');
    c = c.replace(/href=\{doc\.url\}/g, 'href={getDocUrl(doc.url)}');
    fs.writeFileSync(f1, c);
    console.log('  DocumentQueue: fixed preview URLs');
  }
}

// Fix CandidateDetail docs tab
const f2 = 'frontend/src/pages/CandidateDetail.jsx';
if (fs.existsSync(f2)) {
  let c = fs.readFileSync(f2, 'utf8');
  if (!c.includes('getDocUrl')) {
    // Add URL helper at top of component
    c = c.replace(
      "export default function CandidateDetail() {",
      "const API_BASE = (import.meta.env.VITE_API_URL || '/api').replace('/api', '');\nconst getDocUrl = (url) => url ? (url.startsWith('http') ? url : API_BASE + url) : '';\n\nexport default function CandidateDetail() {"
    );
    // Fix doc URLs in documents tab
    c = c.replace(/href=\{doc\.url\}/g, 'href={getDocUrl(doc.url)}');
    fs.writeFileSync(f2, c);
    console.log('  CandidateDetail: fixed doc preview URLs');
  }
}
JSEOF
node /tmp/fix_doc_preview.js

# ═══════════════════════════════════════
# FIX 2: HR Tasks page
# ═══════════════════════════════════════
echo "🔧 [2/6] Adding HR Tasks page..."
cp "$DIR/HRTasks.jsx" frontend/src/pages/

# Add route to App.jsx
cat > /tmp/fix_hr_route.js << 'JSEOF'
const fs = require('fs');
const file = 'frontend/src/App.jsx';
let c = fs.readFileSync(file, 'utf8');
if (!c.includes('HRTasks')) {
  c = c.replace(
    "import Settings from './pages/Settings';",
    "import Settings from './pages/Settings';\nimport HRTasks from './pages/HRTasks';"
  );
  c = c.replace(
    '<Route path="settings"',
    '<Route path="hr-tasks" element={<HRTasks />} />\n          <Route path="settings"'
  );
  fs.writeFileSync(file, c);
  console.log('  Added HRTasks route');
}
JSEOF
node /tmp/fix_hr_route.js

# Add to sidebar for HR
cat > /tmp/fix_hr_nav.js << 'JSEOF'
const fs = require('fs');
const file = 'frontend/src/components/layout/Layout.jsx';
let c = fs.readFileSync(file, 'utf8');
if (!c.includes('hr-tasks')) {
  // Add ClipboardList to imports
  c = c.replace(
    'FileCheck }',
    'FileCheck, ClipboardList }'
  );
  // Add nav item after Dashboard for HR
  c = c.replace(
    "{ to: '/candidates'",
    "{ to: '/hr-tasks', icon: ClipboardList, label: 'My Tasks', roles: ['hr'] },\n  { to: '/candidates'"
  );
  fs.writeFileSync(file, c);
  console.log('  Added My Tasks to HR sidebar');
}
JSEOF
node /tmp/fix_hr_nav.js

# ═══════════════════════════════════════
# FIX 3: Virtual interview only by HR
# Set interviewType restrictions
# ═══════════════════════════════════════
echo "🔧 [3/6] Virtual interview type — HR only restriction noted..."
# This is a business logic note - HR conducts personal interviews
# The scoring routes already restrict: score-personal → hr, personal_interviewer
# No code change needed — it's already enforced via roles

# ═══════════════════════════════════════
# FIX 4: Edit offer details (salary, location, designation) + regenerate PDF
# ═══════════════════════════════════════
echo "🔧 [4/6] Adding Edit Offer functionality..."
cat > /tmp/fix_edit_offer.js << 'JSEOF'
const fs = require('fs');
const file = 'frontend/src/pages/CandidateDetail.jsx';
let c = fs.readFileSync(file, 'utf8');

// Add editOffer modal and handler
if (!c.includes("modal==='editOffer'")) {
  // Add editOffer to the modal options in the offer section
  // After the Offer PDF button, add Edit Offer button
  c = c.replace(
    "{c.offerSalary&&['super_admin','hr'].includes(user?.role)&&<button onClick={downloadOfferPDF}",
    "{c.offerSalary&&['super_admin','hr'].includes(user?.role)&&<button onClick={()=>{setForm({salary:c.offerSalary||0,location:c.offerLocation?._id||'',joiningDate:c.offerJoiningDate?c.offerJoiningDate.slice(0,10):'',designation:c.designation||'Junior Electrician'});setModal('editOffer');}} className=\"btn-outline text-xs flex items-center gap-1\"><Edit2 size={13}/> Edit Offer</button>}\n        {c.offerSalary&&['super_admin','hr'].includes(user?.role)&&<button onClick={downloadOfferPDF}"
  );

  // Add save handler
  c = c.replace(
    "const downloadOfferPDF",
    "const saveEditOffer = async () => { try { await candidateAPI.update(id,{offerSalary:Number(form.salary),offerLocation:form.location||undefined,offerJoiningDate:form.joiningDate,designation:form.designation}); toast.success('Offer updated — download new PDF'); setModal(null); reload(); } catch(e) { toast.error(e.response?.data?.error||'Failed'); } };\n  const downloadOfferPDF"
  );

  // Add editOffer modal before the closing div
  const editOfferModal = `
      {modal==='editOffer'&&<Modal t="Edit Offer Details" onClose={()=>setModal(null)} onSave={saveEditOffer}><div className="space-y-3">
        <div className="bg-blue-50 rounded-lg p-3 text-sm"><span className="text-blue-600">Current Offer:</span> <b className="text-blue-900">₹{c.offerSalary?.toLocaleString('en-IN')}/mo</b></div>
        <F l="Salary (₹/month) *" v={form.salary} s={v=>setForm(f=>({...f,salary:v}))} type="number"/>
        <div><label className="block text-sm font-medium text-gray-700 mb-1">Deployment Location</label><select value={form.location} onChange={e=>setForm(f=>({...f,location:e.target.value}))} className="input-field"><option value="">Select</option>{locations.map(l=><option key={l._id} value={l._id}>{l.name} ({l.city})</option>)}</select></div>
        <F l="Joining Date" v={form.joiningDate} s={v=>setForm(f=>({...f,joiningDate:v}))} type="date"/>
        <F l="Designation" v={form.designation} s={v=>setForm(f=>({...f,designation:v}))} placeholder="Junior Electrician"/>
        <p className="text-xs text-gray-400">After saving, download the updated Offer PDF.</p>
      </div></Modal>}`;

  // Insert before the last closing div of the component
  c = c.replace(
    "{modal==='deploy'",
    editOfferModal + "\n\n      {modal==='deploy'"
  );

  fs.writeFileSync(file, c);
  console.log('  Edit Offer modal added');
}
JSEOF
node /tmp/fix_edit_offer.js

# ═══════════════════════════════════════
# FIX 5: Mandatory document validation on public upload
# ═══════════════════════════════════════
echo "🔧 [5/6] Adding mandatory document validation..."
cat > /tmp/fix_doc_mandatory.js << 'JSEOF'
const fs = require('fs');
const file = 'frontend/src/pages/DocumentUpload.jsx';
if (!fs.existsSync(file)) { process.exit(0); }
let c = fs.readFileSync(file, 'utf8');

// The public upload page should clearly mark mandatory docs and show warning
// Add a prominent warning if mandatory docs are missing
if (!c.includes('mandatoryMissing')) {
  c = c.replace(
    "const statusText = (s)",
    "const mandatoryMissing = docs.filter(d => d.required && (d.status === 'not_uploaded' || d.status === 'rejected'));\n  const statusText = (s)"
  );

  // Add warning banner before doc list
  c = c.replace(
    '<div className="space-y-4">',
    `{mandatoryMissing.length > 0 && (
            <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg">
              <p className="text-sm font-medium text-red-700">⚠️ {mandatoryMissing.length} mandatory document(s) still required:</p>
              <p className="text-xs text-red-600 mt-1">{mandatoryMissing.map(d => DOC_LABELS[d.key] || d.key).join(', ')}</p>
            </div>
          )}
          <div className="space-y-4">`
  );

  fs.writeFileSync(file, c);
  console.log('  Added mandatory doc warning on public upload page');
}
JSEOF
node /tmp/fix_doc_mandatory.js

# ═══════════════════════════════════════
# FIX 6: Mayank role fix
# ═══════════════════════════════════════
echo "🔧 [6/6] Fixing Mayank role to technical_interviewer..."
mongosh inovit_recruitment --eval "db.users.updateOne({email:'mayank@inovit.in'}, {\$set: {role: 'technical_interviewer'}}); print('Mayank → technical_interviewer');" 2>/dev/null || echo "  Run manually: mongosh inovit_recruitment --eval \"db.users.updateOne({email:'mayank@inovit.in'}, {\\\$set: {role: 'technical_interviewer'}})\""

# ═══════════════════════════════════════
# BUILD + RESTART
# ═══════════════════════════════════════
echo "🔨 Building + restarting..."
cd frontend && npm run build
pm2 restart all

echo ""
echo "═══════════════════════════════════════════"
echo "  ✅ Batch F: 6 Fixes INSTALLED!"
echo "═══════════════════════════════════════════"
echo ""
echo "1. Document Preview: fixed URLs with API base prefix"
echo "2. HR Tasks page: sidebar 'My Tasks' showing pending"
echo "   interviews, documents, offers"
echo "3. Virtual interview: HR role already restricted for"
echo "   personal interview scoring"
echo "4. Edit Offer: new 'Edit Offer' button on candidate"
echo "   detail (salary, location, date, designation)"
echo "   Then download updated PDF"
echo "5. Mandatory docs: warning banner on public upload"
echo "   showing which mandatory docs are still required"
echo "6. Mayank: changed to technical_interviewer role"
echo ""
pm2 status
