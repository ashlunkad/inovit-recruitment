import { useState, useEffect } from 'react';
import { candidateAPI, documentAPI } from '../services/api';
import api from '../services/api';
import { useNavigate } from 'react-router-dom';
import { ClipboardList, Calendar, FileCheck, Briefcase, ChevronRight } from 'lucide-react';

const O = '#E67E22';
const G = '#4A4A4A';
const fmtIST = (d) => d ? new Date(d).toLocaleString('en-IN',{dateStyle:'short',timeStyle:'short',timeZone:'UTC'}) : '-';

export default function HRTasks() {
  const [pendingInterviews, setPendingInterviews] = useState([]);
  const [pendingDocs, setPendingDocs] = useState([]);
  const [pendingOffers, setPendingOffers] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    Promise.all([
      candidateAPI.getAll({ status: ['Interview_Scheduled','Interview_Pending_Technical'], limit: 100, sort: 'interviewScheduled' }),
      api.get('/documents/queue').catch(() => ({ data: { queue: [] } })),
      candidateAPI.getAll({ status: ['Selected'], limit: 100, sort: '-updatedAt' }),
    ]).then(([intRes, docRes, offerRes]) => {
      setPendingInterviews(intRes.data.candidates || []);
      setPendingDocs(docRes.data.queue || []);
      setPendingOffers(offerRes.data.candidates || []);
    }).catch(console.error).finally(() => setLoading(false));
  }, []);

  if (loading) return <div className="flex items-center justify-center h-64"><div className="animate-spin rounded-full h-10 w-10 border-b-2" style={{borderColor:O}}></div></div>;

  const sections = [
    { title: 'Pending Interviews', icon: Calendar, color: '#8B5CF6', items: pendingInterviews, emptyMsg: 'No pending interviews',
      render: (c) => (
        <div key={c._id} className="flex items-center gap-3 p-3 border rounded-lg hover:bg-gray-50 cursor-pointer" onClick={() => navigate('/candidates/'+c._id)}>
          <div className="w-12 text-center"><div className="text-sm font-bold" style={{color:'#8B5CF6'}}>{fmtIST(c.interviewScheduled).split(',')[1]?.trim() || '-'}</div><div className="text-[10px] text-gray-400">{fmtIST(c.interviewScheduled).split(',')[0]}</div></div>
          <div className="flex-1 min-w-0"><div className="font-medium text-sm text-gray-900 truncate">{c.fullName}</div><div className="text-xs text-gray-400">{c.candidateId} • {c.qualification?.replace(/_/g,' ')}</div></div>
          <span className={'text-xs px-2 py-0.5 rounded-full '+(c.status==='Interview_Pending_Technical'?'bg-amber-100 text-amber-700':'bg-purple-100 text-purple-700')}>{c.status==='Interview_Pending_Technical'?'Tech Pending':'Scheduled'}</span>
          <ChevronRight size={14} className="text-gray-300"/>
        </div>
      )},
    { title: 'Pending Document Verification', icon: FileCheck, color: '#22C55E', items: pendingDocs, emptyMsg: 'No pending documents',
      render: (c) => (
        <div key={c._id} className="flex items-center gap-3 p-3 border rounded-lg hover:bg-gray-50 cursor-pointer" onClick={() => navigate('/candidates/'+c._id)}>
          <div className="flex-1 min-w-0"><div className="font-medium text-sm text-gray-900 truncate">{c.fullName}</div><div className="text-xs text-gray-400">{c.candidateId} • {c.phone}</div></div>
          <div className="flex gap-1">
            <span className="text-xs bg-yellow-100 text-yellow-700 px-2 py-0.5 rounded-full">{c.pendingDocs} pending</span>
            <span className="text-xs bg-green-100 text-green-700 px-2 py-0.5 rounded-full">{c.verifiedDocs} verified</span>
          </div>
          <ChevronRight size={14} className="text-gray-300"/>
        </div>
      )},
    { title: 'Pending Offer Letters', icon: Briefcase, color: O, items: pendingOffers, emptyMsg: 'No candidates awaiting offer',
      render: (c) => (
        <div key={c._id} className="flex items-center gap-3 p-3 border rounded-lg hover:bg-gray-50 cursor-pointer" onClick={() => navigate('/candidates/'+c._id)}>
          <div className="flex-1 min-w-0"><div className="font-medium text-sm text-gray-900 truncate">{c.fullName}</div><div className="text-xs text-gray-400">{c.candidateId} • {c.preferredCity||c.currentLocation?.city||'-'}</div></div>
          <span className="text-xs bg-emerald-100 text-emerald-700 px-2 py-0.5 rounded-full">Selected — Needs Offer</span>
          <ChevronRight size={14} className="text-gray-300"/>
        </div>
      )},
  ];

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold" style={{color:G}}>My Tasks</h1>

      {/* Summary cards */}
      <div className="grid grid-cols-3 gap-4">
        {sections.map(s => (
          <div key={s.title} className="bg-white rounded-xl border p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg flex items-center justify-center" style={{backgroundColor:s.color+'20'}}><s.icon size={20} style={{color:s.color}}/></div>
            <div><div className="text-2xl font-bold" style={{color:G}}>{s.items.length}</div><div className="text-xs text-gray-500">{s.title}</div></div>
          </div>
        ))}
      </div>

      {/* Task lists */}
      {sections.map(s => (
        <div key={s.title} className="card !p-4">
          <div className="flex items-center gap-2 mb-3">
            <s.icon size={16} style={{color:s.color}}/>
            <h3 className="font-semibold text-sm" style={{color:G}}>{s.title}</h3>
            <span className="text-xs bg-gray-100 text-gray-600 px-2 py-0.5 rounded-full ml-auto">{s.items.length}</span>
          </div>
          {s.items.length === 0 ? (
            <p className="text-sm text-gray-400 text-center py-4">{s.emptyMsg}</p>
          ) : (
            <div className="space-y-2 max-h-64 overflow-y-auto">
              {s.items.slice(0,20).map(s.render)}
            </div>
          )}
        </div>
      ))}
    </div>
  );
}
