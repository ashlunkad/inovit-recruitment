import { useState, useEffect } from 'react';
import { candidateAPI } from '../services/api';
import api from '../services/api';
import { useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import { Calendar, Clock, Video, MapPin, User, Star, X, Save, Phone, FileText, AlertTriangle, RotateCcw } from 'lucide-react';

const SCORE_COLORS = {1:'bg-red-100 text-red-700 border-red-300',2:'bg-yellow-100 text-yellow-700 border-yellow-300',3:'bg-blue-100 text-blue-700 border-blue-300',4:'bg-green-100 text-green-700 border-green-300'};
const fmtIST = (d,opts) => d ? new Date(d).toLocaleString('en-IN',{...opts,timeZone:'Asia/Kolkata'}) : '-';

export default function Interviews() {
  const [interviews, setInterviews] = useState([]);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState('today');
  const [scoreModal, setScoreModal] = useState(null); // { candidate, type: 'personal'|'technical' }
  const [profileModal, setProfileModal] = useState(null);
  const [rescheduleModal, setRescheduleModal] = useState(null);
  const [scoreForm, setScoreForm] = useState({technical:0,practical:0,communication:0,experience:0,locationAvailability:0,teamLeading:0,notes:'',recommendedLocation:''});
  const [rescheduleForm, setRescheduleForm] = useState({date:'',reason:''});
  const navigate = useNavigate();

  const fetchData = async () => {
    setLoading(true);
    try {
      const statuses = tab==='done'?['Interview_Done']:['Interview_Scheduled','Interview_Pending_Technical'];
      const res = await candidateAPI.getAll({status:statuses,limit:200,sort:tab==='done'?'-updatedAt':'interviewScheduled'});
      let data = res.data.candidates||[];
      if(tab==='today'){const today=new Date().toLocaleDateString('en-CA',{timeZone:'Asia/Kolkata'});data=data.filter(c=>c.interviewScheduled&&new Date(c.interviewScheduled).toLocaleDateString('en-CA',{timeZone:'Asia/Kolkata'})===today);}
      else if(tab==='upcoming'){data=data.filter(c=>c.interviewScheduled&&new Date(c.interviewScheduled)>new Date());}
      setInterviews(data);
    } catch {} finally{setLoading(false);}
  };
  useEffect(()=>{fetchData();},[tab]);

  const openScore = (c, type) => {
    const b = type==='personal'?(c.personalInterviewBreakdown||{}):(c.technicalInterviewBreakdown||{});
    setScoreForm({technical:b.technical||0,practical:b.practical||0,communication:b.communication||0,experience:b.experience||0,locationAvailability:b.locationAvailability||0,teamLeading:b.teamLeading||0,notes:'',recommendedLocation:c.recommendedLocation||''});
    setScoreModal({candidate:c,type});
  };

  const saveScore = async () => {
    try {
      if(scoreModal.type==='personal') await candidateAPI.scorePersonalInterview(scoreModal.candidate._id,scoreForm);
      else await candidateAPI.scoreTechnicalInterview(scoreModal.candidate._id,scoreForm);
      toast.success(`${scoreModal.type==='personal'?'Personal':'Technical'} interview scored for ${scoreModal.candidate.fullName}`);
      setScoreModal(null); fetchData();
    } catch(e){toast.error(e.response?.data?.error||'Failed');}
  };

  const markNoShow = async (c) => {
    if(!confirm('Mark '+c.fullName+' as no-show?'))return;
    try{const count=(c.rescheduleCount||0)+1;await candidateAPI.update(c._id,{status:count>=2?'Unreachable':'Interview_Scheduled',rescheduleCount:count,statusChangeReason:'No-show ('+count+'/2)'});toast.success(c.fullName+' no-show');fetchData();}catch{toast.error('Failed');}
  };

  const openReschedule = (c) => {setRescheduleForm({date:'',reason:''});setRescheduleModal(c);};
  const saveReschedule = async () => {
    if(!rescheduleForm.date){toast.error('Select date');return;}
    try{const dt=new Date(new Date(rescheduleForm.date).getTime()-(5.5*60*60*1000)).toISOString();await candidateAPI.update(rescheduleModal._id,{interviewScheduled:dt,rescheduleCount:(rescheduleModal.rescheduleCount||0)+1,statusChangeReason:'Rescheduled: '+(rescheduleForm.reason||'-')});toast.success('Rescheduled');setRescheduleModal(null);fetchData();}catch{toast.error('Failed');}
  };

  const openProfile = async (c) => {try{const res=await candidateAPI.getOne(c._id);setProfileModal(res.data.candidate);}catch{setProfileModal(c);}};

  const totalScore = (f) => Object.entries(f).filter(([k])=>!['notes','recommendedLocation'].includes(k)).reduce((s,[,v])=>s+Number(v),0);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-gray-900">Interviewer Panel</h1>
        <button onClick={fetchData} className="btn-outline text-sm">Refresh</button>
      </div>

      <div className="flex gap-1 bg-gray-100 p-1 rounded-lg w-fit">
        {[{key:'today',label:'Today',icon:Clock},{key:'upcoming',label:'Upcoming',icon:Calendar},{key:'done',label:'Completed',icon:Star}].map(t=>(
          <button key={t.key} onClick={()=>setTab(t.key)} className={'px-4 py-2 text-sm rounded-md transition flex items-center gap-1.5 '+(tab===t.key?'bg-white text-primary-700 font-medium shadow-sm':'text-gray-500')}><t.icon size={15}/> {t.label}</button>
        ))}
      </div>

      {loading?<div className="flex justify-center py-12"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary-600"></div></div>:
      interviews.length===0?<div className="card text-center py-12 text-gray-400"><Calendar size={48} className="mx-auto mb-3 text-gray-300"/><p>No interviews</p></div>:
      <div className="space-y-3">
        {interviews.map(c => {
          const dt=c.interviewScheduled?new Date(c.interviewScheduled):null;
          const isToday=dt&&dt.toLocaleDateString('en-CA',{timeZone:'Asia/Kolkata'})===new Date().toLocaleDateString('en-CA',{timeZone:'Asia/Kolkata'});
          const hasPersonal=c.personalInterviewScore>0;
          const hasTechnical=c.technicalInterviewScore>0;
          const isFullyScored=hasPersonal&&hasTechnical;

          return (
            <div key={c._id} className={'card !p-4 border-l-4 '+(isFullyScored?'border-l-green-400':hasPersonal?'border-l-amber-400':isToday?'border-l-orange-400':'border-l-blue-400')}>
              <div className="flex flex-col lg:flex-row lg:items-center gap-4">
                <div className="lg:w-28 text-center shrink-0">
                  {dt?<><div className={'text-lg font-bold '+(isToday?'text-orange-600':'text-gray-700')}>{fmtIST(dt,{hour:'2-digit',minute:'2-digit',hour12:true})}</div><div className="text-xs text-gray-400">{isToday?'Today':fmtIST(dt,{day:'numeric',month:'short'})}</div></>:<div className="text-sm text-gray-400">Not set</div>}
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <h3 className="font-semibold text-gray-900">{c.fullName}</h3>
                    <span className="text-xs text-gray-400">{c.candidateId}</span>
                    {c.interviewType==='virtual'?<span className="badge bg-blue-100 text-blue-700 text-xs"><Video size={11} className="inline mr-0.5"/>Virtual</span>:c.interviewType==='physical'?<span className="badge bg-green-100 text-green-700 text-xs"><MapPin size={11} className="inline mr-0.5"/>Physical</span>:null}
                    {hasPersonal&&!hasTechnical&&<span className="badge bg-amber-100 text-amber-700 text-xs">Technical Pending</span>}
                    {isFullyScored&&<span className="badge bg-green-100 text-green-700 text-xs">Fully Scored</span>}
                  </div>
                  <div className="flex flex-wrap gap-3 mt-1 text-xs text-gray-500">
                    <span>{c.qualification?.replace(/_/g,' ')}</span>
                    <span>{c.experienceYears||0}yr</span>
                    <span><Phone size={10} className="inline"/> {c.phone}</span>
                    <span><MapPin size={10} className="inline"/> {c.preferredCity||c.currentLocation?.city||'-'}</span>
                    {c.interviewer?.name&&<span><User size={10} className="inline"/> {c.interviewer.name}</span>}
                  </div>
                </div>

                {/* Scores */}
                {(hasPersonal||hasTechnical)&&<div className="flex gap-2 shrink-0">
                  {hasPersonal&&<div className="text-center px-2 py-1 rounded bg-purple-50"><div className="text-sm font-bold text-purple-700">{c.personalInterviewScore}/24</div><div className="text-[10px] text-purple-500">Personal</div></div>}
                  {hasTechnical&&<div className="text-center px-2 py-1 rounded bg-orange-50"><div className="text-sm font-bold text-orange-700">{c.technicalInterviewScore}/24</div><div className="text-[10px] text-orange-500">Technical</div></div>}
                </div>}

                {/* Actions */}
                <div className="flex items-center gap-1.5 shrink-0 flex-wrap">
                  <button onClick={()=>openProfile(c)} className="btn-outline text-xs py-1.5 px-2"><FileText size={13} className="inline mr-0.5"/>Profile</button>

                  {!hasPersonal&&tab!=='done'&&<button onClick={()=>openScore(c,'personal')} className="bg-purple-600 hover:bg-purple-700 text-white text-xs py-1.5 px-2 rounded-lg"><Star size={13} className="inline mr-0.5"/>Personal</button>}
                  {hasPersonal&&!hasTechnical&&tab!=='done'&&<button onClick={()=>openScore(c,'technical')} className="bg-orange-600 hover:bg-orange-700 text-white text-xs py-1.5 px-2 rounded-lg"><Star size={13} className="inline mr-0.5"/>Technical</button>}

                  {tab!=='done'&&!isFullyScored&&<>
                    <button onClick={()=>markNoShow(c)} className="bg-red-50 text-red-600 text-xs py-1.5 px-2 rounded-lg"><AlertTriangle size={13} className="inline mr-0.5"/>No-Show</button>
                    <button onClick={()=>openReschedule(c)} className="bg-amber-50 text-amber-600 text-xs py-1.5 px-2 rounded-lg"><RotateCcw size={13} className="inline mr-0.5"/>Reschedule</button>
                  </>}
                  {c.interviewLink&&tab!=='done'&&<a href={c.interviewLink} target="_blank" rel="noopener noreferrer" className="bg-blue-600 text-white text-xs py-1.5 px-2 rounded-lg"><Video size={13} className="inline mr-0.5"/>Join</a>}
                </div>
              </div>
            </div>
          );
        })}
      </div>}

      {/* Score Modal */}
      {scoreModal&&<div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4"><div className="bg-white rounded-xl shadow-xl max-w-lg w-full max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between p-5 border-b"><div>
          <h3 className="text-lg font-bold text-gray-900">Score {scoreModal.type==='personal'?'Personal':'Technical'} Interview</h3>
          <p className="text-sm text-gray-500">{scoreModal.candidate.fullName} • {scoreModal.candidate.candidateId}</p>
        </div><button onClick={()=>setScoreModal(null)} className="text-gray-400 hover:text-gray-600"><X size={20}/></button></div>
        <div className="p-5 space-y-4">
          <div className="bg-gray-50 rounded-lg p-3 text-sm grid grid-cols-2 gap-2">
            <div><span className="text-gray-500">Qualification:</span> <b>{scoreModal.candidate.qualification?.replace(/_/g,' ')}</b></div>
            <div><span className="text-gray-500">Experience:</span> <b>{scoreModal.candidate.experienceYears||0} years</b></div>
            <div><span className="text-gray-500">City:</span> <b>{scoreModal.candidate.currentLocation?.city||'-'}</b></div>
            <div><span className="text-gray-500">Preferred:</span> <b>{scoreModal.candidate.preferredCity||scoreModal.candidate.preferredLocation?.name||'-'}</b></div>
          </div>
          {[['technical','Technical Knowledge'],['practical','Practical Skills'],['communication','Communication & Attitude'],['experience','Relevant Experience'],['locationAvailability','Location Willingness'],['teamLeading','Team Leading']].map(([key,label])=>(
            <div key={key}><label className="block text-sm font-medium text-gray-700 mb-2">{label}</label>
              <div className="flex gap-2">{[{v:1,l:'Poor'},{v:2,l:'Average'},{v:3,l:'Good'},{v:4,l:'Excellent'}].map(opt=>(
                <button key={opt.v} type="button" onClick={()=>setScoreForm(f=>({...f,[key]:opt.v}))}
                  className={'flex-1 py-2 px-2 rounded-lg border-2 text-sm font-medium transition '+(scoreForm[key]===opt.v?SCORE_COLORS[opt.v]+' border-current':'bg-gray-50 text-gray-400 border-gray-200 hover:bg-gray-100')}>{opt.l}</button>
              ))}</div></div>
          ))}
          <div className="pt-3 border-t text-center"><span className="text-lg font-bold text-primary-700">Total: {totalScore(scoreForm)}/24</span></div>
          <div><label className="block text-sm font-medium text-gray-700 mb-1">Recommended Location</label><input value={scoreForm.recommendedLocation} onChange={e=>setScoreForm(f=>({...f,recommendedLocation:e.target.value}))} className="input-field" placeholder="e.g., Jaipur instead of Delhi"/></div>
          <div><label className="block text-sm font-medium text-gray-700 mb-1">Notes</label><textarea value={scoreForm.notes} onChange={e=>setScoreForm(f=>({...f,notes:e.target.value}))} className="input-field" rows={3}/></div>
        </div>
        <div className="flex gap-3 justify-end p-5 border-t"><button onClick={()=>setScoreModal(null)} className="btn-outline text-sm">Cancel</button><button onClick={saveScore} className="btn-primary text-sm" disabled={totalScore(scoreForm)===0}><Save size={14} className="inline mr-1"/>Submit</button></div>
      </div></div>}

      {/* Profile Modal */}
      {profileModal&&<div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4"><div className="bg-white rounded-xl shadow-xl max-w-md w-full max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between p-5 border-b"><h3 className="text-lg font-bold">Candidate Profile</h3><button onClick={()=>setProfileModal(null)} className="text-gray-400 hover:text-gray-600"><X size={20}/></button></div>
        <div className="p-5">
          <div className="text-center mb-4"><div className="w-16 h-16 rounded-full bg-primary-100 flex items-center justify-center text-primary-700 font-bold text-2xl mx-auto">{profileModal.fullName?.split(' ').map(n=>n[0]).join('').slice(0,2)}</div><h2 className="text-xl font-bold mt-2">{profileModal.fullName}</h2><p className="text-sm text-gray-500">{profileModal.candidateId}</p></div>
          <dl className="space-y-2 text-sm">{[['Phone',profileModal.phone],['Qualification',profileModal.qualification?.replace(/_/g,' ')],['Experience',(profileModal.experienceYears||0)+' years'],['City',profileModal.currentLocation?.city],['Preferred',profileModal.preferredCity||profileModal.preferredLocation?.name],['Source',profileModal.source],['Agent',profileModal.assignedAgent?.name],['Father',profileModal.fatherName],['External ID',profileModal.externalCode]].filter(([,v])=>v).map(([l,v])=>(<div key={l} className="flex justify-between border-b border-gray-50 pb-1.5"><dt className="text-gray-500">{l}</dt><dd className="font-medium text-gray-800">{v}</dd></div>))}</dl>
        </div>
        <div className="flex gap-3 justify-end p-5 border-t"><button onClick={()=>setProfileModal(null)} className="btn-outline text-sm">Close</button><button onClick={()=>{setProfileModal(null);navigate('/candidates/'+profileModal._id);}} className="btn-primary text-sm">Full Detail</button></div>
      </div></div>}

      {/* Reschedule Modal */}
      {rescheduleModal&&<div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4"><div className="bg-white rounded-xl shadow-xl max-w-sm w-full">
        <div className="flex items-center justify-between p-5 border-b"><h3 className="text-lg font-bold">Reschedule</h3><button onClick={()=>setRescheduleModal(null)} className="text-gray-400 hover:text-gray-600"><X size={20}/></button></div>
        <div className="p-5 space-y-3">
          <p className="text-sm text-gray-600">{rescheduleModal.fullName}</p>
          <div><label className="block text-sm font-medium text-gray-700 mb-1">New Date & Time *</label><input type="datetime-local" value={rescheduleForm.date} onChange={e=>setRescheduleForm(f=>({...f,date:e.target.value}))} className="input-field"/></div>
          <div><label className="block text-sm font-medium text-gray-700 mb-1">Reason</label><input value={rescheduleForm.reason} onChange={e=>setRescheduleForm(f=>({...f,reason:e.target.value}))} className="input-field"/></div>
        </div>
        <div className="flex gap-3 justify-end p-5 border-t"><button onClick={()=>setRescheduleModal(null)} className="btn-outline text-sm">Cancel</button><button onClick={saveReschedule} className="btn-primary text-sm">Reschedule</button></div>
      </div></div>}
    </div>
  );
}
