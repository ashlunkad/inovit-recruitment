#!/bin/bash
echo "═══════════════════════════════════════════════════"
echo "  INOVIT — Batch 3: Dashboard + Status + Panels"
echo "═══════════════════════════════════════════════════"

DIR="$(cd "$(dirname "$0")" && pwd)"
cd /opt/inovit-recruitment

echo "📝 [1/5] Updating Candidates list (status colors + preferredCity + /48 scores)..."
cp "$DIR/Candidates.jsx" frontend/src/pages/

echo "📝 [2/5] Updating Selection Panel (dual scores + location dropdown)..."
cp "$DIR/SelectionPanel.jsx" frontend/src/pages/

echo "📝 [3/5] Updating Interviewer Panel (dual scoring buttons)..."
cp "$DIR/Interviews.jsx" frontend/src/pages/

echo "📝 [4/5] Fixing Dashboard call outcomes rendering..."
node -e "
const fs = require('fs');
const file = 'frontend/src/pages/Dashboard.jsx';
if (!fs.existsSync(file)) { console.log('  Dashboard.jsx not found — skip'); process.exit(0); }
let c = fs.readFileSync(file, 'utf8');

// Add callOutcomes to stats destructuring if not present
if (!c.includes('callOutcomes')) {
  // Find where stats are destructured or rendered
  c = c.replace(
    'recentActivity,',
    'recentActivity, callOutcomes,'
  );

  // Add call outcomes section before recent activity
  c = c.replace(
    '{/* Recent Activity */}',
    \`{/* Call Outcomes Today */}
          {stats?.callOutcomes?.length > 0 && (
            <div className=\"card\">
              <h3 className=\"font-semibold text-gray-800 mb-3\">Call Outcomes Today</h3>
              <div className=\"flex flex-wrap gap-2\">
                {stats.callOutcomes.map(o => (
                  <div key={o._id} className=\"bg-gray-50 rounded-lg px-3 py-2 text-center\">
                    <div className=\"text-lg font-bold text-primary-700\">{o.count}</div>
                    <div className=\"text-xs text-gray-500\">{(o._id || 'Unknown').replace(/_/g, ' ')}</div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Recent Activity */}\`
  );

  fs.writeFileSync(file, c);
  console.log('  Added call outcomes to Dashboard');
} else { console.log('  callOutcomes already in Dashboard'); }
"

echo "🔨 [5/5] Building frontend + restarting..."
cd frontend && npm run build
pm2 restart all

echo ""
echo "═══════════════════════════════════════════════════"
echo "  ✅ Batch 3 INSTALLED!"
echo "═══════════════════════════════════════════════════"
echo ""
echo "Changes:"
echo ""
echo "  CANDIDATES LIST:"
echo "    • All 27 status colors (including Interview_Pending_Technical,"
echo "      Onboarding, Offer_Declined, Waitlisted)"
echo "    • Score column shows total/48 for dual interviews"
echo "    • Location column shows preferredCity || currentCity || location"
echo "    • Export CSV includes Personal/Technical/Total scores"
echo "    • Add Candidate form has preferredCity field"
echo ""
echo "  SELECTION PANEL:"
echo "    • Separate columns: Personal /24 | Technical /24 | Total /48"
echo "    • 'Technical Pending' indicator if Round 2 not done"
echo "    • Location dropdown in Select modal"
echo "    • Sort by personalInterviewScore or technicalInterviewScore"
echo "    • Shows recommendedLocation || preferredCity"
echo ""
echo "  INTERVIEWER PANEL:"
echo "    • TWO score buttons: 'Personal' (purple) + 'Technical' (orange)"
echo "    • 'Personal' visible when not scored yet"
echo "    • 'Technical' visible only after personal is done"
echo "    • 'Technical Pending' badge on cards"
echo "    • 'Fully Scored' badge when both done"
echo "    • Separate score boxes: Personal /24 + Technical /24"
echo "    • Recommended Location field in score modal"
echo "    • Reschedule with IST timezone fix"
echo ""
echo "  DASHBOARD:"
echo "    • Call Outcomes Today section (Connected, No Answer, etc.)"
echo ""
pm2 status
