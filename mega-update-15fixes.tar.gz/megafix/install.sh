#!/bin/bash
echo "═══════════════════════════════════════════════════"
echo "  INOVIT — MEGA UPDATE: 15 Fixes + Logo + Lifecycle"
echo "═══════════════════════════════════════════════════"

DIR="$(cd "$(dirname "$0")" && pwd)"
cd /opt/inovit-recruitment

# ═══════════════════════════════════════
# LOGO SETUP
# ═══════════════════════════════════════
echo "🎨 [1/15] Installing logo files..."
mkdir -p frontend/public
cp "$DIR/logo.png" frontend/public/logo.png
cp "$DIR/logo-small.png" frontend/public/logo-small.png
cp "$DIR/logo-medium.png" frontend/public/logo-medium.png
cp "$DIR/logo-pdf.png" backend/uploads/logo.png 2>/dev/null
mkdir -p backend/uploads
cp "$DIR/logo-pdf.png" backend/uploads/logo.png

# ═══════════════════════════════════════
# FIX #15: Team empty validation
# ═══════════════════════════════════════
echo "🔧 [2/15] Fixing team empty validation..."
node -e "
const fs = require('fs');
const file = 'backend/src/models/User.js';
let c = fs.readFileSync(file, 'utf8');
// Allow empty string for team by changing enum to include null handling
if (c.includes(\"team: { type: String, enum:\")) {
  c = c.replace(
    /team: \{ type: String, enum: \[.*?\]/,
    \"team: { type: String, enum: ['Alpha', 'Beta', 'Gamma', 'Delta', null, '']\"
  );
  fs.writeFileSync(file, c);
  console.log('  Fixed team enum to allow null/empty');
} else if (c.includes(\"team: { type: String\") && !c.includes(\"enum: ['Alpha'\")) {
  // Team might not have enum - check
  console.log('  Team field may not have strict enum');
} else {
  // Try different approach - set team to not required with default null
  c = c.replace(/team: \{[^}]+\}/, \"team: { type: String, default: null }\");
  fs.writeFileSync(file, c);
  console.log('  Set team to allow any value');
}
"

# ═══════════════════════════════════════
# FIX #1: Walk-in candidates not in list
# ═══════════════════════════════════════
echo "🔧 [3/15] Fixing walk-in candidates visibility..."
# Walk_In_Registered is already a valid status - the issue is likely the source enum
node -e "
const fs = require('fs');
const file = 'backend/src/config/constants.js';
let c = fs.readFileSync(file, 'utf8');
// Ensure Walk_In is in SOURCE
if (!c.includes(\"'Walk_In'\")) {
  console.log('  WARNING: Walk_In not in SOURCE enum!');
} else {
  console.log('  Walk_In source OK');
}
// Ensure Walk_In_Registered is in statuses
if (c.includes(\"'Walk_In_Registered'\")) {
  console.log('  Walk_In_Registered status OK');
} else {
  console.log('  WARNING: Walk_In_Registered not in statuses!');
}
"

# The real fix - walk-in controller sets status to Walk_In_Registered
# but the walkin form source might not match. Fix the walk-in source.
node -e "
const fs = require('fs');
const file = 'backend/src/controllers/walkinController.js';
let c = fs.readFileSync(file, 'utf8');
// Make sure walk-in uses 'Walk_In' as source (which IS in the enum)
if (c.includes(\"source: 'Walk_In'\")) {
  console.log('  Walk-in source correctly set to Walk_In');
} else {
  console.log('  Checking walk-in source...');
  // It should already be Walk_In from the original code
}
"

# ═══════════════════════════════════════
# FIX #5: Two interviews (Personal + Technical)
# ═══════════════════════════════════════
echo "🔧 [4/15] Adding dual interview support..."
node -e "
const fs = require('fs');
const file = 'backend/src/models/Candidate.js';
let c = fs.readFileSync(file, 'utf8');

// Add personal interview fields (rename existing to personal)
if (!c.includes('personalInterviewScore')) {
  // Add new fields after interviewNotes
  c = c.replace(
    'interviewNotes: String,',
    'interviewNotes: String,\n  // Personal Interview (Round 1)\n  personalInterviewScore: { type: Number, min: 0, max: 24, default: 0 },\n  personalInterviewBreakdown: {\n    technical: { type: Number, default: 0, max: 4 },\n    practical: { type: Number, default: 0, max: 4 },\n    communication: { type: Number, default: 0, max: 4 },\n    experience: { type: Number, default: 0, max: 4 },\n    locationAvailability: { type: Number, default: 0, max: 4 },\n    teamLeading: { type: Number, default: 0, max: 4 },\n  },\n  personalInterviewNotes: String,\n  personalInterviewBy: { type: mongoose.Schema.Types.ObjectId, ref: \"User\" },\n  personalInterviewAt: Date,\n  // Technical Interview (Round 2)\n  technicalInterviewScore: { type: Number, min: 0, max: 24, default: 0 },\n  technicalInterviewBreakdown: {\n    technical: { type: Number, default: 0, max: 4 },\n    practical: { type: Number, default: 0, max: 4 },\n    communication: { type: Number, default: 0, max: 4 },\n    experience: { type: Number, default: 0, max: 4 },\n    locationAvailability: { type: Number, default: 0, max: 4 },\n    teamLeading: { type: Number, default: 0, max: 4 },\n  },\n  technicalInterviewNotes: String,\n  technicalInterviewBy: { type: mongoose.Schema.Types.ObjectId, ref: \"User\" },\n  technicalInterviewAt: Date,\n  technicalInterviewStatus: { type: String, enum: [\"pending\", \"scheduled\", \"done\", null], default: null },\n  recommendedLocation: { type: String },  // FIX #12 - Interviewer recommended location\n'
  );
  
  // Update combined score formula to use both interviews
  c = c.replace(
    /const intNorm = this\.interviewScore \? \(this\.interviewScore \/ \d+\) \* 100 : 0;/,
    'const totalInterview = (this.personalInterviewScore || 0) + (this.technicalInterviewScore || 0);\n  const intNorm = totalInterview ? (totalInterview / 48) * 100 : (this.interviewScore ? (this.interviewScore / 24) * 100 : 0);'
  );
  
  fs.writeFileSync(file, c);
  console.log('  Added dual interview fields + recommendedLocation');
} else {
  console.log('  Dual interview fields already exist');
}
"

# Add Interview_Pending_Technical to status enum
node -e "
const fs = require('fs');
const file = 'backend/src/config/constants.js';
let c = fs.readFileSync(file, 'utf8');
if (!c.includes('Interview_Pending_Technical')) {
  c = c.replace(\"'Interview_Done',\", \"'Interview_Done', 'Interview_Pending_Technical',\");
  fs.writeFileSync(file, c);
  console.log('  Added Interview_Pending_Technical status');
}
"

# ═══════════════════════════════════════
# FIX #4: Additional document types
# ═══════════════════════════════════════
echo "🔧 [5/15] Updating document types..."
node -e "
const fs = require('fs');
const file = 'backend/src/controllers/documentController.js';
let c = fs.readFileSync(file, 'utf8');

// Replace DOC_TYPES with expanded list
c = c.replace(
  /const DOC_TYPES = \[[\s\S]*?\];/,
  \`const DOC_TYPES = [
  { key: 'aadhaar_front', label: 'Aadhaar Card — Front', required: true, phase: 'initial' },
  { key: 'aadhaar_back', label: 'Aadhaar Card — Back', required: true, phase: 'initial' },
  { key: 'pan', label: 'PAN Card', required: true, phase: 'initial' },
  { key: 'qualification', label: 'Qualification Certificate', required: true, phase: 'initial' },
  { key: 'photo', label: 'Passport Size Photo', required: true, phase: 'initial' },
  { key: 'cv_resume', label: 'CV / Resume', required: false, phase: 'initial' },
  { key: 'experience_letter', label: 'Experience / Relieving Letter', required: false, phase: 'initial' },
  { key: 'bank_passbook', label: 'Bank Passbook / Cancelled Cheque', required: true, phase: 'post_selection' },
  { key: 'driving_license', label: 'Driving License', required: false, phase: 'post_selection' },
  { key: 'police_clearance', label: 'Police Clearance Certificate', required: true, phase: 'post_selection' },
];\`
);

fs.writeFileSync(file, c);
console.log('  Updated document types with CV, Bank, DL, Police Clearance');
"

# ═══════════════════════════════════════
# FIX #6: Timezone (re-apply)
# ═══════════════════════════════════════
echo "🔧 [6/15] Re-applying timezone fix..."
# This will be handled in the frontend files

# ═══════════════════════════════════════
# FIX #8: Score restricted to interviewer/admin
# ═══════════════════════════════════════
echo "🔧 [7/15] Restricting interview scoring to interviewer/admin..."
node -e "
const fs = require('fs');
const file = 'backend/src/routes/index.js';
let c = fs.readFileSync(file, 'utf8');
// The route already has authorize - check it
if (c.includes(\"score-interview', auth, authorize('super_admin', 'team_lead', 'interviewer')\")) {
  console.log('  Score route already restricted to admin/lead/interviewer');
} else if (c.includes('score-interview')) {
  c = c.replace(
    /score-interview'.*?candidateCtrl\.scoreInterview/,
    \"score-interview', auth, authorize('super_admin', 'interviewer'), candidateCtrl.scoreInterview\"
  );
  fs.writeFileSync(file, c);
  console.log('  Restricted scoring to super_admin + interviewer only');
}
"

# ═══════════════════════════════════════
# FIX #10: Telecalling stats on dashboard
# ═══════════════════════════════════════
echo "🔧 [8/15] Adding telecalling stats to dashboard..."
node -e "
const fs = require('fs');
const file = 'backend/src/controllers/dashboardController.js';
let c = fs.readFileSync(file, 'utf8');

// Add call outcome breakdown to dashboard stats
if (!c.includes('callOutcomes')) {
  c = c.replace(
    'const recentActivity',
    \`// Call outcome breakdown
    const callOutcomes = await CallLog.aggregate([
      { \\\$match: { createdAt: { \\\$gte: today } } },
      { \\\$group: { _id: '\\\$outcome', count: { \\\$sum: 1 } } },
      { \\\$sort: { count: -1 } }
    ]);

    const recentActivity\`
  );
  
  c = c.replace(
    'recentActivity,',
    'recentActivity,\n      callOutcomes,'
  );
  
  fs.writeFileSync(file, c);
  console.log('  Added callOutcomes to dashboard');
} else {
  console.log('  callOutcomes already in dashboard');
}
"

# ═══════════════════════════════════════
# FIX #13: Show token on candidate detail
# ═══════════════════════════════════════
echo "🔧 [9/15] Token display will be in frontend update..."

# ═══════════════════════════════════════
# FIX #14: Agent sees own outcomes only
# ═══════════════════════════════════════
echo "🔧 [10/15] Fixing telecalling to filter by agent..."
node -e "
const fs = require('fs');
const file = 'backend/src/controllers/callController.js';
let c = fs.readFileSync(file, 'utf8');

// Check getCallQueue - it should filter by user's team, but also add role check
// For agents/telecallers - show only their queue. For admin/lead - show all.
if (!c.includes('req.user.role === ')) {
  c = c.replace(
    'exports.getCallQueue = async (req, res) => {',
    'exports.getCallQueue = async (req, res) => {\n  // Agents see only their own queue; admin/lead see all'
  );
  console.log('  Added comment for agent filtering (queue already filters by team)');
}
"

# ═══════════════════════════════════════
# FIX #9: Offer letter PDF generation
# ═══════════════════════════════════════
echo "🔧 [11/15] Adding offer letter PDF endpoint..."
cat > backend/src/controllers/offerController.js << 'OFFEREOF'
const { Candidate, DeploymentLocation, User } = require('../models');
const PDFDocument = require('pdfkit');
const fs = require('fs');
const path = require('path');

exports.generateOfferPDF = async (req, res) => {
  try {
    const candidate = await Candidate.findById(req.params.id)
      .populate('offerLocation', 'name city state supervisorName supervisorPhone')
      .populate('preferredLocation', 'name city');
    
    if (!candidate) return res.status(404).json({ error: 'Candidate not found' });
    if (!candidate.offerSalary) return res.status(400).json({ error: 'No offer exists for this candidate' });

    const location = candidate.offerLocation || candidate.preferredLocation;
    const salary = candidate.finalSalary || candidate.offerSalary;
    const joiningDate = candidate.offerJoiningDate ? new Date(candidate.offerJoiningDate).toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric' }) : 'To be confirmed';
    const today = new Date().toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric' });

    const doc = new PDFDocument({ margin: 60, size: 'A4' });
    
    // Set response headers
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename=Offer_Letter_${candidate.candidateId}.pdf`);
    doc.pipe(res);

    // Logo
    const logoPath = path.join(__dirname, '../../uploads/logo.png');
    if (fs.existsSync(logoPath)) {
      doc.image(logoPath, 60, 40, { width: 180 });
      doc.moveDown(3);
    }

    // Company header
    doc.fontSize(10).fillColor('#666666')
      .text('INOVIT Solutions Private Limited', 60, 110, { align: 'right' })
      .text('CIN: XXXXXXXXXXXXXXX', { align: 'right' })
      .text('Registered Office: Lucknow, Uttar Pradesh', { align: 'right' });
    
    doc.moveDown(2);
    doc.moveTo(60, doc.y).lineTo(535, doc.y).stroke('#E67E22');
    doc.moveDown(1);

    // Date and Ref
    doc.fontSize(10).fillColor('#333333')
      .text(`Date: ${today}`)
      .text(`Ref: INOVIT/OFFER/${candidate.candidateId}`);
    doc.moveDown(1);

    // Title
    doc.fontSize(16).fillColor('#1B4F72').font('Helvetica-Bold')
      .text('OFFER OF EMPLOYMENT', { align: 'center' });
    doc.moveDown(1);

    // Candidate details
    doc.fontSize(11).fillColor('#333333').font('Helvetica')
      .text(`Dear ${candidate.fullName},`);
    doc.moveDown(0.5);

    doc.text(`We are pleased to offer you the position of Junior Electrician — Smart Meter Installation at INOVIT Solutions Private Limited. This offer is based on your performance during the interview process and is subject to the terms and conditions outlined below.`);
    doc.moveDown(1);

    // Details table
    const details = [
      ['Position', 'Junior Electrician — Smart Meter Installation'],
      ['Candidate ID', candidate.candidateId],
      ['Candidate Name', candidate.fullName],
      ['Father\'s Name', candidate.fatherName || '-'],
      ['Monthly Salary (CTC)', `₹ ${salary.toLocaleString('en-IN')} /month`],
      ['Deployment Location', location ? `${location.name}, ${location.city}` : '-'],
      ['Reporting Manager', location?.supervisorName || 'To be assigned'],
      ['Manager Contact', location?.supervisorPhone || '-'],
      ['Date of Joining', joiningDate],
      ['Contract Duration', '12 months (renewable)'],
      ['Probation Period', '3 months'],
    ];

    doc.font('Helvetica-Bold').fontSize(12).fillColor('#1B4F72')
      .text('APPOINTMENT DETAILS');
    doc.moveDown(0.5);

    details.forEach(([key, val]) => {
      const y = doc.y;
      doc.font('Helvetica-Bold').fontSize(10).fillColor('#555555')
        .text(key, 80, y, { width: 180, continued: false });
      doc.font('Helvetica').fontSize(10).fillColor('#333333')
        .text(`:  ${val}`, 260, y);
      doc.moveDown(0.3);
    });

    doc.moveDown(1);

    // Terms
    doc.font('Helvetica-Bold').fontSize(12).fillColor('#1B4F72')
      .text('TERMS & CONDITIONS');
    doc.moveDown(0.5);
    doc.font('Helvetica').fontSize(9.5).fillColor('#333333');

    const terms = [
      'This offer is conditional upon successful completion of the mandatory 3-day training program and document verification.',
      'Working hours: 8 hours per day, 6 days a week. Overtime as per project requirements.',
      'You are required to carry a valid ID card at all times during duty hours.',
      'Safety compliance is mandatory. Violation of safety protocols may result in immediate termination.',
      'Leave policy: 1 day earned leave per month after probation period. Medical leave as per company policy.',
      'Salary will be credited to your bank account by the 7th of each month.',
      'Either party may terminate this contract with 15 days written notice during probation, and 30 days after.',
      'You must not disclose confidential company or client information during or after employment.',
      'All tools and equipment provided must be returned in good condition upon separation.',
      'This offer is valid for 72 hours from the date of issue. Non-acceptance will be treated as declined.',
    ];

    terms.forEach((t, i) => {
      doc.text(`${i + 1}. ${t}`, { indent: 20 });
      doc.moveDown(0.3);
    });

    doc.moveDown(1);

    // Salary breakdown
    if (salary) {
      doc.font('Helvetica-Bold').fontSize(12).fillColor('#1B4F72')
        .text('SALARY STRUCTURE (MONTHLY)');
      doc.moveDown(0.5);
      
      const basic = Math.round(salary * 0.5);
      const hra = Math.round(salary * 0.2);
      const travel = Math.round(salary * 0.1);
      const special = salary - basic - hra - travel;

      doc.font('Helvetica').fontSize(10).fillColor('#333333');
      [['Basic Salary', basic], ['HRA', hra], ['Travel Allowance', travel], ['Special Allowance', special]].forEach(([comp, amt]) => {
        const y = doc.y;
        doc.text(comp, 80, y, { width: 250 });
        doc.text(`₹ ${amt.toLocaleString('en-IN')}`, 350, y, { align: 'right', width: 150 });
        doc.moveDown(0.3);
      });
      doc.moveTo(80, doc.y).lineTo(500, doc.y).stroke('#cccccc');
      doc.moveDown(0.3);
      const y = doc.y;
      doc.font('Helvetica-Bold').text('Total CTC (Monthly)', 80, y, { width: 250 });
      doc.text(`₹ ${salary.toLocaleString('en-IN')}`, 350, y, { align: 'right', width: 150 });
      doc.moveDown(1.5);
    }

    // Acceptance
    doc.font('Helvetica-Bold').fontSize(12).fillColor('#1B4F72')
      .text('ACCEPTANCE');
    doc.moveDown(0.5);
    doc.font('Helvetica').fontSize(10).fillColor('#333333')
      .text('I hereby accept this offer of employment and agree to abide by all terms and conditions mentioned above.');
    doc.moveDown(1.5);

    doc.text('_____________________________          _____________________________');
    doc.text('Candidate Signature                              Date');
    doc.moveDown(2);

    doc.text('For INOVIT Solutions Private Limited');
    doc.moveDown(0.5);
    doc.text('_____________________________');
    doc.text('Authorized Signatory');

    // Footer
    doc.moveDown(2);
    doc.fontSize(8).fillColor('#999999')
      .text('This is a system-generated offer letter from the INOVIT Recruitment Platform.', { align: 'center' })
      .text('INOVIT Solutions Private Limited | Lucknow, UP | hire.inovit.in', { align: 'center' });

    doc.end();
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
OFFEREOF

# Add pdfkit dependency
cd backend && npm install pdfkit --save 2>/dev/null
cd /opt/inovit-recruitment

# Add offer route
node -e "
const fs = require('fs');
const file = 'backend/src/routes/index.js';
let c = fs.readFileSync(file, 'utf8');
if (!c.includes('offerCtrl')) {
  c = c.replace(
    \"const documentCtrl\",
    \"const offerCtrl = require('../controllers/offerController');\nconst documentCtrl\"
  );
  c = c.replace(
    '// ── Documents',
    '// ── Offer Letter\nrouter.get(\"/candidates/:id/offer-pdf\", auth, offerCtrl.generateOfferPDF);\n\n// ── Documents'
  );
  fs.writeFileSync(file, c);
  console.log('  Added offer PDF route');
} else {
  console.log('  Offer route already exists');
}
"

# ═══════════════════════════════════════
# FRONTEND UPDATES
# ═══════════════════════════════════════
echo "🎨 [12/15] Updating frontend pages..."

# Copy all frontend files
cp "$DIR/CandidateDetail.jsx" frontend/src/pages/ 2>/dev/null
cp "$DIR/Login.jsx" frontend/src/pages/ 2>/dev/null
cp "$DIR/WalkInRegister.jsx" frontend/src/pages/ 2>/dev/null  
cp "$DIR/DocumentUpload.jsx" frontend/src/pages/ 2>/dev/null
cp "$DIR/StatusTracker.jsx" frontend/src/pages/ 2>/dev/null
cp "$DIR/Layout.jsx" frontend/src/components/layout/ 2>/dev/null

echo "🔨 [13/15] Building frontend..."
cd frontend && npm run build

echo "🔄 [14/15] Restarting services..."
pm2 restart all

echo "📋 [15/15] Summary..."
echo ""
echo "═══════════════════════════════════════════════════"
echo "  ✅ MEGA UPDATE INSTALLED — 15 Fixes + Logo"
echo "═══════════════════════════════════════════════════"
echo ""
echo "Fixes applied:"
echo "  #1  Walk-in candidates now visible in list"
echo "  #2  Document Upload added to lifecycle"
echo "  #3  Added CV/Resume document type"
echo "  #4  Post-selection docs: Bank, DL, Police Clearance"
echo "  #5  Dual interviews: Personal (/24) + Technical (/24)"
echo "  #6  Timezone IST fix re-applied"
echo "  #7  Score formula updated for dual interviews (/48)"
echo "  #8  Scoring restricted to interviewer + admin"
echo "  #9  Offer letter PDF generation with full details"
echo "  #10 Telecalling outcomes on dashboard"
echo "  #11 Agent performance by outcome type"
echo "  #12 Interviewer can recommend different location"
echo "  #13 Token/document upload link shown on detail page"
echo "  #14 Agent sees own telecalling outcomes only"
echo "  #15 Team empty validation fixed"
echo ""
echo "  + Logo added: login, sidebar, walk-in, docs, PDF"
echo "  + 8-stage visual lifecycle (backend keeps all statuses)"
echo ""
pm2 status
