import { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios';
import { AlertCircle } from 'lucide-react';

const API = import.meta.env.VITE_API_URL || '/api';
const STAGES = [
  { key:'new', label:'Application', icon:'📝' },
  { key:'screening', label:'Screening', icon:'🔍' },
  { key:'interview', label:'Interview', icon:'🎤' },
  { key:'selection', label:'Selection', icon:'✅' },
  { key:'offer', label:'Offer', icon:'📨' },
  { key:'documents', label:'Documents', icon:'📄' },
  { key:'training', label:'Training', icon:'📚' },
  { key:'deployment', label:'Deployment', icon:'🚀' },
];

export default function StatusTracker() {
  const { token } = useParams();
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    axios.get(`${API}/status/${token}`).then(res => setData(res.data)).catch(() => setError('Invalid status link')).finally(() => setLoading(false));
  }, [token]);

  if (loading) return <div className="min-h-screen bg-gray-50 flex items-center justify-center"><div className="animate-spin rounded-full h-10 w-10 border-b-2 border-blue-600"></div></div>;
  if (error) return (<div className="min-h-screen bg-gray-50 flex items-center justify-center p-4"><div className="bg-white rounded-2xl shadow-xl max-w-md w-full p-8 text-center"><AlertCircle size={48} className="mx-auto text-red-500 mb-4"/><h1 className="text-xl font-bold">Invalid Link</h1><p className="text-gray-600">{error}</p></div></div>);

  const currentStage = data?.currentStage || 0;

  return (
    <div className="min-h-screen bg-gradient-to-b from-primary-600 to-primary-800 py-8 px-4">
      <div className="max-w-lg mx-auto">
        <div className="text-center text-white mb-6">
          <img src="/logo-medium.png" alt="INOVIT" className="h-14 mx-auto mb-2" onError={e=>{e.target.style.display='none';}} />
          <p className="text-primary-200 text-sm">Application Status</p>
        </div>
        <div className="bg-white rounded-2xl shadow-xl p-6 md:p-8">
          <div className="text-center mb-6">
            <h2 className="text-xl font-bold text-gray-900">Hi, {data?.name}!</h2>
            <p className="text-sm text-gray-500">ID: {data?.candidateId}</p>
          </div>
          <div className="space-y-4">
            {STAGES.map((stage, i) => {
              const isActive = i === currentStage;
              const isDone = i < currentStage;
              return (
                <div key={stage.key} className={'flex items-center gap-4 p-3 rounded-lg transition '+(isActive?'bg-primary-50 border-2 border-primary-300':isDone?'bg-green-50':'bg-gray-50')}>
                  <div className={'w-10 h-10 rounded-full flex items-center justify-center text-lg '+(isDone?'bg-green-500 text-white':isActive?'bg-primary-500 text-white':'bg-gray-200')}>
                    {isDone ? '✓' : stage.icon}
                  </div>
                  <div className="flex-1">
                    <div className={'font-medium '+(isActive?'text-primary-700':isDone?'text-green-700':'text-gray-400')}>{stage.label}</div>
                    {isActive && <div className="text-xs text-primary-500 mt-0.5">Current stage</div>}
                  </div>
                  {isDone && <span className="text-xs text-green-600 font-medium">Complete</span>}
                </div>
              );
            })}
          </div>
          {data?.details?.interviewDate && <div className="mt-4 p-3 bg-blue-50 rounded-lg text-sm text-blue-700">Interview scheduled: {new Date(data.details.interviewDate).toLocaleString('en-IN',{dateStyle:'medium',timeStyle:'short',timeZone:'Asia/Kolkata'})}</div>}
          <p className="text-center text-xs text-gray-400 mt-6">INOVIT Solutions Private Limited © 2026</p>
        </div>
      </div>
    </div>
  );
}
