import { useState, useEffect } from 'react';
import { authAPI } from '../services/api';
import api from '../services/api';
import { UserPlus, Edit2, Shield, Phone, Mail, Users, X, Eye, EyeOff, ToggleLeft, ToggleRight } from 'lucide-react';
import toast from 'react-hot-toast';

const ROLES = [
  { value: 'super_admin', label: 'Super Admin', color: 'bg-red-100 text-red-700', desc: 'Full access to everything' },
  { value: 'team_lead', label: 'Team Lead', color: 'bg-purple-100 text-purple-700', desc: 'Dashboard, Candidates, Selection, Import' },
  { value: 'agent', label: 'Agent', color: 'bg-blue-100 text-blue-700', desc: 'Dashboard, Candidates, Telecalling' },
  { value: 'interviewer', label: 'Interviewer', color: 'bg-green-100 text-green-700', desc: 'Dashboard, Score interviews' },
  { value: 'telecaller', label: 'Telecaller', color: 'bg-orange-100 text-orange-700', desc: 'Dashboard, Telecalling module' },
];

const TEAMS = ['Alpha', 'Beta', 'Gamma', 'Delta'];

export default function UserManagement() {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editUser, setEditUser] = useState(null);
  const [showPassword, setShowPassword] = useState(false);
  const [filterRole, setFilterRole] = useState('');
  const [filterActive, setFilterActive] = useState('');
  const [form, setForm] = useState({
    name: '', email: '', password: '', role: 'agent', team: 'Alpha', phone: '', languages: ['hi', 'en']
  });

  const fetchUsers = async () => {
    try {
      setLoading(true);
      const params = {};
      if (filterRole) params.role = filterRole;
      if (filterActive) params.active = filterActive;
      const res = await authAPI.getUsers(params);
      setUsers(res.data.users || []);
    } catch (err) {
      toast.error('Failed to load users');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchUsers(); }, [filterRole, filterActive]);

  const openAddModal = () => {
    setEditUser(null);
    setForm({ name: '', email: '', password: '', role: 'agent', team: 'Alpha', phone: '', languages: ['hi', 'en'] });
    setShowPassword(false);
    setShowModal(true);
  };

  const openEditModal = (user) => {
    setEditUser(user);
    setForm({
      name: user.name, email: user.email, password: '', role: user.role,
      team: user.team || '', phone: user.phone || '', languages: user.languages || ['hi', 'en']
    });
    setShowModal(true);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (editUser) {
        const updates = { name: form.name, role: form.role, team: form.team, phone: form.phone, languages: form.languages };
        await api.put(`/users/${editUser._id}`, updates);
        toast.success(`${form.name} updated successfully`);
      } else {
        if (!form.password || form.password.length < 6) {
          toast.error('Password must be at least 6 characters');
          return;
        }
        await api.post('/auth/register', form);
        toast.success(`${form.name} added successfully`);
      }
      setShowModal(false);
      fetchUsers();
    } catch (err) {
      toast.error(err.response?.data?.error || 'Operation failed');
    }
  };

  const toggleActive = async (user) => {
    try {
      await api.put(`/users/${user._id}`, { isActive: !user.isActive });
      toast.success(`${user.name} ${user.isActive ? 'deactivated' : 'activated'}`);
      fetchUsers();
    } catch (err) {
      toast.error('Failed to update user');
    }
  };

  const getRoleBadge = (role) => {
    const r = ROLES.find(x => x.value === role);
    return r ? <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${r.color}`}>{r.label}</span> : role;
  };

  const toggleLanguage = (lang) => {
    const langs = form.languages.includes(lang)
      ? form.languages.filter(l => l !== lang)
      : [...form.languages, lang];
    setForm(f => ({ ...f, languages: langs }));
  };

  const stats = {
    total: users.length,
    active: users.filter(u => u.isActive).length,
    byRole: ROLES.map(r => ({ ...r, count: users.filter(u => u.role === r.value).length })),
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">User Management</h1>
          <p className="text-sm text-gray-500 mt-1">{stats.active} active users of {stats.total} total</p>
        </div>
        <button onClick={openAddModal} className="btn-primary flex items-center gap-2">
          <UserPlus size={18} /> Add New User
        </button>
      </div>

      {/* Role Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
        {stats.byRole.map(r => (
          <div key={r.value} className="bg-white rounded-lg border p-3 text-center cursor-pointer hover:shadow-md transition"
            onClick={() => setFilterRole(filterRole === r.value ? '' : r.value)}>
            <div className={`text-2xl font-bold ${filterRole === r.value ? 'text-primary-600' : 'text-gray-900'}`}>{r.count}</div>
            <div className="text-xs text-gray-500 mt-1">{r.label}s</div>
            {filterRole === r.value && <div className="w-full h-0.5 bg-primary-600 mt-2 rounded"></div>}
          </div>
        ))}
      </div>

      {/* Filters */}
      <div className="flex gap-3 items-center">
        <select value={filterRole} onChange={e => setFilterRole(e.target.value)} className="input-field w-auto text-sm">
          <option value="">All Roles</option>
          {ROLES.map(r => <option key={r.value} value={r.value}>{r.label}</option>)}
        </select>
        <select value={filterActive} onChange={e => setFilterActive(e.target.value)} className="input-field w-auto text-sm">
          <option value="">All Status</option>
          <option value="true">Active</option>
          <option value="false">Inactive</option>
        </select>
        {(filterRole || filterActive) && (
          <button onClick={() => { setFilterRole(''); setFilterActive(''); }} className="text-sm text-primary-600 hover:underline">
            Clear filters
          </button>
        )}
      </div>

      {/* Users Table */}
      <div className="bg-white rounded-lg border overflow-hidden">
        {loading ? (
          <div className="flex justify-center py-12">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary-600"></div>
          </div>
        ) : users.length === 0 ? (
          <div className="text-center py-12 text-gray-500">No users found</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 border-b">
                <tr>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Name</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Email</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Role</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Team</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Phone</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Last Login</th>
                  <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {users.map(user => (
                  <tr key={user._id} className={`hover:bg-gray-50 ${!user.isActive ? 'opacity-50' : ''}`}>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full bg-primary-100 text-primary-600 flex items-center justify-center text-sm font-bold">
                          {user.name?.charAt(0)?.toUpperCase()}
                        </div>
                        <span className="font-medium text-gray-900 text-sm">{user.name}</span>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-sm text-gray-600">{user.email}</td>
                    <td className="px-4 py-3">{getRoleBadge(user.role)}</td>
                    <td className="px-4 py-3 text-sm text-gray-600">{user.team || '—'}</td>
                    <td className="px-4 py-3 text-sm text-gray-600 font-mono">{user.phone || '—'}</td>
                    <td className="px-4 py-3">
                      <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${user.isActive ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                        {user.isActive ? 'Active' : 'Inactive'}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-xs text-gray-500">
                      {user.lastLogin ? new Date(user.lastLogin).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }) : 'Never'}
                    </td>
                    <td className="px-4 py-3 text-right">
                      <div className="flex items-center justify-end gap-2">
                        <button onClick={() => openEditModal(user)} className="p-1.5 text-gray-400 hover:text-primary-600 hover:bg-primary-50 rounded" title="Edit">
                          <Edit2 size={15} />
                        </button>
                        <button onClick={() => toggleActive(user)} className={`p-1.5 rounded ${user.isActive ? 'text-gray-400 hover:text-red-600 hover:bg-red-50' : 'text-gray-400 hover:text-green-600 hover:bg-green-50'}`}
                          title={user.isActive ? 'Deactivate' : 'Activate'}>
                          {user.isActive ? <ToggleRight size={15} /> : <ToggleLeft size={15} />}
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Add/Edit Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between p-5 border-b">
              <h3 className="text-lg font-bold text-gray-900">{editUser ? 'Edit User' : 'Add New User'}</h3>
              <button onClick={() => setShowModal(false)} className="text-gray-400 hover:text-gray-600"><X size={20} /></button>
            </div>
            <form onSubmit={handleSubmit} className="p-5 space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Full Name *</label>
                <input value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} required
                  placeholder="e.g., Priya Sharma" className="input-field" />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Email *</label>
                <input type="email" value={form.email} onChange={e => setForm(f => ({ ...f, email: e.target.value }))} required
                  placeholder="e.g., priya@inovit.in" className="input-field" disabled={!!editUser} />
                {editUser && <p className="text-xs text-gray-400 mt-1">Email cannot be changed</p>}
              </div>

              {!editUser && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Password *</label>
                  <div className="relative">
                    <input type={showPassword ? 'text' : 'password'} value={form.password}
                      onChange={e => setForm(f => ({ ...f, password: e.target.value }))} required minLength={6}
                      placeholder="Minimum 6 characters" className="input-field pr-10" />
                    <button type="button" onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600">
                      {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                    </button>
                  </div>
                </div>
              )}

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Role *</label>
                <select value={form.role} onChange={e => setForm(f => ({ ...f, role: e.target.value }))} className="input-field">
                  {ROLES.map(r => <option key={r.value} value={r.value}>{r.label} — {r.desc}</option>)}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Team</label>
                <select value={form.team} onChange={e => setForm(f => ({ ...f, team: e.target.value }))} className="input-field">
                  <option value="">No Team</option>
                  {TEAMS.map(t => <option key={t} value={t}>{t}</option>)}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Phone</label>
                <input type="tel" value={form.phone} onChange={e => setForm(f => ({ ...f, phone: e.target.value }))}
                  placeholder="10-digit number" maxLength={10} className="input-field font-mono" />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Languages</label>
                <div className="flex flex-wrap gap-2">
                  {[{ code: 'hi', label: 'Hindi' }, { code: 'en', label: 'English' }, { code: 'ta', label: 'Tamil' }, { code: 'te', label: 'Telugu' }, { code: 'bn', label: 'Bengali' }, { code: 'mr', label: 'Marathi' }, { code: 'gu', label: 'Gujarati' }, { code: 'kn', label: 'Kannada' }].map(l => (
                    <button key={l.code} type="button" onClick={() => toggleLanguage(l.code)}
                      className={`text-xs px-3 py-1.5 rounded-full border transition ${form.languages.includes(l.code) ? 'bg-primary-100 border-primary-300 text-primary-700' : 'bg-gray-50 border-gray-200 text-gray-500 hover:bg-gray-100'}`}>
                      {l.label}
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex gap-3 pt-2">
                <button type="button" onClick={() => setShowModal(false)} className="flex-1 px-4 py-2.5 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 text-sm font-medium">
                  Cancel
                </button>
                <button type="submit" className="flex-1 btn-primary py-2.5 text-sm">
                  {editUser ? 'Save Changes' : 'Add User'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
