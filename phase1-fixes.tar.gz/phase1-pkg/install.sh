#!/bin/bash
echo "Installing Phase 1 Critical Fixes..."
DIR="$(cd "$(dirname "$0")" && pwd)"
cd /opt/inovit-recruitment

cp "$DIR/CandidateDetail.jsx" frontend/src/pages/
cp "$DIR/api.js" frontend/src/services/
cp "$DIR/App.jsx" frontend/src/
cp "$DIR/Layout.jsx" frontend/src/components/layout/
cp "$DIR/UserManagement.jsx" frontend/src/pages/

sed -i "s/.select('name city state')/.select('name city state quota deployed')/" backend/src/controllers/walkinController.js 2>/dev/null

cd frontend && npm run build && pm2 restart all
echo "✅ Phase 1 installed! Open https://hire.inovit.in"
