import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { candidateAPI, locationAPI, authAPI } from '../services/api';
import api from '../services/api';
import toast from 'react-hot-toast';
import { ArrowLeft, Phone, Mail, MapPin, Star, Clock, Send, FileText, Edit2, X, Save, UserCheck, Calendar, Briefcase, ChevronDown } from 'lucide-react';

const eventIcons = {
  whatsapp_out: '📤', whatsapp_in: '📩', call_outbound: '📞', call_inbound: '📲',
  sms_sent: '📱', internal_note: '📝', status_change: '🔄', document_event: '📄',
  score_update: '🎯', panel_decision: '✅', system_event: '⚙️',
};
const eventColors = {
  whatsapp_out: 'border-green-300 bg-green-50', whatsapp_in: 'border-green-400 bg-green-50',
  call_outbound: 'border-blue-300 bg-blue-50', call_inbound: 'border-blue-400 bg-blue-50',
  status_change: 'border-yellow-300 bg-yellow-50', panel_decision: 'border-emerald-300 bg-emerald-50',
  internal_note: 'border-purple-300 bg-purple-50', system_event: 'border-gray-300 bg-gray-50',
  score_update: 'border-orange-300 bg-orange-50', document_event: 'border-indigo-300 bg-indigo-50',
};

const ALL_STATUSES = [
  'New','Walk_In_Registered','Contacted','WhatsApp_Failed','Interested','Not_Interested',
  'Screening','Screened','Portal_Applied','Interview_Scheduled','Interview_Done',
  'Selected','Rejected','On_Hold','Waitlisted','Offered','Offer_Accepted','Offer_Declined',
  'Onboarding','Training','Training_Completed','Training_Failed','Deployed','Unreachable','Blacklisted','Archived'
];
const QUALIFICATIONS = [
  {v:'ITI_Electrical',l:'ITI - Electrical'},{v:'ITI_Other',l:'ITI - Other'},{v:'Diploma_Electrical',l:'Diploma - Electrical'},
  {v:'Diploma_Other',l:'Diploma - Other'},{v:'BTech_Electrical',l:'B.Tech - Electrical'},{v:'BTech_Other',l:'B.Tech - Other'},
  {v:'BSc',l:'B.Sc'},{v:'HSC',l:'12th / HSC'},{v:'10th',l:'10th'},{v:'Other',l:'Other'}
];

export default function CandidateDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [candidate, setCandidate] = useState(null);
  const [timeline, setTimeline] = useState([]);
  const [loading, setLoading] = useState(true);
  const [note, setNote] = useState('');
  const [timelineFilter, setTimelineFilter] = useState('all');

  // Modals
  const [editModal, setEditModal] = useState(false);
  const [statusModal, setStatusModal] = useState(false);
  const [assignModal, setAssignModal] = useState(false);
  const [interviewModal, setInterviewModal] = useState(false);
  const [offerModal, setOfferModal] = useState(false);
  const [scoreModal, setScoreModal] = useState(false);

  // Data for dropdowns
  const [locations, setLocations] = useState([]);
  const [users, setUsers] = useState([]);

  // Form states
  const [editForm, setEditForm] = useState({});
  const [statusForm, setStatusForm] = useState({ status: '', reason: '' });
  const [assignForm, setAssignForm] = useState({ agent: '', team: '' });
  const [interviewForm, setInterviewForm] = useState({ date: '', type: 'virtual', interviewer: '', link: '' });
  const [offerForm, setOfferForm] = useState({ salary: 18000, location: '', joiningDate: '' });
  const [scoreForm, setScoreForm] = useState({ technical: 5, practical: 5, communication: 5, experience: 5, locationAvailability: 5, quizNormalized: 5, notes: '' });

  const reload = () => {
    candidateAPI.getOne(id).then(res => {
      setCandidate(res.data.candidate);
      setTimeline(res.data.timeline || []);
    }).catch(() => toast.error('Candidate not found')).finally(() => setLoading(false));
  };

  useEffect(() => {
    reload();
    locationAPI.getAll().then(r => setLocations(r.data.locations || [])).catch(() => {});
    authAPI.getUsers().then(r => setUsers(r.data.users || [])).catch(() => {});
  }, [id]);

  // ── Add Note ──
  const addNote = async () => {
    if (!note.trim()) return;
    try {
      await candidateAPI.addNote(id, { content: note });
      toast.success('Note added');
      setNote('');
      reload();
    } catch { toast.error('Failed to add note'); }
  };

  // ── Edit Candidate ──
  const openEdit = () => {
    const c = candidate;
    setEditForm({
      fullName: c.fullName || '', phone: c.phone || '', alternatePhone: c.alternatePhone || '',
      email: c.email || '', qualification: c.qualification || '', experienceYears: c.experienceYears || 0,
      electricalTrade: c.electricalTrade || false, currentCity: c.currentLocation?.city || '',
      currentState: c.currentLocation?.state || '', preferredLocation: c.preferredLocation?._id || '',
      preferredLanguage: c.preferredLanguage || 'hi', gender: c.gender || '', dateOfBirth: c.dateOfBirth ? c.dateOfBirth.slice(0,10) : '',
    });
    setEditModal(true);
  };
  const saveEdit = async () => {
    try {
      await candidateAPI.update(id, {
        fullName: editForm.fullName, phone: editForm.phone, alternatePhone: editForm.alternatePhone,
        email: editForm.email, qualification: editForm.qualification, experienceYears: Number(editForm.experienceYears),
        electricalTrade: editForm.electricalTrade, currentLocation: { city: editForm.currentCity, state: editForm.currentState },
        preferredLocation: editForm.preferredLocation || undefined, preferredLanguage: editForm.preferredLanguage,
        gender: editForm.gender, dateOfBirth: editForm.dateOfBirth || undefined,
      });
      toast.success('Candidate updated');
      setEditModal(false);
      reload();
    } catch (err) { toast.error(err.response?.data?.error || 'Update failed'); }
  };

  // ── Change Status ──
  const openStatus = () => { setStatusForm({ status: candidate.status, reason: '' }); setStatusModal(true); };
  const saveStatus = async () => {
    if (statusForm.status === candidate.status) { setStatusModal(false); return; }
    try {
      await candidateAPI.update(id, { status: statusForm.status, statusChangeReason: statusForm.reason });
      toast.success('Status changed to ' + statusForm.status.replace(/_/g, ' '));
      setStatusModal(false);
      reload();
    } catch (err) { toast.error(err.response?.data?.error || 'Failed'); }
  };

  // ── Assign Agent ──
  const openAssign = () => { setAssignForm({ agent: candidate.assignedAgent?._id || '', team: candidate.assignedTeam || '' }); setAssignModal(true); };
  const saveAssign = async () => {
    try {
      await candidateAPI.update(id, { assignedAgent: assignForm.agent || undefined, assignedTeam: assignForm.team || undefined });
      toast.success('Agent assigned');
      setAssignModal(false);
      reload();
    } catch (err) { toast.error('Failed to assign'); }
  };

  // ── Schedule Interview ──
  const openInterview = () => {
    setInterviewForm({
      date: candidate.interviewScheduled ? candidate.interviewScheduled.slice(0,16) : '',
      type: candidate.interviewType || 'virtual', interviewer: candidate.interviewer?._id || '', link: candidate.interviewLink || ''
    });
    setInterviewModal(true);
  };
  const saveInterview = async () => {
    try {
      await candidateAPI.update(id, {
        interviewScheduled: interviewForm.date, interviewType: interviewForm.type,
        interviewer: interviewForm.interviewer || undefined, interviewLink: interviewForm.link,
        status: 'Interview_Scheduled', statusChangeReason: 'Interview scheduled'
      });
      toast.success('Interview scheduled');
      setInterviewModal(false);
      reload();
    } catch (err) { toast.error('Failed to schedule'); }
  };

  // ── Create Offer ──
  const openOffer = () => {
    setOfferForm({
      salary: candidate.offerSalary || 18000,
      location: candidate.offerLocation?._id || candidate.preferredLocation?._id || '',
      joiningDate: candidate.offerJoiningDate ? candidate.offerJoiningDate.slice(0,10) : ''
    });
    setOfferModal(true);
  };
  const saveOffer = async () => {
    try {
      await candidateAPI.update(id, {
        offerSalary: Number(offerForm.salary), offerLocation: offerForm.location,
        offerJoiningDate: offerForm.joiningDate, offerSentAt: new Date().toISOString(),
        offerExpiresAt: new Date(Date.now() + 72*60*60*1000).toISOString(),
        status: 'Offered', statusChangeReason: 'Offer sent'
      });
      toast.success('Offer created and sent');
      setOfferModal(false);
      reload();
    } catch (err) { toast.error('Failed to create offer'); }
  };

  // ── Accept/Decline Offer ──
  const acceptOffer = async () => {
    try {
      await candidateAPI.update(id, { status: 'Offer_Accepted', offerAcceptedAt: new Date().toISOString(), statusChangeReason: 'Offer accepted' });
      toast.success('Offer accepted!');
      reload();
    } catch { toast.error('Failed'); }
  };
  const declineOffer = async () => {
    const reason = prompt('Decline reason:');
    if (!reason) return;
    try {
      await candidateAPI.update(id, { status: 'Offer_Declined', offerDeclinedAt: new Date().toISOString(), offerDeclineReason: reason, statusChangeReason: 'Offer declined: ' + reason });
      toast.success('Offer declined');
      reload();
    } catch { toast.error('Failed'); }
  };

  // ── Score Interview ──
  const openScore = () => {
    const b = candidate.interviewBreakdown || {};
    setScoreForm({
      technical: b.technical || 5, practical: b.practical || 5, communication: b.communication || 5,
      experience: b.experience || 5, locationAvailability: b.locationAvailability || 5,
      quizNormalized: b.quizNormalized || 5, notes: candidate.interviewNotes || ''
    });
    setScoreModal(true);
  };
  const saveScore = async () => {
    try {
      await candidateAPI.scoreInterview(id, scoreForm);
      toast.success('Interview scored');
      setScoreModal(false);
      reload();
    } catch (err) { toast.error(err.response?.data?.error || 'Failed'); }
  };

  // ── Blacklist ──
  const toggleBlacklist = async () => {
    const reason = candidate.blacklisted ? null : prompt('Blacklist reason:');
    if (!candidate.blacklisted && !reason) return;
    try {
      await candidateAPI.update(id, {
        blacklisted: !candidate.blacklisted,
        blacklistReason: reason || '',
        status: candidate.blacklisted ? candidate.status : 'Blacklisted',
        statusChangeReason: candidate.blacklisted ? 'Removed from blacklist' : 'Blacklisted: ' + reason
      });
      toast.success(candidate.blacklisted ? 'Removed from blacklist' : 'Blacklisted');
      reload();
    } catch { toast.error('Failed'); }
  };

  // Timeline filter
  const filteredTimeline = timelineFilter === 'all' ? timeline : timeline.filter(e => {
    if (timelineFilter === 'whatsapp') return e.eventType?.includes('whatsapp');
    if (timelineFilter === 'calls') return e.eventType?.includes('call');
    if (timelineFilter === 'notes') return e.eventType === 'internal_note';
    if (timelineFilter === 'system') return ['status_change','system_event','panel_decision','score_update'].includes(e.eventType);
    return true;
  });

  if (loading) return <div className="flex items-center justify-center h-64"><div className="animate-spin rounded-full h-10 w-10 border-b-2 border-primary-600"></div></div>;
  if (!candidate) return <div className="text-center py-10 text-gray-500">Candidate not found</div>;
  const c = candidate;
  const scoreColor = (s) => s >= 80 ? 'text-green-600 bg-green-50' : s >= 60 ? 'text-blue-600 bg-blue-50' : s >= 40 ? 'text-yellow-600 bg-yellow-50' : 'text-red-500 bg-red-50';
  const statusColor = (s) => {
    if (['Deployed','Training_Completed'].includes(s)) return 'bg-green-100 text-green-700';
    if (['Selected','Offered','Offer_Accepted'].includes(s)) return 'bg-blue-100 text-blue-700';
    if (['Rejected','Blacklisted','Archived'].includes(s)) return 'bg-red-100 text-red-700';
    if (['On_Hold','Waitlisted'].includes(s)) return 'bg-amber-100 text-amber-700';
    return 'bg-gray-100 text-gray-700';
  };

  const agents = users.filter(u => ['agent','team_lead','telecaller'].includes(u.role));
  const interviewers = users.filter(u => ['interviewer','super_admin','team_lead'].includes(u.role));

  return (
    <div className="space-y-6">
      <button onClick={() => navigate(-1)} className="flex items-center gap-1 text-sm text-gray-500 hover:text-gray-700"><ArrowLeft size={16} /> Back</button>

      {/* Header */}
      <div className="card flex flex-col md:flex-row md:items-center gap-4">
        <div className="w-14 h-14 rounded-full bg-primary-100 flex items-center justify-center text-primary-700 font-bold text-xl">
          {c.fullName?.split(' ').map(n=>n[0]).join('').slice(0,2)}
        </div>
        <div className="flex-1">
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold text-gray-900">{c.fullName}</h1>
            <span className={'text-xs px-2 py-0.5 rounded-full font-medium ' + statusColor(c.status)}>{c.status?.replace(/_/g,' ')}</span>
            {c.blacklisted && <span className="text-xs px-2 py-0.5 rounded-full font-medium bg-red-600 text-white">BLACKLISTED</span>}
          </div>
          <div className="flex flex-wrap gap-3 mt-1 text-sm text-gray-500">
            <span className="flex items-center gap-1"><Phone size={13} /> {c.phone}</span>
            {c.email && <span className="flex items-center gap-1"><Mail size={13} /> {c.email}</span>}
            <span className="flex items-center gap-1"><MapPin size={13} /> {c.currentLocation?.city || 'N/A'}</span>
            <span className="flex items-center gap-1"><FileText size={13} /> {c.candidateId}</span>
          </div>
        </div>
        <div className="flex gap-2">
          <div className={`text-center px-3 py-2 rounded-lg ${scoreColor(c.combinedScore)}`}>
            <div className="text-xl font-bold">{c.combinedScore || 0}</div>
            <div className="text-xs">Combined</div>
          </div>
          <div className="text-center px-3 py-2 rounded-lg bg-gray-50">
            <div className="text-xl font-bold text-gray-700">{c.interviewScore || 0}/60</div>
            <div className="text-xs text-gray-500">Interview</div>
          </div>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="flex flex-wrap gap-2">
        <button onClick={openEdit} className="btn-outline text-sm flex items-center gap-1"><Edit2 size={14} /> Edit Details</button>
        <button onClick={openStatus} className="btn-outline text-sm flex items-center gap-1"><ChevronDown size={14} /> Change Status</button>
        <button onClick={openAssign} className="btn-outline text-sm flex items-center gap-1"><UserCheck size={14} /> Assign Agent</button>
        <button onClick={openInterview} className="btn-outline text-sm flex items-center gap-1"><Calendar size={14} /> Schedule Interview</button>
        {['Interview_Done','Interview_Scheduled'].includes(c.status) && (
          <button onClick={openScore} className="btn-outline text-sm flex items-center gap-1"><Star size={14} /> Score Interview</button>
        )}
        {c.panelDecision === 'Selected' && !['Offered','Offer_Accepted'].includes(c.status) && (
          <button onClick={openOffer} className="btn-primary text-sm flex items-center gap-1"><Briefcase size={14} /> Create Offer</button>
        )}
        {c.status === 'Offered' && (
          <>
            <button onClick={acceptOffer} className="bg-green-600 hover:bg-green-700 text-white text-sm px-3 py-1.5 rounded-lg">Accept Offer</button>
            <button onClick={declineOffer} className="bg-red-500 hover:bg-red-600 text-white text-sm px-3 py-1.5 rounded-lg">Decline Offer</button>
          </>
        )}
        <button onClick={toggleBlacklist} className={`text-sm px-3 py-1.5 rounded-lg ${c.blacklisted ? 'bg-gray-200 text-gray-700 hover:bg-gray-300' : 'bg-red-50 text-red-600 hover:bg-red-100'}`}>
          {c.blacklisted ? 'Remove Blacklist' : 'Blacklist'}
        </button>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Left: Details */}
        <div className="lg:col-span-1 space-y-4">
          <div className="card">
            <h3 className="font-semibold text-gray-800 mb-3">Details</h3>
            <dl className="space-y-2 text-sm">
              {[
                ['Status', c.status?.replace(/_/g,' ')],
                ['Qualification', c.qualification?.replace(/_/g,' ')],
                ['Experience', (c.experienceYears || 0) + ' years'],
                ['Electrical Trade', c.electricalTrade ? 'Yes' : 'No'],
                ['Source', c.source?.replace(/_/g,' ')],
                ['Preferred Location', c.preferredLocation?.name || 'N/A'],
                ['Language', c.preferredLanguage === 'hi' ? 'Hindi' : 'English'],
                ['Panel Decision', c.panelDecision],
                ['Training', c.trainingStatus?.replace(/_/g,' ')],
                ['WhatsApp', c.whatsappStatus],
                ['Assigned To', c.assignedAgent?.name || 'Unassigned'],
                ['Team', c.assignedTeam || 'N/A'],
              ].map(([label, value]) => (
                <div key={label} className="flex justify-between">
                  <dt className="text-gray-500">{label}</dt>
                  <dd className="font-medium text-gray-800">{value || '-'}</dd>
                </div>
              ))}
            </dl>
          </div>

          {/* Offer Info */}
          {c.offerSalary && (
            <div className="card border-blue-200 bg-blue-50">
              <h3 className="font-semibold text-blue-800 mb-2">Offer Details</h3>
              <dl className="space-y-1.5 text-sm">
                <div className="flex justify-between"><dt className="text-blue-600">Salary</dt><dd className="font-bold text-blue-900">Rs. {c.offerSalary?.toLocaleString()}/month</dd></div>
                <div className="flex justify-between"><dt className="text-blue-600">Location</dt><dd className="font-medium">{c.offerLocation?.name || c.preferredLocation?.name || '-'}</dd></div>
                {c.offerJoiningDate && <div className="flex justify-between"><dt className="text-blue-600">Joining</dt><dd className="font-medium">{new Date(c.offerJoiningDate).toLocaleDateString('en-IN')}</dd></div>}
                {c.offerSentAt && <div className="flex justify-between"><dt className="text-blue-600">Sent</dt><dd>{new Date(c.offerSentAt).toLocaleDateString('en-IN')}</dd></div>}
                {c.offerAcceptedAt && <div className="flex justify-between"><dt className="text-green-600">Accepted</dt><dd className="text-green-700 font-bold">{new Date(c.offerAcceptedAt).toLocaleDateString('en-IN')}</dd></div>}
                {c.offerDeclinedAt && <div className="flex justify-between"><dt className="text-red-600">Declined</dt><dd className="text-red-700">{c.offerDeclineReason}</dd></div>}
              </dl>
            </div>
          )}

          {/* Interview Info */}
          {c.interviewScheduled && (
            <div className="card border-purple-200 bg-purple-50">
              <h3 className="font-semibold text-purple-800 mb-2">Interview</h3>
              <dl className="space-y-1.5 text-sm">
                <div className="flex justify-between"><dt className="text-purple-600">Date</dt><dd className="font-bold">{new Date(c.interviewScheduled).toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' })}</dd></div>
                <div className="flex justify-between"><dt className="text-purple-600">Type</dt><dd>{c.interviewType || '-'}</dd></div>
                <div className="flex justify-between"><dt className="text-purple-600">Interviewer</dt><dd>{c.interviewer?.name || '-'}</dd></div>
                {c.interviewLink && <div className="flex justify-between"><dt className="text-purple-600">Link</dt><dd><a href={c.interviewLink} target="_blank" className="text-blue-600 underline text-xs">Join</a></dd></div>}
              </dl>
            </div>
          )}

          {c.interviewScore > 0 && (
            <div className="card">
              <h3 className="font-semibold text-gray-800 mb-3">Interview Breakdown</h3>
              <div className="space-y-2">
                {[['Technical',c.interviewBreakdown?.technical],['Practical',c.interviewBreakdown?.practical],
                  ['Communication',c.interviewBreakdown?.communication],['Experience',c.interviewBreakdown?.experience],
                  ['Location',c.interviewBreakdown?.locationAvailability],['Quiz',c.interviewBreakdown?.quizNormalized]
                ].map(([label, val]) => (
                  <div key={label} className="flex items-center gap-2 text-sm">
                    <span className="w-28 text-gray-500">{label}</span>
                    <div className="flex-1 bg-gray-200 rounded-full h-2"><div className="bg-primary-500 h-2 rounded-full" style={{width:`${(val||0)*10}%`}}></div></div>
                    <span className="font-medium w-8 text-right">{val||0}/10</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Right: Timeline */}
        <div className="lg:col-span-2">
          <div className="card">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold text-gray-800">Unified Timeline</h3>
              <div className="flex gap-1">
                {['all','whatsapp','calls','notes','system'].map(f => (
                  <button key={f} onClick={() => setTimelineFilter(f)}
                    className={'text-xs px-2 py-1 rounded-full transition ' + (timelineFilter===f ? 'bg-primary-100 text-primary-700 font-medium' : 'text-gray-500 hover:bg-gray-100')}>
                    {f==='all' ? 'All' : f.charAt(0).toUpperCase()+f.slice(1)}
                  </button>
                ))}
              </div>
            </div>
            <div className="flex gap-2 mb-4">
              <input value={note} onChange={e=>setNote(e.target.value)} placeholder="Add a note..." className="input-field flex-1" onKeyDown={e=>e.key==='Enter'&&addNote()} />
              <button onClick={addNote} className="btn-primary flex items-center gap-1"><Send size={14} /> Add</button>
            </div>
            <div className="space-y-3 max-h-[600px] overflow-y-auto">
              {filteredTimeline.length === 0 ? (
                <div className="text-center text-gray-400 py-8">No timeline events yet</div>
              ) : filteredTimeline.map((event, i) => (
                <div key={event._id||i} className={'border-l-4 rounded-r-lg p-3 ' + (eventColors[event.eventType] || 'border-gray-300 bg-gray-50')}>
                  <div className="flex items-start justify-between">
                    <div className="flex items-start gap-2">
                      <span className="text-base">{eventIcons[event.eventType] || '📌'}</span>
                      <div>
                        <div className="text-sm text-gray-800">{event.content || event.eventType?.replace(/_/g,' ')}</div>
                        {event.callDuration > 0 && <div className="text-xs text-gray-500 mt-0.5">Duration: {Math.floor(event.callDuration/60)}m {event.callDuration%60}s</div>}
                        {event.oldStatus && <div className="text-xs text-gray-500 mt-0.5">{event.oldStatus} → {event.newStatus}</div>}
                      </div>
                    </div>
                    <div className="text-xs text-gray-400 whitespace-nowrap ml-2">
                      {new Date(event.createdAt).toLocaleString('en-IN', { dateStyle:'short', timeStyle:'short' })}
                    </div>
                  </div>
                  <div className="text-xs text-gray-400 mt-1 ml-7">by {event.createdByName || event.createdBy?.name || 'System'}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* ═══ MODALS ═══ */}

      {/* Edit Modal */}
      {editModal && (
        <Modal title="Edit Candidate Details" onClose={() => setEditModal(false)} onSave={saveEdit}>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Full Name *" value={editForm.fullName} onChange={v => setEditForm(f=>({...f, fullName:v}))} />
            <Field label="Phone *" value={editForm.phone} onChange={v => setEditForm(f=>({...f, phone:v}))} />
            <Field label="Alternate Phone" value={editForm.alternatePhone} onChange={v => setEditForm(f=>({...f, alternatePhone:v}))} />
            <Field label="Email" value={editForm.email} onChange={v => setEditForm(f=>({...f, email:v}))} type="email" />
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Qualification</label>
              <select value={editForm.qualification} onChange={e => setEditForm(f=>({...f, qualification:e.target.value}))} className="input-field">
                <option value="">Select</option>
                {QUALIFICATIONS.map(q => <option key={q.v} value={q.v}>{q.l}</option>)}
              </select>
            </div>
            <Field label="Experience (Years)" value={editForm.experienceYears} onChange={v => setEditForm(f=>({...f, experienceYears:v}))} type="number" />
            <Field label="Current City" value={editForm.currentCity} onChange={v => setEditForm(f=>({...f, currentCity:v}))} />
            <Field label="Current State" value={editForm.currentState} onChange={v => setEditForm(f=>({...f, currentState:v}))} />
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Preferred Location</label>
              <select value={editForm.preferredLocation} onChange={e => setEditForm(f=>({...f, preferredLocation:e.target.value}))} className="input-field">
                <option value="">Select</option>
                {locations.map(l => <option key={l._id} value={l._id}>{l.name} ({l.city})</option>)}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Gender</label>
              <select value={editForm.gender} onChange={e => setEditForm(f=>({...f, gender:e.target.value}))} className="input-field">
                <option value="">Select</option>
                <option value="Male">Male</option><option value="Female">Female</option><option value="Other">Other</option>
              </select>
            </div>
            <div className="col-span-2 flex items-center gap-2">
              <input type="checkbox" checked={editForm.electricalTrade} onChange={e => setEditForm(f=>({...f, electricalTrade:e.target.checked}))} className="rounded" id="et" />
              <label htmlFor="et" className="text-sm text-gray-700">Electrical Trade</label>
            </div>
          </div>
        </Modal>
      )}

      {/* Status Modal */}
      {statusModal && (
        <Modal title="Change Status" onClose={() => setStatusModal(false)} onSave={saveStatus}>
          <div className="space-y-3">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Current: <span className="font-bold">{c.status?.replace(/_/g,' ')}</span></label>
              <select value={statusForm.status} onChange={e => setStatusForm(f=>({...f, status:e.target.value}))} className="input-field">
                {ALL_STATUSES.map(s => <option key={s} value={s}>{s.replace(/_/g,' ')}</option>)}
              </select>
            </div>
            <Field label="Reason (optional)" value={statusForm.reason} onChange={v => setStatusForm(f=>({...f, reason:v}))} />
          </div>
        </Modal>
      )}

      {/* Assign Modal */}
      {assignModal && (
        <Modal title="Assign Agent & Team" onClose={() => setAssignModal(false)} onSave={saveAssign}>
          <div className="space-y-3">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Agent</label>
              <select value={assignForm.agent} onChange={e => setAssignForm(f=>({...f, agent:e.target.value}))} className="input-field">
                <option value="">Unassigned</option>
                {agents.map(a => <option key={a._id} value={a._id}>{a.name} ({a.role})</option>)}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Team</label>
              <select value={assignForm.team} onChange={e => setAssignForm(f=>({...f, team:e.target.value}))} className="input-field">
                <option value="">No Team</option>
                {['Alpha','Beta','Gamma','Delta'].map(t => <option key={t} value={t}>{t}</option>)}
              </select>
            </div>
          </div>
        </Modal>
      )}

      {/* Interview Modal */}
      {interviewModal && (
        <Modal title="Schedule Interview" onClose={() => setInterviewModal(false)} onSave={saveInterview}>
          <div className="space-y-3">
            <Field label="Date & Time *" value={interviewForm.date} onChange={v => setInterviewForm(f=>({...f, date:v}))} type="datetime-local" />
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Type</label>
              <select value={interviewForm.type} onChange={e => setInterviewForm(f=>({...f, type:e.target.value}))} className="input-field">
                <option value="virtual">Virtual (Video Call)</option>
                <option value="physical">Physical (In-Person)</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Interviewer</label>
              <select value={interviewForm.interviewer} onChange={e => setInterviewForm(f=>({...f, interviewer:e.target.value}))} className="input-field">
                <option value="">Select interviewer</option>
                {interviewers.map(u => <option key={u._id} value={u._id}>{u.name}</option>)}
              </select>
            </div>
            <Field label="Meeting Link (optional)" value={interviewForm.link} onChange={v => setInterviewForm(f=>({...f, link:v}))} placeholder="https://meet.google.com/..." />
          </div>
        </Modal>
      )}

      {/* Offer Modal */}
      {offerModal && (
        <Modal title="Create Offer" onClose={() => setOfferModal(false)} onSave={saveOffer}>
          <div className="space-y-3">
            <Field label="Monthly Salary (Rs.) *" value={offerForm.salary} onChange={v => setOfferForm(f=>({...f, salary:v}))} type="number" />
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Deployment Location *</label>
              <select value={offerForm.location} onChange={e => setOfferForm(f=>({...f, location:e.target.value}))} className="input-field">
                <option value="">Select location</option>
                {locations.map(l => <option key={l._id} value={l._id}>{l.name} ({l.city})</option>)}
              </select>
            </div>
            <Field label="Joining Date *" value={offerForm.joiningDate} onChange={v => setOfferForm(f=>({...f, joiningDate:v}))} type="date" />
            <div className="bg-blue-50 rounded-lg p-3 text-sm text-blue-700">
              Offer will expire in 72 hours. Candidate will be notified via WhatsApp (when connected).
            </div>
          </div>
        </Modal>
      )}

      {/* Score Interview Modal */}
      {scoreModal && (
        <Modal title="Score Interview" onClose={() => setScoreModal(false)} onSave={saveScore} wide>
          <div className="space-y-4">
            {[['technical','Technical Knowledge'],['practical','Practical Skills'],['communication','Communication'],
              ['experience','Relevant Experience'],['locationAvailability','Location/Availability'],['quizNormalized','Quiz Score (Normalized)']
            ].map(([key, label]) => (
              <div key={key} className="flex items-center gap-3">
                <label className="w-40 text-sm font-medium text-gray-700">{label}</label>
                <input type="range" min="0" max="10" value={scoreForm[key]} onChange={e => setScoreForm(f=>({...f,[key]:Number(e.target.value)}))}
                  className="flex-1 accent-primary-600" />
                <span className="w-12 text-center font-bold text-primary-700 bg-primary-50 rounded px-2 py-1">{scoreForm[key]}/10</span>
              </div>
            ))}
            <div className="pt-2 border-t">
              <div className="text-center text-lg font-bold text-primary-700">
                Total: {Object.entries(scoreForm).filter(([k])=>k!=='notes').reduce((s,[,v])=>s+Number(v),0)}/60
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Interview Notes</label>
              <textarea value={scoreForm.notes} onChange={e => setScoreForm(f=>({...f, notes:e.target.value}))} className="input-field" rows={3} placeholder="Key observations..." />
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
}

// ── Reusable Components ──
function Modal({ title, children, onClose, onSave, wide }) {
  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <div className={'bg-white rounded-xl shadow-xl w-full max-h-[90vh] overflow-y-auto ' + (wide ? 'max-w-lg' : 'max-w-md')}>
        <div className="flex items-center justify-between p-5 border-b">
          <h3 className="text-lg font-bold text-gray-900">{title}</h3>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600"><X size={20} /></button>
        </div>
        <div className="p-5">{children}</div>
        <div className="flex gap-3 justify-end p-5 border-t">
          <button onClick={onClose} className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 text-sm">Cancel</button>
          <button onClick={onSave} className="btn-primary py-2 text-sm"><Save size={14} className="inline mr-1" />Save</button>
        </div>
      </div>
    </div>
  );
}

function Field({ label, value, onChange, type = 'text', placeholder }) {
  return (
    <div>
      <label className="block text-sm font-medium text-gray-700 mb-1">{label}</label>
      <input type={type} value={value} onChange={e => onChange(e.target.value)} placeholder={placeholder} className="input-field" />
    </div>
  );
}
