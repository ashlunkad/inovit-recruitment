#!/bin/bash
echo "═══════════════════════════════════════════════════"
echo "  INOVIT — Batch 1: Score System Overhaul"
echo "═══════════════════════════════════════════════════"

DIR="$(cd "$(dirname "$0")" && pwd)"
cd /opt/inovit-recruitment

# 1. Backend: candidate controller with dual scoring
echo "📝 [1/8] Replacing candidateController (dual interview scoring)..."
cp "$DIR/candidateController.js" backend/src/controllers/

# 2. Backend: routes with new endpoints
echo "📝 [2/8] Replacing routes (score-personal + score-technical)..."
cp "$DIR/routes-index.js" backend/src/routes/index.js

# 3. Frontend: api.js with new endpoints
echo "📝 [3/8] Updating api.js..."
cp "$DIR/api.js" frontend/src/services/

# 4. Model: Ensure dual interview fields exist + fix combined score
echo "📝 [4/8] Updating Candidate model..."
node -e "
const fs = require('fs');
const file = 'backend/src/models/Candidate.js';
let c = fs.readFileSync(file, 'utf8');

// Add personalInterviewScore if missing
if (!c.includes('personalInterviewScore')) {
  c = c.replace(
    'interviewNotes: String,',
    'interviewNotes: String,\n  personalInterviewScore: { type: Number, min: 0, max: 24, default: 0 },\n  personalInterviewBreakdown: {\n    technical: { type: Number, default: 0, max: 4 },\n    practical: { type: Number, default: 0, max: 4 },\n    communication: { type: Number, default: 0, max: 4 },\n    experience: { type: Number, default: 0, max: 4 },\n    locationAvailability: { type: Number, default: 0, max: 4 },\n    teamLeading: { type: Number, default: 0, max: 4 },\n  },\n  personalInterviewNotes: String,\n  personalInterviewBy: { type: mongoose.Schema.Types.ObjectId, ref: \"User\" },\n  personalInterviewAt: Date,\n  technicalInterviewScore: { type: Number, min: 0, max: 24, default: 0 },\n  technicalInterviewBreakdown: {\n    technical: { type: Number, default: 0, max: 4 },\n    practical: { type: Number, default: 0, max: 4 },\n    communication: { type: Number, default: 0, max: 4 },\n    experience: { type: Number, default: 0, max: 4 },\n    locationAvailability: { type: Number, default: 0, max: 4 },\n    teamLeading: { type: Number, default: 0, max: 4 },\n  },\n  technicalInterviewNotes: String,\n  technicalInterviewBy: { type: mongoose.Schema.Types.ObjectId, ref: \"User\" },\n  technicalInterviewAt: Date,\n  technicalInterviewStatus: { type: String, enum: [\"pending\", \"scheduled\", \"done\", null], default: null },\n  recommendedLocation: { type: String },\n'
  );
  console.log('  Added dual interview fields');
}

// Fix combined score formula
c = c.replace(
  /const intNorm = .*?;(\s*\/\/.*)?/,
  'const totalInt = (this.personalInterviewScore || 0) + (this.technicalInterviewScore || 0) || (this.interviewScore || 0);\n  const intMax = totalInt > 24 ? 48 : 24; // Handle both old (/24) and new (/48) scores\n  const intNorm = totalInt ? (totalInt / intMax) * 100 : 0;'
);

fs.writeFileSync(file, c);
console.log('  Combined score formula updated');
"

# 5. Add Interview_Pending_Technical to constants
echo "📝 [5/8] Adding Interview_Pending_Technical status..."
node -e "
const fs = require('fs');
const file = 'backend/src/config/constants.js';
let c = fs.readFileSync(file, 'utf8');
if (!c.includes('Interview_Pending_Technical')) {
  c = c.replace(\"'Interview_Done',\", \"'Interview_Done', 'Interview_Pending_Technical',\");
  fs.writeFileSync(file, c);
  console.log('  Added Interview_Pending_Technical');
} else { console.log('  Already exists'); }
"

# 6. Fix team validation in User model
echo "📝 [6/8] Fixing User team validation..."
node -e "
const fs = require('fs');
const file = 'backend/src/models/User.js';
let c = fs.readFileSync(file, 'utf8');
// Make team accept null/empty
c = c.replace(
  /team: \{[^}]*\}/,
  'team: { type: String, default: null }'
);
fs.writeFileSync(file, c);
console.log('  Team field now accepts any value');
"

# 7. Update status tracker stage map
echo "📝 [7/8] Updating status tracker stage map..."
node -e "
const fs = require('fs');
const file = 'backend/src/controllers/walkinController.js';
let c = fs.readFileSync(file, 'utf8');

// Replace statusStageMap with 8-stage version
c = c.replace(
  /const statusStageMap = \{[\s\S]*?\};/,
  \`const statusStageMap = {
      'New': 0, 'Walk_In_Registered': 0, 'Contacted': 1, 'Interested': 1,
      'WhatsApp_Failed': 1, 'Not_Interested': 1, 'Unreachable': 1,
      'Screening': 2, 'Screened': 2, 'Portal_Applied': 2,
      'Interview_Scheduled': 3, 'Interview_Done': 3, 'Interview_Pending_Technical': 3,
      'Selected': 4, 'On_Hold': 4, 'Rejected': 4, 'Waitlisted': 4,
      'Offered': 5, 'Offer_Accepted': 5, 'Offer_Declined': 5,
      'Onboarding': 6,
      'Training': 7, 'Training_Completed': 7, 'Training_Failed': 7, 'Deployed': 7,
    };\`
);

// Update stages array to 8 stages
c = c.replace(
  /const stages = \[[\s\S]*?\];/,
  \`const stages = [
      { key: 'application', label: 'Application', icon: '📝' },
      { key: 'outreach', label: 'Outreach', icon: '📞' },
      { key: 'screening', label: 'Screening', icon: '🔍' },
      { key: 'interview', label: 'Interview', icon: '🎤' },
      { key: 'selection', label: 'Selection', icon: '✅' },
      { key: 'offer', label: 'Offer', icon: '📨' },
      { key: 'documents', label: 'Documents', icon: '📄' },
      { key: 'training', label: 'Training & Deploy', icon: '🚀' },
    ];\`
);

fs.writeFileSync(file, c);
console.log('  Updated to 8-stage lifecycle');
"

# 8. Build and restart
echo "🔨 [8/8] Building frontend + restarting..."
cd frontend && npm run build
pm2 restart all

echo ""
echo "═══════════════════════════════════════════════════"
echo "  ✅ Batch 1: Score System Overhaul INSTALLED!"
echo "═══════════════════════════════════════════════════"
echo ""
echo "Backend changes:"
echo "  • NEW: POST /candidates/:id/score-personal (Round 1)"
echo "  • NEW: POST /candidates/:id/score-technical (Round 2)"
echo "  • Score Personal → status: Interview_Pending_Technical"
echo "  • Score Technical → status: Interview_Done"
echo "  • Combined score: (personal+technical)/48 * 100 * 0.5"
echo "  • Deploy action auto-increments location.deployed"
echo "  • Team validation: accepts empty/null"
echo "  • Status tracker: 8 stages"
echo ""
echo "Frontend changes:"
echo "  • api.js: scorePersonalInterview() + scoreTechnicalInterview()"
echo "  • candidateAPI.getOfferPDF() for PDF download"
echo "  • documentAPI for document management"
echo ""
echo "NOTE: CandidateDetail.jsx and Interviews.jsx still need"
echo "UI updates to show dual score buttons. That's in Batch 1b."
echo ""
pm2 status
