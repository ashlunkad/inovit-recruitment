#!/bin/bash
echo "═══════════════════════════════════════════"
echo "  INOVIT — Import Fix Installer"
echo "═══════════════════════════════════════════"

DIR="$(cd "$(dirname "$0")" && pwd)"
cd /opt/inovit-recruitment

echo "📝 [1/5] Updating import controller (source name + external code + phone fix + gender fix)..."
cp "$DIR/importController.js" backend/src/controllers/

echo "📝 [2/5] Updating ImportData page (source name input)..."
cp "$DIR/ImportData.jsx" frontend/src/pages/

echo "📝 [3/5] Adding externalCode field to Candidate model..."
# Add externalCode field after sourceDetail field
sed -i '/sourceDetail: String/a\  externalCode: { type: String, index: true }, // Original ID from source database' backend/src/models/Candidate.js

echo "📝 [4/5] Adding sourceName field to ImportBatch model..."
sed -i '/status: .mapping/i\  sourceName: String,' backend/src/models/ImportBatch.js 2>/dev/null

echo "📝 [4.5/5] Fixing referral code collision (longer random)..."
sed -i "s/Math.floor(1000 + Math.random() \* 9000)/Math.floor(100000 + Math.random() * 900000)/" backend/src/models/Candidate.js

echo "🔨 [5/5] Building frontend + restarting..."
cd frontend && npm run build
pm2 restart all

echo ""
echo "═══════════════════════════════════════════"
echo "  ✅ Import Fix INSTALLED!"
echo "═══════════════════════════════════════════"
echo ""
echo "Changes:"
echo "  • Import now asks for 'Database/Source Name' (required)"
echo "  • New mappable field: 'External ID / Unique Code'"
echo "  • Phone .0 decimal fix (Excel numbers)"
echo "  • Gender auto-capitalization (male → Male)"
echo "  • Referral code collision fix (6-digit random)"
echo "  • Duplicate external codes update existing records"
echo ""
pm2 status
