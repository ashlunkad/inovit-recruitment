import { useState, useEffect } from 'react';
import { candidateAPI } from '../services/api';
import { useNavigate } from 'react-router-dom';
import { Calendar, Clock, Video, MapPin, User, Star } from 'lucide-react';

export default function Interviews() {
  const [interviews, setInterviews] = useState([]);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState('upcoming'); // upcoming, today, done
  const navigate = useNavigate();

  const fetchData = async () => {
    setLoading(true);
    try {
      const statuses = tab === 'done' ? 'Interview_Done' : 'Interview_Scheduled';
      const res = await candidateAPI.getAll({ status: statuses, limit: 100, sort: tab === 'done' ? '-updatedAt' : 'interviewScheduled' });
      let data = res.data.candidates || [];

      if (tab === 'today') {
        const today = new Date().toISOString().slice(0, 10);
        data = data.filter(c => c.interviewScheduled && c.interviewScheduled.slice(0, 10) === today);
      } else if (tab === 'upcoming') {
        const now = new Date().toISOString();
        data = data.filter(c => c.interviewScheduled && c.interviewScheduled >= now);
      }

      setInterviews(data);
    } catch (err) { console.error(err); }
    finally { setLoading(false); }
  };

  useEffect(() => { fetchData(); }, [tab]);

  const scoreColor = (s) => s >= 80 ? 'text-green-600 bg-green-50' : s >= 60 ? 'text-blue-600 bg-blue-50' : s >= 40 ? 'text-yellow-600 bg-yellow-50' : 'text-red-500 bg-red-50';

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-gray-900">Interviews</h1>
        <div className="text-sm text-gray-500">{interviews.length} interviews</div>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 bg-gray-100 p-1 rounded-lg w-fit">
        {[{ key: 'today', label: 'Today' }, { key: 'upcoming', label: 'Upcoming' }, { key: 'done', label: 'Completed' }].map(t => (
          <button key={t.key} onClick={() => setTab(t.key)}
            className={'px-4 py-2 text-sm rounded-md transition ' + (tab === t.key ? 'bg-white text-primary-700 font-medium shadow-sm' : 'text-gray-500 hover:text-gray-700')}>
            {t.label}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="flex justify-center py-12"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary-600"></div></div>
      ) : interviews.length === 0 ? (
        <div className="card text-center py-12 text-gray-400">
          <Calendar size={48} className="mx-auto mb-3 text-gray-300" />
          <p>No {tab === 'today' ? "interviews scheduled for today" : tab === 'upcoming' ? "upcoming interviews" : "completed interviews"}</p>
        </div>
      ) : (
        <div className="space-y-3">
          {interviews.map(c => {
            const dt = c.interviewScheduled ? new Date(c.interviewScheduled) : null;
            const isToday = dt && dt.toDateString() === new Date().toDateString();
            const isPast = dt && dt < new Date();

            return (
              <div key={c._id} onClick={() => navigate('/candidates/' + c._id)}
                className={'card !p-4 cursor-pointer hover:shadow-md transition border-l-4 ' +
                  (isToday ? 'border-l-orange-400' : isPast ? 'border-l-gray-300' : 'border-l-blue-400')}>
                <div className="flex flex-col md:flex-row md:items-center gap-4">
                  {/* Time */}
                  <div className="md:w-32 text-center">
                    {dt ? (
                      <>
                        <div className={'text-lg font-bold ' + (isToday ? 'text-orange-600' : 'text-gray-700')}>
                          {dt.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })}
                        </div>
                        <div className="text-xs text-gray-400">
                          {isToday ? 'Today' : dt.toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })}
                        </div>
                      </>
                    ) : <div className="text-sm text-gray-400">Not set</div>}
                  </div>

                  {/* Candidate Info */}
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <h3 className="font-semibold text-gray-900">{c.fullName}</h3>
                      <span className="text-xs text-gray-400">{c.candidateId}</span>
                    </div>
                    <div className="flex flex-wrap gap-3 mt-1 text-xs text-gray-500">
                      <span>{c.qualification?.replace(/_/g, ' ')}</span>
                      <span>{c.experienceYears}yr exp</span>
                      <span>{c.currentLocation?.city || '-'}</span>
                      {c.preferredLocation?.name && <span className="flex items-center gap-0.5"><MapPin size={10} /> {c.preferredLocation.name}</span>}
                    </div>
                  </div>

                  {/* Interview Type */}
                  <div className="flex items-center gap-2">
                    {c.interviewType === 'virtual' ? (
                      <span className="badge bg-blue-100 text-blue-700 text-xs flex items-center gap-1"><Video size={12} /> Virtual</span>
                    ) : c.interviewType === 'physical' ? (
                      <span className="badge bg-green-100 text-green-700 text-xs flex items-center gap-1"><MapPin size={12} /> Physical</span>
                    ) : (
                      <span className="badge bg-gray-100 text-gray-600 text-xs">TBD</span>
                    )}
                  </div>

                  {/* Interviewer */}
                  <div className="md:w-32 text-sm text-gray-600">
                    {c.interviewer?.name ? (
                      <span className="flex items-center gap-1"><User size={13} /> {c.interviewer.name}</span>
                    ) : <span className="text-red-400 text-xs">No interviewer</span>}
                  </div>

                  {/* Score (if done) */}
                  {tab === 'done' && c.interviewScore > 0 && (
                    <div className={'text-center px-3 py-1 rounded-lg ' + scoreColor(c.combinedScore)}>
                      <div className="text-lg font-bold">{c.interviewScore}/60</div>
                      <div className="text-xs">Score</div>
                    </div>
                  )}

                  {/* Link */}
                  {c.interviewLink && tab !== 'done' && (
                    <a href={c.interviewLink} target="_blank" rel="noopener noreferrer"
                      onClick={e => e.stopPropagation()}
                      className="bg-blue-600 text-white text-xs px-3 py-1.5 rounded-lg hover:bg-blue-700 flex items-center gap-1">
                      <Video size={12} /> Join
                    </a>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
