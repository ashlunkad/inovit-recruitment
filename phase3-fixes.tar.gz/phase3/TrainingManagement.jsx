import { useState, useEffect } from 'react';
import { candidateAPI } from '../services/api';
import api from '../services/api';
import toast from 'react-hot-toast';
import { useNavigate } from 'react-router-dom';
import { GraduationCap, Check, X as XIcon, Clock, Users, Calendar } from 'lucide-react';

export default function TrainingManagement() {
  const [candidates, setCandidates] = useState([]);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState('pending'); // pending, in_training, completed, failed
  const [attendanceModal, setAttendanceModal] = useState(null);
  const [scoreModal, setScoreModal] = useState(null);
  const navigate = useNavigate();

  const fetchData = async () => {
    setLoading(true);
    try {
      let statuses = [];
      if (tab === 'pending') statuses = ['Offer_Accepted', 'Onboarding'];
      else if (tab === 'in_training') statuses = ['Training'];
      else if (tab === 'completed') statuses = ['Training_Completed'];
      else statuses = ['Training_Failed'];

      const res = await candidateAPI.getAll({ status: statuses, limit: 200, sort: '-updatedAt' });
      setCandidates(res.data.candidates || []);
    } catch (err) { console.error(err); }
    finally { setLoading(false); }
  };

  useEffect(() => { fetchData(); }, [tab]);

  // Start training
  const startTraining = async (id) => {
    try {
      await candidateAPI.update(id, { status: 'Training', trainingStatus: 'Day1', statusChangeReason: 'Training started' });
      toast.success('Training started');
      fetchData();
    } catch { toast.error('Failed'); }
  };

  // Mark attendance
  const saveAttendance = async () => {
    if (!attendanceModal) return;
    try {
      await candidateAPI.update(attendanceModal._id, {
        trainingAttendance: attendanceModal.attendance,
        trainingStatus: attendanceModal.attendance.day3 ? 'Day3' : attendanceModal.attendance.day2 ? 'Day2' : 'Day1'
      });
      toast.success('Attendance updated');
      setAttendanceModal(null);
      fetchData();
    } catch { toast.error('Failed'); }
  };

  // Save training score
  const saveTrainingScore = async () => {
    if (!scoreModal) return;
    try {
      const passed = scoreModal.scores.safetyQuiz >= 70 && scoreModal.scores.practicalFinal === 'pass' && scoreModal.scores.writtenFinal >= 60;
      await candidateAPI.update(scoreModal._id, {
        trainingScores: scoreModal.scores,
        trainingStatus: passed ? 'Completed' : 'Failed',
        status: passed ? 'Training_Completed' : 'Training_Failed',
        statusChangeReason: passed ? 'Training completed - all assessments passed' : 'Training failed - did not meet minimum scores'
      });
      toast.success(passed ? 'Training PASSED!' : 'Training FAILED');
      setScoreModal(null);
      fetchData();
    } catch { toast.error('Failed'); }
  };

  const stats = {
    pending: 0, inTraining: 0, completed: 0, failed: 0
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-gray-900">Training Management</h1>
        <span className="text-sm text-gray-500">{candidates.length} candidates</span>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 bg-gray-100 p-1 rounded-lg w-fit">
        {[{ key:'pending', label:'Ready for Training', icon: Clock },
          { key:'in_training', label:'In Training', icon: GraduationCap },
          { key:'completed', label:'Completed', icon: Check },
          { key:'failed', label:'Failed', icon: XIcon },
        ].map(t => (
          <button key={t.key} onClick={() => setTab(t.key)}
            className={'px-4 py-2 text-sm rounded-md transition flex items-center gap-1 ' + (tab === t.key ? 'bg-white text-primary-700 font-medium shadow-sm' : 'text-gray-500 hover:text-gray-700')}>
            <t.icon size={14} /> {t.label}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="flex justify-center py-12"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary-600"></div></div>
      ) : candidates.length === 0 ? (
        <div className="card text-center py-12 text-gray-400">
          <GraduationCap size={48} className="mx-auto mb-3 text-gray-300" />
          <p>No candidates in this category</p>
        </div>
      ) : (
        <div className="bg-white rounded-xl shadow-sm border overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-gray-50 border-b">
              <tr>
                <th className="px-4 py-3 text-left font-medium text-gray-500">Candidate</th>
                <th className="px-4 py-3 text-left font-medium text-gray-500">Location</th>
                <th className="px-4 py-3 text-center font-medium text-gray-500">Day 1</th>
                <th className="px-4 py-3 text-center font-medium text-gray-500">Day 2</th>
                <th className="px-4 py-3 text-center font-medium text-gray-500">Day 3</th>
                {(tab === 'completed' || tab === 'failed' || tab === 'in_training') && (
                  <>
                    <th className="px-4 py-3 text-center font-medium text-gray-500">Safety Quiz</th>
                    <th className="px-4 py-3 text-center font-medium text-gray-500">Written</th>
                    <th className="px-4 py-3 text-center font-medium text-gray-500">Practical</th>
                  </>
                )}
                <th className="px-4 py-3 text-center font-medium text-gray-500">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {candidates.map(c => {
                const att = c.trainingAttendance || {};
                const scores = c.trainingScores || {};
                return (
                  <tr key={c._id} className="hover:bg-gray-50">
                    <td className="px-4 py-3 cursor-pointer" onClick={() => navigate('/candidates/' + c._id)}>
                      <div className="font-medium text-gray-900">{c.fullName}</div>
                      <div className="text-xs text-gray-400">{c.candidateId} • {c.qualification?.replace(/_/g,' ')}</div>
                    </td>
                    <td className="px-4 py-3 text-xs text-gray-600">{c.preferredLocation?.name || c.offerLocation?.name || '-'}</td>
                    <td className="px-4 py-3 text-center">{att.day1 ? <span className="text-green-600 font-bold">✓</span> : <span className="text-gray-300">—</span>}</td>
                    <td className="px-4 py-3 text-center">{att.day2 ? <span className="text-green-600 font-bold">✓</span> : <span className="text-gray-300">—</span>}</td>
                    <td className="px-4 py-3 text-center">{att.day3 ? <span className="text-green-600 font-bold">✓</span> : <span className="text-gray-300">—</span>}</td>
                    {(tab === 'completed' || tab === 'failed' || tab === 'in_training') && (
                      <>
                        <td className="px-4 py-3 text-center"><span className={scores.safetyQuiz >= 70 ? 'text-green-600 font-bold' : 'text-red-500'}>{scores.safetyQuiz || '-'}</span></td>
                        <td className="px-4 py-3 text-center"><span className={scores.writtenFinal >= 60 ? 'text-green-600 font-bold' : 'text-red-500'}>{scores.writtenFinal || '-'}</span></td>
                        <td className="px-4 py-3 text-center"><span className={scores.practicalFinal === 'pass' ? 'text-green-600 font-bold' : scores.practicalFinal === 'fail' ? 'text-red-500' : 'text-gray-400'}>{scores.practicalFinal || '-'}</span></td>
                      </>
                    )}
                    <td className="px-4 py-3 text-center">
                      <div className="flex items-center justify-center gap-1">
                        {tab === 'pending' && (
                          <button onClick={() => startTraining(c._id)} className="bg-green-600 text-white text-xs px-3 py-1 rounded-lg hover:bg-green-700">Start Training</button>
                        )}
                        {tab === 'in_training' && (
                          <>
                            <button onClick={() => setAttendanceModal({ _id: c._id, name: c.fullName, attendance: { day1: att.day1||false, day2: att.day2||false, day3: att.day3||false } })}
                              className="bg-blue-600 text-white text-xs px-2 py-1 rounded-lg hover:bg-blue-700">Attendance</button>
                            <button onClick={() => setScoreModal({ _id: c._id, name: c.fullName, scores: { safetyQuiz: scores.safetyQuiz||0, practicalDay2: scores.practicalDay2||'', writtenFinal: scores.writtenFinal||0, practicalFinal: scores.practicalFinal||'' } })}
                              className="bg-purple-600 text-white text-xs px-2 py-1 rounded-lg hover:bg-purple-700">Score</button>
                          </>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {/* Attendance Modal */}
      {attendanceModal && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-sm w-full p-6">
            <h3 className="text-lg font-bold text-gray-900 mb-4">Attendance — {attendanceModal.name}</h3>
            <div className="space-y-3">
              {['day1','day2','day3'].map((day, i) => (
                <label key={day} className="flex items-center gap-3 p-3 rounded-lg border cursor-pointer hover:bg-gray-50">
                  <input type="checkbox" checked={attendanceModal.attendance[day]}
                    onChange={e => setAttendanceModal(m => ({...m, attendance: {...m.attendance, [day]: e.target.checked}}))}
                    className="rounded w-5 h-5" />
                  <div>
                    <div className="font-medium text-gray-800">Day {i+1}</div>
                    <div className="text-xs text-gray-400">{['Safety + Orientation','Practical Training','Final Assessment'][i]}</div>
                  </div>
                </label>
              ))}
            </div>
            <div className="flex gap-3 justify-end mt-4">
              <button onClick={() => setAttendanceModal(null)} className="btn-outline text-sm">Cancel</button>
              <button onClick={saveAttendance} className="btn-primary text-sm">Save Attendance</button>
            </div>
          </div>
        </div>
      )}

      {/* Score Modal */}
      {scoreModal && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full p-6">
            <h3 className="text-lg font-bold text-gray-900 mb-4">Training Scores — {scoreModal.name}</h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Safety Quiz (0-100, pass: 70+)</label>
                <input type="number" value={scoreModal.scores.safetyQuiz}
                  onChange={e => setScoreModal(m => ({...m, scores: {...m.scores, safetyQuiz: Number(e.target.value)}}))}
                  className="input-field" min={0} max={100} />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Day 2 Practical</label>
                <select value={scoreModal.scores.practicalDay2}
                  onChange={e => setScoreModal(m => ({...m, scores: {...m.scores, practicalDay2: e.target.value}}))}
                  className="input-field">
                  <option value="">Not assessed</option>
                  <option value="pass">Pass</option><option value="fail">Fail</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Written Final (0-100, pass: 60+)</label>
                <input type="number" value={scoreModal.scores.writtenFinal}
                  onChange={e => setScoreModal(m => ({...m, scores: {...m.scores, writtenFinal: Number(e.target.value)}}))}
                  className="input-field" min={0} max={100} />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Practical Final</label>
                <select value={scoreModal.scores.practicalFinal}
                  onChange={e => setScoreModal(m => ({...m, scores: {...m.scores, practicalFinal: e.target.value}}))}
                  className="input-field">
                  <option value="">Not assessed</option>
                  <option value="pass">Pass</option><option value="fail">Fail</option>
                </select>
              </div>
              <div className="bg-gray-50 rounded-lg p-3 text-xs text-gray-500">
                Pass criteria: Safety Quiz ≥ 70, Written Final ≥ 60, Practical Final = Pass. All three required to pass training.
              </div>
            </div>
            <div className="flex gap-3 justify-end mt-4">
              <button onClick={() => setScoreModal(null)} className="btn-outline text-sm">Cancel</button>
              <button onClick={saveTrainingScore} className="btn-primary text-sm">Submit Scores</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
