#!/bin/bash
echo "═══════════════════════════════════════════"
echo "  INOVIT Phase 3 — MEDIUM Priority Installer"
echo "═══════════════════════════════════════════"

DIR="$(cd "$(dirname "$0")" && pwd)"
cd /opt/inovit-recruitment

echo "📝 [1/8] Adding Analytics page..."
cp "$DIR/Analytics.jsx" frontend/src/pages/

echo "📝 [2/8] Adding Interviews page..."
cp "$DIR/Interviews.jsx" frontend/src/pages/

echo "📝 [3/8] Adding Training Management page..."
cp "$DIR/TrainingManagement.jsx" frontend/src/pages/

echo "📝 [4/8] Updating Locations (edit + deactivate)..."
cp "$DIR/Locations.jsx" frontend/src/pages/

echo "📝 [5/8] Updating App.jsx (new routes)..."
cp "$DIR/App.jsx" frontend/src/

echo "📝 [6/8] Updating Layout.jsx (new nav items)..."
cp "$DIR/Layout.jsx" frontend/src/components/layout/

echo "🔨 [7/8] Building frontend..."
cd frontend && npm run build

echo "🔄 [8/8] Restarting services..."
pm2 restart all

echo ""
echo "═══════════════════════════════════════════"
echo "  ✅ Phase 3 INSTALLED!"
echo "═══════════════════════════════════════════"
echo ""
echo "New pages in sidebar:"
echo "  • Interviews — Today/Upcoming/Completed interviews"
echo "  • Training — Start training, attendance, scoring"
echo "  • Analytics — Conversion funnel, pipeline chart,"
echo "                source distribution, agent performance"
echo ""
echo "Updated pages:"
echo "  • Locations — Edit button + Deactivate toggle"
echo "                + Supervisor name/phone fields"
echo ""
pm2 status
