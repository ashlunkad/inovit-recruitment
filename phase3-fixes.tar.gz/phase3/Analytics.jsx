import { useState, useEffect } from 'react';
import { candidateAPI, authAPI } from '../services/api';
import api from '../services/api';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Legend, PieChart, Pie, Cell, LineChart, Line } from 'recharts';
import { TrendingUp, Users, Target, Zap, Calendar } from 'lucide-react';

const COLORS = ['#2E86C1','#27AE60','#E67E22','#E74C3C','#8E44AD','#1ABC9C','#F39C12','#3498DB','#D35400','#2C3E50'];
const FUNNEL_STAGES = [
  { key: 'total', label: 'Total Candidates', color: '#3498DB' },
  { key: 'contacted', label: 'Contacted', color: '#2E86C1' },
  { key: 'interested', label: 'Interested', color: '#27AE60' },
  { key: 'interviewed', label: 'Interviewed', color: '#8E44AD' },
  { key: 'selected', label: 'Selected', color: '#E67E22' },
  { key: 'offered', label: 'Offered', color: '#F39C12' },
  { key: 'accepted', label: 'Accepted', color: '#1ABC9C' },
  { key: 'deployed', label: 'Deployed', color: '#27AE60' },
];

export default function Analytics() {
  const [pipeline, setPipeline] = useState([]);
  const [sources, setSources] = useState([]);
  const [agents, setAgents] = useState([]);
  const [funnel, setFunnel] = useState([]);
  const [loading, setLoading] = useState(true);
  const [dateRange, setDateRange] = useState({ from: '', to: '' });

  const fetchData = async () => {
    setLoading(true);
    try {
      const [statsRes, usersRes] = await Promise.all([
        candidateAPI.getPipelineStats(),
        authAPI.getUsers()
      ]);

      const pipelineData = statsRes.data.pipeline || [];
      const sourceData = statsRes.data.sources || [];
      setPipeline(pipelineData);
      setSources(sourceData);

      // Build funnel
      const statusMap = {};
      pipelineData.forEach(p => { statusMap[p._id] = p.count; });
      const total = statsRes.data.summary?.total || 0;
      const funnelData = [
        { stage: 'Total', count: total, pct: 100 },
        { stage: 'Contacted', count: (statusMap['Contacted']||0)+(statusMap['Interested']||0)+(statusMap['Screening']||0)+(statusMap['Interview_Scheduled']||0)+(statusMap['Interview_Done']||0)+(statusMap['Selected']||0)+(statusMap['Offered']||0)+(statusMap['Offer_Accepted']||0)+(statusMap['Training']||0)+(statusMap['Deployed']||0), pct: 0 },
        { stage: 'Interested', count: (statusMap['Interested']||0)+(statusMap['Screening']||0)+(statusMap['Interview_Scheduled']||0)+(statusMap['Interview_Done']||0)+(statusMap['Selected']||0)+(statusMap['Offered']||0)+(statusMap['Offer_Accepted']||0)+(statusMap['Training']||0)+(statusMap['Deployed']||0), pct: 0 },
        { stage: 'Interviewed', count: (statusMap['Interview_Done']||0)+(statusMap['Selected']||0)+(statusMap['Offered']||0)+(statusMap['Offer_Accepted']||0)+(statusMap['Training']||0)+(statusMap['Deployed']||0), pct: 0 },
        { stage: 'Selected', count: (statusMap['Selected']||0)+(statusMap['Offered']||0)+(statusMap['Offer_Accepted']||0)+(statusMap['Training']||0)+(statusMap['Deployed']||0), pct: 0 },
        { stage: 'Offered', count: (statusMap['Offered']||0)+(statusMap['Offer_Accepted']||0)+(statusMap['Training']||0)+(statusMap['Deployed']||0), pct: 0 },
        { stage: 'Accepted', count: (statusMap['Offer_Accepted']||0)+(statusMap['Training']||0)+(statusMap['Deployed']||0), pct: 0 },
        { stage: 'Deployed', count: statusMap['Deployed']||0, pct: 0 },
      ];
      funnelData.forEach(f => { f.pct = total > 0 ? Math.round((f.count/total)*100) : 0; });
      setFunnel(funnelData);

      // Agent performance
      const users = usersRes.data.users || [];
      const agentUsers = users.filter(u => ['agent','team_lead','telecaller'].includes(u.role));
      const agentStats = [];
      for (const u of agentUsers.slice(0, 10)) {
        try {
          const candRes = await api.get('/candidates', { params: { agent: u._id, limit: 1 } });
          const callRes = await api.get('/calls/stats/' + u._id);
          agentStats.push({
            name: u.name, role: u.role, team: u.team,
            candidates: candRes.data.pagination?.total || 0,
            callsToday: callRes.data.todayCalls || 0,
            connectRate: callRes.data.connectRate || 0,
          });
        } catch { agentStats.push({ name: u.name, role: u.role, team: u.team, candidates: 0, callsToday: 0, connectRate: 0 }); }
      }
      setAgents(agentStats);
    } catch (err) { console.error(err); }
    finally { setLoading(false); }
  };

  useEffect(() => { fetchData(); }, []);

  if (loading) return <div className="flex items-center justify-center h-64"><div className="animate-spin rounded-full h-10 w-10 border-b-2 border-primary-600"></div></div>;

  const sourceChart = sources.map((s,i) => ({ name: s._id || 'Unknown', value: s.count, fill: COLORS[i%COLORS.length] }));
  const pipelineChart = pipeline.filter(p => p.count > 0).map(p => ({ name: (p._id||'').replace(/_/g,' '), count: p.count })).sort((a,b) => b.count - a.count);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-gray-900">Analytics & Reports</h1>
        <button onClick={fetchData} className="btn-outline text-sm flex items-center gap-1"><TrendingUp size={14} /> Refresh</button>
      </div>

      {/* Conversion Funnel */}
      <div className="card">
        <h2 className="text-lg font-semibold text-gray-800 mb-4">Conversion Funnel</h2>
        <div className="space-y-3">
          {funnel.map((f, i) => (
            <div key={f.stage} className="flex items-center gap-3">
              <div className="w-24 text-sm font-medium text-gray-600 text-right">{f.stage}</div>
              <div className="flex-1 relative">
                <div className="bg-gray-100 rounded-full h-8">
                  <div className="h-8 rounded-full flex items-center justify-end pr-3 transition-all duration-500"
                    style={{ width: Math.max(f.pct, 5) + '%', backgroundColor: FUNNEL_STAGES[i]?.color || '#999' }}>
                    <span className="text-white text-xs font-bold">{f.count}</span>
                  </div>
                </div>
              </div>
              <div className="w-12 text-right text-sm font-bold" style={{ color: FUNNEL_STAGES[i]?.color }}>{f.pct}%</div>
            </div>
          ))}
        </div>
        <div className="mt-4 pt-4 border-t flex flex-wrap gap-4 text-sm text-gray-500">
          <span>Total → Deployed: <b className="text-green-600">{funnel.length > 0 ? funnel[funnel.length-1].pct : 0}%</b></span>
          <span>Total → Selected: <b className="text-blue-600">{funnel.find(f=>f.stage==='Selected')?.pct||0}%</b></span>
          <span>Interviewed → Selected: <b className="text-purple-600">{funnel.find(f=>f.stage==='Interviewed')?.count > 0 ? Math.round((funnel.find(f=>f.stage==='Selected')?.count||0)/(funnel.find(f=>f.stage==='Interviewed')?.count)*100) : 0}%</b></span>
        </div>
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        {/* Pipeline Distribution */}
        <div className="card">
          <h2 className="text-lg font-semibold text-gray-800 mb-4">Pipeline Distribution</h2>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={pipelineChart} layout="vertical" margin={{ left: 80 }}>
              <XAxis type="number" tick={{ fontSize: 11 }} />
              <YAxis dataKey="name" type="category" tick={{ fontSize: 11 }} width={80} />
              <Tooltip />
              <Bar dataKey="count" fill="#2E86C1" radius={[0,4,4,0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Source Effectiveness */}
        <div className="card">
          <h2 className="text-lg font-semibold text-gray-800 mb-4">Source Distribution</h2>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie data={sourceChart} cx="50%" cy="50%" outerRadius={100} dataKey="value" label={({name,value}) => name + ': ' + value}>
                {sourceChart.map((e,i) => <Cell key={i} fill={e.fill} />)}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Agent Performance */}
      <div className="card">
        <h2 className="text-lg font-semibold text-gray-800 mb-4">Agent Performance</h2>
        {agents.length === 0 ? (
          <p className="text-gray-400 text-center py-6">No agent data available</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-gray-50 border-b">
                <tr>
                  <th className="px-4 py-3 text-left font-medium text-gray-500">Agent</th>
                  <th className="px-4 py-3 text-left font-medium text-gray-500">Role</th>
                  <th className="px-4 py-3 text-left font-medium text-gray-500">Team</th>
                  <th className="px-4 py-3 text-center font-medium text-gray-500">Candidates</th>
                  <th className="px-4 py-3 text-center font-medium text-gray-500">Calls Today</th>
                  <th className="px-4 py-3 text-center font-medium text-gray-500">Connect Rate</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {agents.map((a,i) => (
                  <tr key={i} className="hover:bg-gray-50">
                    <td className="px-4 py-3 font-medium text-gray-900">{a.name}</td>
                    <td className="px-4 py-3 text-xs"><span className="badge bg-gray-100 text-gray-600">{a.role}</span></td>
                    <td className="px-4 py-3 text-gray-600">{a.team || '-'}</td>
                    <td className="px-4 py-3 text-center font-bold">{a.candidates}</td>
                    <td className="px-4 py-3 text-center">{a.callsToday}</td>
                    <td className="px-4 py-3 text-center">
                      <span className={'font-bold ' + (a.connectRate >= 50 ? 'text-green-600' : a.connectRate >= 30 ? 'text-yellow-600' : 'text-red-500')}>{a.connectRate}%</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
