import { useState, useEffect } from 'react';
import { candidateAPI, authAPI } from '../services/api';
import api from '../services/api';
import { useAuth } from '../context/AuthContext';
import { useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import { Calendar, Clock, Video, MapPin, User, Star, X, Save, Phone, FileText, AlertTriangle, RotateCcw, ChevronLeft, ChevronRight } from 'lucide-react';

const O = '#E67E22';
const G = '#4A4A4A';
const SCORE_COLORS = {1:'bg-red-100 text-red-700 border-red-300',2:'bg-yellow-100 text-yellow-700 border-yellow-300',3:'bg-blue-100 text-blue-700 border-blue-300',4:'bg-green-100 text-green-700 border-green-300'};

// Generate 5-min slots from 9AM to 8PM IST
function generateSlots() {
  const slots = [];
  for (let h = 9; h < 20; h++) {
    for (let m = 0; m < 60; m += 5) {
      const hour12 = h > 12 ? h - 12 : h === 0 ? 12 : h;
      const ampm = h >= 12 ? 'PM' : 'AM';
      const label = `${hour12}:${String(m).padStart(2,'0')} ${ampm}`;
      const value = `${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}`;
      slots.push({ label, value, hour: h, minute: m });
    }
  }
  return slots;
}
const TIME_SLOTS = generateSlots();

const toIST = (d) => d ? new Date(d).toLocaleString('en-IN',{hour:'2-digit',minute:'2-digit',hour12:true,timeZone:'Asia/Kolkata'}) : '';
const toISTFull = (d) => d ? new Date(d).toLocaleString('en-IN',{dateStyle:'medium',timeStyle:'short',timeZone:'Asia/Kolkata'}) : '-';
const todayIST = () => { const d = new Date(); return d.toLocaleDateString('en-CA', {timeZone:'Asia/Kolkata'}); };

export default function Interviews() {
  const { user } = useAuth();
  const [tab, setTab] = useState('calendar');
  const [interviews, setInterviews] = useState([]);
  const [loading, setLoading] = useState(true);
  const [calDate, setCalDate] = useState(todayIST());
  const [calSlots, setCalSlots] = useState([]);
  const [calInterviewer, setCalInterviewer] = useState('');
  const [interviewers, setInterviewers] = useState([]);
  const [scoreModal, setScoreModal] = useState(null);
  const [profileModal, setProfileModal] = useState(null);
  const [rescheduleModal, setRescheduleModal] = useState(null);
  const [scoreForm, setScoreForm] = useState({technical:0,practical:0,communication:0,experience:0,locationAvailability:0,teamLeading:0,notes:'',recommendedLocation:''});
  const [rescheduleForm, setRescheduleForm] = useState({date:'',reason:''});
  const navigate = useNavigate();

  const isInterviewer = ['personal_interviewer','technical_interviewer'].includes(user?.role);

  // Fetch interviewers list
  useEffect(() => {
    authAPI.getUsers().then(r => {
      const users = r.data.users || [];
      setInterviewers(users.filter(u => ['personal_interviewer','technical_interviewer','hr','super_admin'].includes(u.role)));
    }).catch(() => {});
  }, []);

  // Fetch calendar slots for selected date + interviewer
  const fetchCalendar = async () => {
    try {
      const params = { date: calDate };
      if (calInterviewer) params.interviewer = calInterviewer;
      const res = await api.get('/candidates/interview-slots', { params });
      setCalSlots(res.data.slots || []);
    } catch { setCalSlots([]); }
  };

  // Fetch interview list for timeline tabs
  const fetchInterviews = async () => {
    setLoading(true);
    try {
      const statuses = tab === 'done' ? ['Interview_Done'] : ['Interview_Scheduled','Interview_Pending_Technical'];
      const res = await candidateAPI.getAll({ status: statuses, limit: 200, sort: 'interviewScheduled' });
      let data = res.data.candidates || [];
      if (tab === 'today') {
        const today = todayIST();
        data = data.filter(c => c.interviewScheduled && new Date(c.interviewScheduled).toLocaleDateString('en-CA',{timeZone:'Asia/Kolkata'}) === today);
      } else if (tab === 'upcoming') {
        data = data.filter(c => c.interviewScheduled && new Date(c.interviewScheduled) > new Date());
      }
      setInterviews(data);
    } catch {} finally { setLoading(false); }
  };

  useEffect(() => { if (tab === 'calendar') fetchCalendar(); else fetchInterviews(); }, [tab, calDate, calInterviewer]);

  // Check if slot is booked
  const getSlotBooking = (slot) => {
    return calSlots.find(s => {
      const t = new Date(s.time);
      const h = parseInt(t.toLocaleString('en-US',{hour:'2-digit',hour12:false,timeZone:'Asia/Kolkata'}));
      const m = t.toLocaleString('en-US',{minute:'2-digit',timeZone:'Asia/Kolkata'});
      return h === slot.hour && parseInt(m) === slot.minute;
    });
  };

  // Date navigation
  const changeDate = (days) => {
    const d = new Date(calDate);
    d.setDate(d.getDate() + days);
    setCalDate(d.toISOString().slice(0,10));
  };

  // Score handlers
  const openScore = (c, type) => {
    const b = type === 'personal' ? (c.personalInterviewBreakdown||{}) : (c.technicalInterviewBreakdown||{});
    setScoreForm({technical:b.technical||0,practical:b.practical||0,communication:b.communication||0,experience:b.experience||0,locationAvailability:b.locationAvailability||0,teamLeading:b.teamLeading||0,notes:'',recommendedLocation:c.recommendedLocation||''});
    setScoreModal({candidate:c,type});
  };
  const saveScore = async () => {
    try {
      if (scoreModal.type === 'personal') await candidateAPI.scorePersonalInterview(scoreModal.candidate._id, scoreForm);
      else await candidateAPI.scoreTechnicalInterview(scoreModal.candidate._id, scoreForm);
      toast.success(`${scoreModal.type === 'personal' ? 'Personal' : 'Technical'} scored`);
      setScoreModal(null); fetchInterviews(); fetchCalendar();
    } catch(e) { toast.error(e.response?.data?.error||'Failed'); }
  };
  const markNoShow = async (c) => { if(!confirm('Mark '+c.fullName+' as no-show?'))return; try{await candidateAPI.update(c._id,{status:(c.rescheduleCount||0)>=1?'Unreachable':'Interview_Scheduled',rescheduleCount:(c.rescheduleCount||0)+1,statusChangeReason:'No-show'});toast.success('No-show');fetchInterviews();fetchCalendar();}catch{toast.error('Failed');} };
  const openReschedule = (c) => {setRescheduleForm({date:'',reason:''});setRescheduleModal(c);};
  const saveReschedule = async () => { if(!rescheduleForm.date){toast.error('Select date');return;} try{const dt=new Date(new Date(rescheduleForm.date).getTime()-(5.5*60*60*1000)).toISOString();await candidateAPI.update(rescheduleModal._id,{interviewScheduled:dt,rescheduleCount:(rescheduleModal.rescheduleCount||0)+1,statusChangeReason:'Rescheduled: '+(rescheduleForm.reason||'-')});toast.success('Rescheduled');setRescheduleModal(null);fetchInterviews();fetchCalendar();}catch{toast.error('Failed');} };
  const openProfile = async (c) => { try{const r=await candidateAPI.getOne(c._id);setProfileModal(r.data.candidate);}catch{setProfileModal(c);} };
  const totalScore = (f) => Object.entries(f).filter(([k])=>!['notes','recommendedLocation'].includes(k)).reduce((s,[,v])=>s+Number(v),0);

  const isToday = calDate === todayIST();
  const dateLabel = new Date(calDate+'T12:00:00').toLocaleDateString('en-IN',{weekday:'long',day:'numeric',month:'long',year:'numeric'});

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold" style={{color:G}}>
          {isInterviewer ? (user.role === 'personal_interviewer' ? 'Personal' : 'Technical') + ' Interview Panel' : 'Interview Management'}
        </h1>
        <button onClick={() => { fetchCalendar(); fetchInterviews(); }} className="btn-outline text-sm">Refresh</button>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 bg-gray-100 p-1 rounded-lg w-fit">
        {[
          {key:'calendar',label:'Day Calendar',icon:Calendar},
          {key:'today',label:'Today',icon:Clock},
          {key:'upcoming',label:'Upcoming',icon:Calendar},
          {key:'done',label:'Completed',icon:Star},
        ].map(t => (
          <button key={t.key} onClick={()=>setTab(t.key)}
            className={'px-3 py-2 text-sm rounded-md transition flex items-center gap-1.5 '+(tab===t.key?'bg-white font-medium shadow-sm':'text-gray-500')}
            style={tab===t.key?{color:O}:{}}>
            <t.icon size={14}/> {t.label}
          </button>
        ))}
      </div>

      {/* ═══ CALENDAR VIEW ═══ */}
      {tab === 'calendar' && (
        <div>
          {/* Date picker + interviewer filter */}
          <div className="card !p-3 flex flex-wrap items-center gap-3 mb-4">
            <button onClick={()=>changeDate(-1)} className="btn-outline p-1.5"><ChevronLeft size={16}/></button>
            <input type="date" value={calDate} onChange={e=>setCalDate(e.target.value)} className="input-field w-auto text-sm"/>
            <button onClick={()=>changeDate(1)} className="btn-outline p-1.5"><ChevronRight size={16}/></button>
            <span className={'text-sm font-medium '+(isToday?'text-orange-600':'text-gray-600')}>{dateLabel}</span>
            <div className="ml-auto flex items-center gap-2">
              <select value={calInterviewer} onChange={e=>setCalInterviewer(e.target.value)} className="input-field w-auto text-sm">
                <option value="">All Interviewers</option>
                {interviewers.map(u => <option key={u._id} value={u._id}>{u.name} ({u.role?.replace(/_/g,' ')})</option>)}
              </select>
              <span className="text-xs text-gray-400">{calSlots.length} booked</span>
            </div>
          </div>

          {/* Time grid */}
          <div className="bg-white rounded-xl border shadow-sm overflow-hidden">
            <div className="grid grid-cols-[70px_1fr] max-h-[70vh] overflow-y-auto">
              {/* Hour headers + 5-min slots */}
              {Array.from({length:11},(_, i) => i+9).map(hour => {
                const hour12 = hour > 12 ? hour-12 : hour;
                const ampm = hour >= 12 ? 'PM' : 'AM';
                const hourSlots = TIME_SLOTS.filter(s => s.hour === hour);

                return (
                  <div key={hour} className="contents">
                    {/* Hour label */}
                    <div className="border-b border-r bg-gray-50 px-2 py-1 text-xs font-medium text-gray-500 sticky left-0 row-span-1 flex items-start pt-2">
                      {hour12} {ampm}
                    </div>
                    {/* Slots for this hour */}
                    <div className="border-b grid grid-cols-12 min-h-[48px]">
                      {hourSlots.map(slot => {
                        const booking = getSlotBooking(slot);
                        const isPast = isToday && (hour < new Date().getHours() || (hour === new Date().getHours() && slot.minute < new Date().getMinutes()));

                        return (
                          <div key={slot.value}
                            className={'border-r text-[10px] p-0.5 relative group transition cursor-default '+(
                              booking ? 'bg-orange-100 border-orange-200' :
                              isPast ? 'bg-gray-50' :
                              'hover:bg-green-50'
                            )}
                            title={booking ? `${booking.fullName} (${booking.timeIST})` : `${slot.label} — Available`}>
                            {booking ? (
                              <div className="truncate px-0.5" onClick={()=>navigate('/candidates/'+booking._id)}>
                                <div className="font-medium text-orange-800 truncate">{booking.fullName?.split(' ')[0]}</div>
                              </div>
                            ) : (
                              <span className="text-gray-300">{slot.minute === 0 ? '' : ':'+String(slot.minute).padStart(2,'0')}</span>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Booked list below calendar */}
          {calSlots.length > 0 && (
            <div className="card !p-4 mt-4">
              <h3 className="font-semibold text-sm mb-3" style={{color:G}}>Booked Interviews — {dateLabel}</h3>
              <div className="space-y-2">
                {calSlots.map(s => (
                  <div key={s._id} className="flex items-center gap-3 p-2 rounded-lg border hover:bg-gray-50 cursor-pointer" onClick={()=>navigate('/candidates/'+s._id)}>
                    <div className="w-16 text-center shrink-0">
                      <div className="text-sm font-bold" style={{color:O}}>{s.timeIST}</div>
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="font-medium text-sm text-gray-900">{s.fullName}</div>
                      <div className="text-xs text-gray-400">{s.candidateId} • {s.phone}</div>
                    </div>
                    <span className={'text-xs px-2 py-0.5 rounded-full '+(s.type==='virtual'?'bg-blue-100 text-blue-700':'bg-green-100 text-green-700')}>{s.type||'TBD'}</span>
                    <span className="text-xs text-gray-400">{s.interviewer}</span>
                    {s.personalScore > 0 && <span className="text-xs font-bold text-purple-600">P:{s.personalScore}</span>}
                    {s.technicalScore > 0 && <span className="text-xs font-bold text-orange-600">T:{s.technicalScore}</span>}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* ═══ TODAY / UPCOMING / DONE TABS ═══ */}
      {tab !== 'calendar' && (
        loading ? <div className="flex justify-center py-12"><div className="animate-spin rounded-full h-8 w-8 border-b-2" style={{borderColor:O}}></div></div> :
        interviews.length === 0 ? <div className="card text-center py-12 text-gray-400"><Calendar size={48} className="mx-auto mb-3 text-gray-300"/><p>No interviews</p></div> :
        <div className="space-y-2">
          {interviews.map(c => {
            const dt = c.interviewScheduled ? new Date(c.interviewScheduled) : null;
            const hasP = c.personalInterviewScore > 0;
            const hasT = c.technicalInterviewScore > 0;
            const isFullyScored = hasP && hasT;

            return (
              <div key={c._id} className={'card !p-3 border-l-4 '+(isFullyScored?'border-l-green-400':hasP?'border-l-amber-400':'border-l-blue-400')}>
                <div className="flex flex-col lg:flex-row lg:items-center gap-3">
                  <div className="lg:w-20 text-center shrink-0">
                    {dt && <><div className="text-sm font-bold" style={{color:O}}>{toIST(dt)}</div><div className="text-[10px] text-gray-400">{toISTFull(dt).split(',')[0]}</div></>}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-semibold text-gray-900 text-sm">{c.fullName}</span>
                      <span className="text-[10px] text-gray-400">{c.candidateId}</span>
                      {c.interviewType==='virtual'&&<span className="text-[10px] bg-blue-50 text-blue-600 px-1.5 py-0.5 rounded"><Video size={10} className="inline"/> Virtual</span>}
                      {hasP&&!hasT&&<span className="text-[10px] bg-amber-50 text-amber-600 px-1.5 py-0.5 rounded">Tech Pending</span>}
                      {isFullyScored&&<span className="text-[10px] bg-green-50 text-green-600 px-1.5 py-0.5 rounded">Scored</span>}
                    </div>
                    <div className="text-[11px] text-gray-500 mt-0.5">{c.qualification?.replace(/_/g,' ')} • {c.experienceYears||0}yr • {c.preferredCity||c.currentLocation?.city||'-'}</div>
                  </div>
                  {(hasP||hasT)&&<div className="flex gap-1 shrink-0">
                    {hasP&&<div className="text-center px-2 py-1 rounded bg-purple-50"><div className="text-xs font-bold text-purple-700">{c.personalInterviewScore}/24</div><div className="text-[9px] text-purple-500">P</div></div>}
                    {hasT&&<div className="text-center px-2 py-1 rounded bg-orange-50"><div className="text-xs font-bold text-orange-700">{c.technicalInterviewScore}/24</div><div className="text-[9px] text-orange-500">T</div></div>}
                  </div>}
                  <div className="flex items-center gap-1 shrink-0 flex-wrap">
                    <button onClick={()=>openProfile(c)} className="btn-outline text-[11px] py-1 px-2"><FileText size={11} className="inline mr-0.5"/>Profile</button>
                    {!hasP&&tab!=='done'&&<button onClick={()=>openScore(c,'personal')} className="text-white text-[11px] py-1 px-2 rounded-lg" style={{backgroundColor:'#8B5CF6'}}><Star size={11} className="inline mr-0.5"/>Personal</button>}
                    {hasP&&!hasT&&tab!=='done'&&<button onClick={()=>openScore(c,'technical')} className="text-white text-[11px] py-1 px-2 rounded-lg" style={{backgroundColor:O}}><Star size={11} className="inline mr-0.5"/>Technical</button>}
                    {tab!=='done'&&!isFullyScored&&<>
                      <button onClick={()=>markNoShow(c)} className="bg-red-50 text-red-600 text-[11px] py-1 px-2 rounded-lg"><AlertTriangle size={11} className="inline"/></button>
                      <button onClick={()=>openReschedule(c)} className="bg-amber-50 text-amber-600 text-[11px] py-1 px-2 rounded-lg"><RotateCcw size={11} className="inline"/></button>
                    </>}
                    {c.interviewLink&&tab!=='done'&&<a href={c.interviewLink} target="_blank" rel="noopener noreferrer" className="bg-blue-600 text-white text-[11px] py-1 px-2 rounded-lg"><Video size={11} className="inline mr-0.5"/>Join</a>}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* ═══ SCORE MODAL ═══ */}
      {scoreModal&&<div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4"><div className="bg-white rounded-xl shadow-xl max-w-lg w-full max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between p-5 border-b"><div><h3 className="text-lg font-bold" style={{color:G}}>Score {scoreModal.type==='personal'?'Personal':'Technical'} Interview</h3><p className="text-sm text-gray-500">{scoreModal.candidate.fullName} • {scoreModal.candidate.candidateId}</p></div><button onClick={()=>setScoreModal(null)} className="text-gray-400 hover:text-gray-600"><X size={20}/></button></div>
        <div className="p-5 space-y-4">
          <div className="bg-gray-50 rounded-lg p-3 text-sm grid grid-cols-2 gap-2">
            <div><span className="text-gray-500">Qualification:</span> <b>{scoreModal.candidate.qualification?.replace(/_/g,' ')}</b></div>
            <div><span className="text-gray-500">Experience:</span> <b>{scoreModal.candidate.experienceYears||0} years</b></div>
          </div>
          {[['technical','Technical Knowledge'],['practical','Practical Skills'],['communication','Communication & Attitude'],['experience','Relevant Experience'],['locationAvailability','Location Willingness'],['teamLeading','Team Leading']].map(([key,label])=>(
            <div key={key}><label className="block text-sm font-medium text-gray-700 mb-2">{label}</label>
              <div className="flex gap-2">{[{v:1,l:'Poor'},{v:2,l:'Average'},{v:3,l:'Good'},{v:4,l:'Excellent'}].map(opt=>(
                <button key={opt.v} type="button" onClick={()=>setScoreForm(f=>({...f,[key]:opt.v}))}
                  className={'flex-1 py-2 px-2 rounded-lg border-2 text-sm font-medium transition '+(scoreForm[key]===opt.v?SCORE_COLORS[opt.v]+' border-current':'bg-gray-50 text-gray-400 border-gray-200 hover:bg-gray-100')}>{opt.l}</button>
              ))}</div></div>
          ))}
          <div className="pt-3 border-t text-center"><span className="text-lg font-bold" style={{color:O}}>Total: {totalScore(scoreForm)}/24</span></div>
          <div><label className="block text-sm font-medium text-gray-700 mb-1">Recommended Location</label><input value={scoreForm.recommendedLocation} onChange={e=>setScoreForm(f=>({...f,recommendedLocation:e.target.value}))} className="input-field" placeholder="e.g., Jaipur"/></div>
          <div><label className="block text-sm font-medium text-gray-700 mb-1">Notes</label><textarea value={scoreForm.notes} onChange={e=>setScoreForm(f=>({...f,notes:e.target.value}))} className="input-field" rows={2}/></div>
        </div>
        <div className="flex gap-3 justify-end p-5 border-t"><button onClick={()=>setScoreModal(null)} className="btn-outline text-sm">Cancel</button><button onClick={saveScore} className="text-white px-4 py-2 rounded-lg text-sm" style={{backgroundColor:O}} disabled={totalScore(scoreForm)===0}><Save size={14} className="inline mr-1"/>Submit</button></div>
      </div></div>}

      {/* ═══ PROFILE MODAL ═══ */}
      {profileModal&&<div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4"><div className="bg-white rounded-xl shadow-xl max-w-md w-full max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between p-5 border-b"><h3 className="text-lg font-bold" style={{color:G}}>Profile</h3><button onClick={()=>setProfileModal(null)} className="text-gray-400 hover:text-gray-600"><X size={20}/></button></div>
        <div className="p-5"><div className="text-center mb-4"><div className="w-14 h-14 rounded-full flex items-center justify-center text-white font-bold text-xl mx-auto" style={{backgroundColor:O}}>{profileModal.fullName?.split(' ').map(n=>n[0]).join('').slice(0,2)}</div><h2 className="text-lg font-bold mt-2">{profileModal.fullName}</h2><p className="text-sm text-gray-500">{profileModal.candidateId}</p></div>
          <dl className="space-y-2 text-sm">{[['Phone',profileModal.phone],['Qualification',profileModal.qualification?.replace(/_/g,' ')],['Experience',(profileModal.experienceYears||0)+' years'],['City',profileModal.currentLocation?.city],['Preferred',profileModal.preferredCity||profileModal.preferredLocation?.name],['Source',profileModal.source],['Father',profileModal.fatherName]].filter(([,v])=>v).map(([l,v])=>(<div key={l} className="flex justify-between border-b border-gray-50 pb-1"><dt className="text-gray-500">{l}</dt><dd className="font-medium text-gray-800">{v}</dd></div>))}</dl>
        </div>
        <div className="flex gap-3 justify-end p-5 border-t"><button onClick={()=>setProfileModal(null)} className="btn-outline text-sm">Close</button><button onClick={()=>{setProfileModal(null);navigate('/candidates/'+profileModal._id);}} className="text-white px-4 py-2 rounded-lg text-sm" style={{backgroundColor:O}}>Full Detail</button></div>
      </div></div>}

      {/* ═══ RESCHEDULE MODAL ═══ */}
      {rescheduleModal&&<div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4"><div className="bg-white rounded-xl shadow-xl max-w-sm w-full">
        <div className="flex items-center justify-between p-5 border-b"><h3 className="text-lg font-bold" style={{color:G}}>Reschedule</h3><button onClick={()=>setRescheduleModal(null)} className="text-gray-400 hover:text-gray-600"><X size={20}/></button></div>
        <div className="p-5 space-y-3">
          <p className="text-sm text-gray-600">{rescheduleModal.fullName}</p>
          <div><label className="block text-sm font-medium text-gray-700 mb-1">New Date & Time *</label><input type="datetime-local" value={rescheduleForm.date} onChange={e=>setRescheduleForm(f=>({...f,date:e.target.value}))} className="input-field"/></div>
          <div><label className="block text-sm font-medium text-gray-700 mb-1">Reason</label><input value={rescheduleForm.reason} onChange={e=>setRescheduleForm(f=>({...f,reason:e.target.value}))} className="input-field"/></div>
        </div>
        <div className="flex gap-3 justify-end p-5 border-t"><button onClick={()=>setRescheduleModal(null)} className="btn-outline text-sm">Cancel</button><button onClick={saveReschedule} className="text-white px-4 py-2 rounded-lg text-sm" style={{backgroundColor:O}}>Reschedule</button></div>
      </div></div>}
    </div>
  );
}
