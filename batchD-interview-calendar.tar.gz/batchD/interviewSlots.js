// Add to candidateController.js or create as separate file
// GET /api/candidates/interview-slots?date=2026-03-22&interviewer=userId
const { Candidate } = require('../models');

exports.getInterviewSlots = async (req, res) => {
  try {
    const { date, interviewer } = req.query;
    if (!date) return res.status(400).json({ error: 'Date required' });

    // Parse date in IST
    const dayStart = new Date(date + 'T00:00:00+05:30');
    const dayEnd = new Date(date + 'T23:59:59+05:30');

    const query = {
      interviewScheduled: { $gte: dayStart, $lte: dayEnd },
      status: { $in: ['Interview_Scheduled', 'Interview_Pending_Technical', 'Interview_Done'] }
    };
    if (interviewer) query.interviewer = interviewer;

    const booked = await Candidate.find(query)
      .select('fullName candidateId phone interviewScheduled interviewType status personalInterviewScore technicalInterviewScore interviewer')
      .populate('interviewer', 'name')
      .sort('interviewScheduled')
      .lean();

    // Convert to slot format
    const slots = booked.map(c => ({
      _id: c._id,
      candidateId: c.candidateId,
      fullName: c.fullName,
      phone: c.phone,
      time: c.interviewScheduled,
      timeIST: new Date(c.interviewScheduled).toLocaleString('en-IN', { hour: '2-digit', minute: '2-digit', hour12: true, timeZone: 'Asia/Kolkata' }),
      type: c.interviewType,
      status: c.status,
      interviewer: c.interviewer?.name,
      interviewerId: c.interviewer?._id,
      personalScore: c.personalInterviewScore || 0,
      technicalScore: c.technicalInterviewScore || 0,
    }));

    res.json({ date, slots, totalBooked: slots.length });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

module.exports = exports;
