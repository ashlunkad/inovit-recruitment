#!/bin/bash
echo "═══════════════════════════════════════════"
echo "  INOVIT — Batch D: Interview Calendar"
echo "═══════════════════════════════════════════"

DIR="$(cd "$(dirname "$0")" && pwd)"
cd /opt/inovit-recruitment

# 1. Add interview-slots endpoint to backend
echo "📝 [1/3] Adding interview slots endpoint..."
cp "$DIR/interviewSlots.js" backend/src/controllers/

# Add route
cat > /tmp/fix_slots_route.js << 'EOF'
const fs = require('fs');
const file = 'backend/src/routes/index.js';
let c = fs.readFileSync(file, 'utf8');

if (!c.includes('interview-slots')) {
  // Import controller
  c = c.replace(
    "let documentCtrl",
    "let interviewSlotsCtrl;\ntry { interviewSlotsCtrl = require('../controllers/interviewSlots'); } catch(e) {}\nlet documentCtrl"
  );
  // Add route
  c = c.replace(
    "router.get('/candidates/search-phone'",
    "if (interviewSlotsCtrl) router.get('/candidates/interview-slots', auth, interviewSlotsCtrl.getInterviewSlots);\nrouter.get('/candidates/search-phone'"
  );
  fs.writeFileSync(file, c);
  console.log('  Added /candidates/interview-slots route');
} else {
  console.log('  Route already exists');
}
EOF
node /tmp/fix_slots_route.js

# 2. Update frontend
echo "📝 [2/3] Replacing Interviews page with calendar view..."
cp "$DIR/Interviews.jsx" frontend/src/pages/

# 3. Build and restart
echo "🔨 [3/3] Building + restarting..."
cd frontend && npm run build
pm2 restart all

echo ""
echo "═══════════════════════════════════════════"
echo "  ✅ Batch D: Interview Calendar INSTALLED!"
echo "═══════════════════════════════════════════"
echo ""
echo "New 'Day Calendar' tab on Interviews page:"
echo "  • Date picker with prev/next day arrows"
echo "  • Filter by interviewer"
echo "  • 5-min slots from 9 AM to 8 PM (132 slots)"
echo "  • Booked slots shown in orange with candidate name"
echo "  • Available slots shown as empty (hoverable green)"
echo "  • Booked list below calendar with details"
echo "  • Prevents double-booking (booked = blocked)"
echo ""
echo "Other tabs still work:"
echo "  • Today — today's interviews with score buttons"
echo "  • Upcoming — future interviews"
echo "  • Completed — scored interviews"
echo ""
echo "Brand colors: Orange (#E67E22) accents throughout"
pm2 status
