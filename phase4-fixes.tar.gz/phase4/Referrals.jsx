import { useState, useEffect } from 'react';
import api from '../services/api';
import { useNavigate } from 'react-router-dom';
import { Gift, Copy, Users, TrendingUp, Search } from 'lucide-react';
import toast from 'react-hot-toast';

export default function Referrals() {
  const [referrers, setReferrers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const navigate = useNavigate();

  const fetchData = async () => {
    setLoading(true);
    try {
      // Get candidates who have referral codes and have been referred by someone
      const res = await api.get('/candidates', { params: { limit: 500, sort: '-createdAt' } });
      const all = res.data.candidates || [];

      // Build referrer map — candidates who have referral codes
      const referrerMap = {};
      all.forEach(c => {
        if (c.referralCode) {
          referrerMap[c._id] = {
            ...c,
            referrals: [],
            totalReferred: 0,
            deployedReferred: 0,
          };
        }
      });

      // Find who was referred
      all.forEach(c => {
        if (c.referredBy && referrerMap[c.referredBy]) {
          referrerMap[c.referredBy].referrals.push(c);
          referrerMap[c.referredBy].totalReferred++;
          if (c.status === 'Deployed') referrerMap[c.referredBy].deployedReferred++;
        }
      });

      // Convert to array and sort by total referrals
      let list = Object.values(referrerMap).sort((a, b) => b.totalReferred - a.totalReferred);

      if (search) {
        const s = search.toLowerCase();
        list = list.filter(r => r.fullName?.toLowerCase().includes(s) || r.referralCode?.toLowerCase().includes(s) || r.phone?.includes(s));
      }

      setReferrers(list);
    } catch (err) { console.error(err); }
    finally { setLoading(false); }
  };

  useEffect(() => { fetchData(); }, []);

  const copyCode = (code) => {
    navigator.clipboard?.writeText(code);
    toast.success('Referral code copied: ' + code);
  };

  const totalReferrals = referrers.reduce((s, r) => s + r.totalReferred, 0);
  const activeReferrers = referrers.filter(r => r.totalReferred > 0).length;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-gray-900">Referral Tracking</h1>
        <span className="text-sm text-gray-500">{referrers.length} candidates with referral codes</span>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-4">
        <div className="card !p-4 text-center">
          <div className="text-3xl font-bold text-primary-700">{totalReferrals}</div>
          <div className="text-sm text-gray-500">Total Referrals</div>
        </div>
        <div className="card !p-4 text-center">
          <div className="text-3xl font-bold text-green-600">{activeReferrers}</div>
          <div className="text-sm text-gray-500">Active Referrers</div>
        </div>
        <div className="card !p-4 text-center">
          <div className="text-3xl font-bold text-orange-500">{referrers.reduce((s, r) => s + r.deployedReferred, 0)}</div>
          <div className="text-sm text-gray-500">Deployed via Referral</div>
        </div>
      </div>

      {/* Search */}
      <div className="flex gap-2">
        <div className="relative flex-1 max-w-md">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
          <input value={search} onChange={e => { setSearch(e.target.value); }}
            placeholder="Search by name, code, or phone..." className="input-field pl-9" />
        </div>
        {search && <button onClick={() => { setSearch(''); fetchData(); }} className="btn-outline text-sm">Clear</button>}
        <button onClick={fetchData} className="btn-primary text-sm">Search</button>
      </div>

      {/* Table */}
      {loading ? (
        <div className="flex justify-center py-12"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary-600"></div></div>
      ) : (
        <div className="bg-white rounded-xl shadow-sm border overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-gray-50 border-b">
              <tr>
                <th className="px-4 py-3 text-left font-medium text-gray-500">Referrer</th>
                <th className="px-4 py-3 text-left font-medium text-gray-500">Referral Code</th>
                <th className="px-4 py-3 text-center font-medium text-gray-500">Referred</th>
                <th className="px-4 py-3 text-center font-medium text-gray-500">Deployed</th>
                <th className="px-4 py-3 text-left font-medium text-gray-500">Status</th>
                <th className="px-4 py-3 text-left font-medium text-gray-500">Referred Candidates</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {referrers.filter(r => r.totalReferred > 0 || search).slice(0, 100).map(r => (
                <tr key={r._id} className="hover:bg-gray-50">
                  <td className="px-4 py-3 cursor-pointer" onClick={() => navigate('/candidates/' + r._id)}>
                    <div className="font-medium text-gray-900">{r.fullName}</div>
                    <div className="text-xs text-gray-400">{r.candidateId} • {r.phone}</div>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      <code className="bg-primary-50 text-primary-700 px-2 py-1 rounded text-xs font-mono">{r.referralCode}</code>
                      <button onClick={() => copyCode(r.referralCode)} className="p-1 text-gray-400 hover:text-primary-600 rounded"><Copy size={13} /></button>
                    </div>
                  </td>
                  <td className="px-4 py-3 text-center font-bold">{r.totalReferred}</td>
                  <td className="px-4 py-3 text-center font-bold text-green-600">{r.deployedReferred}</td>
                  <td className="px-4 py-3">
                    <span className={'badge text-xs ' + (r.status === 'Deployed' ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-600')}>
                      {r.status?.replace(/_/g, ' ')}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    {r.referrals.length > 0 ? (
                      <div className="flex flex-wrap gap-1">
                        {r.referrals.slice(0, 5).map(ref => (
                          <span key={ref._id} onClick={() => navigate('/candidates/' + ref._id)}
                            className="text-xs bg-gray-100 text-gray-600 px-2 py-0.5 rounded cursor-pointer hover:bg-primary-50 hover:text-primary-700">
                            {ref.fullName?.split(' ')[0]}
                          </span>
                        ))}
                        {r.referrals.length > 5 && <span className="text-xs text-gray-400">+{r.referrals.length - 5} more</span>}
                      </div>
                    ) : <span className="text-xs text-gray-400">No referrals yet</span>}
                  </td>
                </tr>
              ))}
              {referrers.filter(r => r.totalReferred > 0 || search).length === 0 && (
                <tr><td colSpan={6} className="py-12 text-center text-gray-400">No referrals found</td></tr>
              )}
            </tbody>
          </table>
        </div>
      )}

      {/* Registration link info */}
      <div className="card border-blue-200 bg-blue-50">
        <h3 className="font-semibold text-blue-800 mb-2 flex items-center gap-2"><Gift size={18} /> How Referrals Work</h3>
        <div className="text-sm text-blue-700 space-y-1">
          <p>Every registered candidate automatically gets a unique referral code (e.g., REF-RAHU-4521).</p>
          <p>New candidates can enter this code during walk-in registration to be linked to their referrer.</p>
          <p>Walk-in registration URL: <code className="bg-blue-100 px-1 rounded">https://hire.inovit.in/register</code></p>
        </div>
      </div>
    </div>
  );
}
