#!/bin/bash
# INOVIT Database Backup Script
# Run manually or add to cron: 0 2 * * * /opt/inovit-recruitment/backup.sh
# This creates daily backups and keeps last 30 days

BACKUP_DIR="/opt/backups/inovit"
DATE=$(date +%Y-%m-%d_%H%M)
DB_NAME="inovit_recruitment"

mkdir -p "$BACKUP_DIR"

echo "[$(date)] Starting backup..."
mongodump --db "$DB_NAME" --out "$BACKUP_DIR/$DATE" --quiet

if [ $? -eq 0 ]; then
    # Compress
    cd "$BACKUP_DIR" && tar -czf "$DATE.tar.gz" "$DATE" && rm -rf "$DATE"
    echo "[$(date)] Backup complete: $BACKUP_DIR/$DATE.tar.gz"
    
    # Delete backups older than 30 days
    find "$BACKUP_DIR" -name "*.tar.gz" -mtime +30 -delete
    echo "[$(date)] Old backups cleaned up"
    
    # Show size
    ls -lh "$BACKUP_DIR/$DATE.tar.gz"
else
    echo "[$(date)] ERROR: Backup failed!"
    exit 1
fi
