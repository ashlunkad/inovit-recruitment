#!/bin/bash
echo "═══════════════════════════════════════════"
echo "  INOVIT Phase 4 — Final Polish Installer"
echo "═══════════════════════════════════════════"

DIR="$(cd "$(dirname "$0")" && pwd)"
cd /opt/inovit-recruitment

echo "📝 [1/9] Adding Settings page..."
cp "$DIR/Settings.jsx" frontend/src/pages/

echo "📝 [2/9] Adding Referrals page..."
cp "$DIR/Referrals.jsx" frontend/src/pages/

echo "📝 [3/9] Updating App.jsx (all routes)..."
cp "$DIR/App.jsx" frontend/src/

echo "📝 [4/9] Updating Layout.jsx (all nav items)..."
cp "$DIR/Layout.jsx" frontend/src/components/layout/

echo "📝 [5/9] Adding security middleware..."
cp "$DIR/security.js" backend/src/middleware/

echo "📝 [6/9] Updating server.js (security + rate limiting)..."
cp "$DIR/server.js" backend/src/

echo "📝 [7/9] Setting up backup script..."
cp "$DIR/backup.sh" /opt/inovit-recruitment/
chmod +x /opt/inovit-recruitment/backup.sh
mkdir -p /opt/backups/inovit

echo "📦 [8/9] Installing security packages + building..."
cd backend && npm install express-rate-limit --save 2>/dev/null
cd ../frontend && npm run build

echo "🔄 [9/9] Restarting services..."
pm2 restart all

# Setup daily backup cron
echo "⏰ Setting up daily backup at 2 AM..."
(crontab -l 2>/dev/null | grep -v "inovit-recruitment/backup.sh"; echo "0 2 * * * /opt/inovit-recruitment/backup.sh >> /opt/backups/inovit/backup.log 2>&1") | crontab -

echo ""
echo "═══════════════════════════════════════════"
echo "  ✅ Phase 4 — FINAL PHASE INSTALLED!"
echo "═══════════════════════════════════════════"
echo ""
echo "New pages in sidebar:"
echo "  • Referrals — Track referral codes and referred candidates"
echo "  • Settings — Change password, security info, system info,"
echo "               backup commands, VPS commands reference"
echo ""
echo "Security improvements:"
echo "  • Login rate limiting (10 attempts per 15 min)"
echo "  • API rate limiting (100 requests per minute)"
echo "  • MongoDB injection prevention"
echo "  • Helmet security headers"
echo ""
echo "Backup:"
echo "  • Daily automatic backup at 2 AM"
echo "  • Stored in /opt/backups/inovit/"
echo "  • 30-day retention (auto-delete old backups)"
echo "  • Manual backup: /opt/inovit-recruitment/backup.sh"
echo ""
echo "════════════════════════════════════════════"
echo "  🎉 ALL 4 PHASES COMPLETE!"
echo "  Your platform is fully production-ready."
echo "  https://hire.inovit.in"
echo "════════════════════════════════════════════"
echo ""
pm2 status
