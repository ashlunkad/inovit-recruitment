import { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import api from '../services/api';
import toast from 'react-hot-toast';
import { Shield, Database, Key, Globe, Lock, Clock, AlertTriangle } from 'lucide-react';

export default function Settings() {
  const { user } = useAuth();
  const [passwordForm, setPasswordForm] = useState({ currentPassword: '', newPassword: '', confirmPassword: '' });
  const [saving, setSaving] = useState(false);
  const [tab, setTab] = useState('password');

  const changePassword = async () => {
    if (!passwordForm.currentPassword || !passwordForm.newPassword) { toast.error('Fill in all fields'); return; }
    if (passwordForm.newPassword.length < 6) { toast.error('New password must be at least 6 characters'); return; }
    if (passwordForm.newPassword !== passwordForm.confirmPassword) { toast.error('Passwords do not match'); return; }
    setSaving(true);
    try {
      await api.put('/auth/change-password', { currentPassword: passwordForm.currentPassword, newPassword: passwordForm.newPassword });
      toast.success('Password changed successfully');
      setPasswordForm({ currentPassword: '', newPassword: '', confirmPassword: '' });
    } catch (err) { toast.error(err.response?.data?.error || 'Failed to change password'); }
    finally { setSaving(false); }
  };

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-gray-900">Settings</h1>

      <div className="flex gap-1 bg-gray-100 p-1 rounded-lg w-fit">
        {[{ key: 'password', label: 'Change Password', icon: Key },
          { key: 'security', label: 'Security Info', icon: Shield },
          { key: 'system', label: 'System Info', icon: Database },
        ].map(t => (
          <button key={t.key} onClick={() => setTab(t.key)}
            className={'px-4 py-2 text-sm rounded-md transition flex items-center gap-1 ' + (tab === t.key ? 'bg-white text-primary-700 font-medium shadow-sm' : 'text-gray-500 hover:text-gray-700')}>
            <t.icon size={14} /> {t.label}
          </button>
        ))}
      </div>

      {tab === 'password' && (
        <div className="card max-w-md">
          <h2 className="text-lg font-semibold text-gray-800 mb-4">Change Your Password</h2>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Current Password</label>
              <input type="password" value={passwordForm.currentPassword}
                onChange={e => setPasswordForm(f => ({...f, currentPassword: e.target.value}))}
                className="input-field" placeholder="Enter current password" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">New Password</label>
              <input type="password" value={passwordForm.newPassword}
                onChange={e => setPasswordForm(f => ({...f, newPassword: e.target.value}))}
                className="input-field" placeholder="Minimum 6 characters" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Confirm New Password</label>
              <input type="password" value={passwordForm.confirmPassword}
                onChange={e => setPasswordForm(f => ({...f, confirmPassword: e.target.value}))}
                className="input-field" placeholder="Re-enter new password" />
            </div>
            <button onClick={changePassword} disabled={saving} className="btn-primary w-full py-2.5">
              {saving ? 'Changing...' : 'Change Password'}
            </button>
          </div>
        </div>
      )}

      {tab === 'security' && (
        <div className="space-y-4 max-w-2xl">
          <div className="card">
            <h2 className="text-lg font-semibold text-gray-800 mb-3">Security Overview</h2>
            <div className="space-y-3">
              <div className="flex items-center gap-3 p-3 bg-green-50 rounded-lg">
                <Lock size={20} className="text-green-600" />
                <div><div className="font-medium text-green-800">SSL/HTTPS Enabled</div>
                  <div className="text-xs text-green-600">All traffic encrypted via Cloudflare SSL</div></div>
              </div>
              <div className="flex items-center gap-3 p-3 bg-green-50 rounded-lg">
                <Shield size={20} className="text-green-600" />
                <div><div className="font-medium text-green-800">JWT Authentication</div>
                  <div className="text-xs text-green-600">Token-based auth with 7-day expiry</div></div>
              </div>
              <div className="flex items-center gap-3 p-3 bg-green-50 rounded-lg">
                <Key size={20} className="text-green-600" />
                <div><div className="font-medium text-green-800">Password Hashing</div>
                  <div className="text-xs text-green-600">bcrypt with salt rounds — passwords never stored in plain text</div></div>
              </div>
              <div className="flex items-center gap-3 p-3 bg-green-50 rounded-lg">
                <Globe size={20} className="text-green-600" />
                <div><div className="font-medium text-green-800">CORS Protection</div>
                  <div className="text-xs text-green-600">API only accepts requests from authorized origins</div></div>
              </div>
              <div className="flex items-center gap-3 p-3 bg-blue-50 rounded-lg">
                <Shield size={20} className="text-blue-600" />
                <div><div className="font-medium text-blue-800">Role-Based Access Control</div>
                  <div className="text-xs text-blue-600">5 roles: Super Admin, Team Lead, Agent, Interviewer, Telecaller</div></div>
              </div>
            </div>
          </div>

          <div className="card border-yellow-200 bg-yellow-50">
            <h3 className="font-semibold text-yellow-800 mb-2 flex items-center gap-2"><AlertTriangle size={18} /> Security Recommendations</h3>
            <ul className="space-y-2 text-sm text-yellow-700">
              <li>• Change default admin password (admin123) immediately</li>
              <li>• Use strong passwords (8+ characters, mixed case, numbers)</li>
              <li>• Regularly review user accounts and deactivate unused ones</li>
              <li>• Set up automated database backups (see System Info tab)</li>
              <li>• Monitor the VPS firewall rules periodically</li>
            </ul>
          </div>
        </div>
      )}

      {tab === 'system' && (
        <div className="space-y-4 max-w-2xl">
          <div className="card">
            <h2 className="text-lg font-semibold text-gray-800 mb-3">System Information</h2>
            <dl className="space-y-2 text-sm">
              {[
                ['Platform', 'INOVIT Recruitment Platform v3.0'],
                ['Domain', 'hire.inovit.in'],
                ['Server', 'Ubuntu 22.04 LTS — Hostinger VPS'],
                ['Backend', 'Node.js + Express + MongoDB'],
                ['Frontend', 'React + Vite + Tailwind CSS'],
                ['Process Manager', 'PM2 (auto-restart on crash/reboot)'],
                ['SSL', 'Cloudflare (Flexible mode)'],
                ['Proxy', 'Nginx Proxy Manager (Docker)'],
                ['Database', 'MongoDB 7.0 (local)'],
                ['Logged in as', user?.name + ' (' + user?.role + ')'],
              ].map(([k, v]) => (
                <div key={k} className="flex justify-between py-1.5 border-b border-gray-50">
                  <dt className="text-gray-500">{k}</dt>
                  <dd className="font-medium text-gray-800">{v}</dd>
                </div>
              ))}
            </dl>
          </div>

          <div className="card">
            <h2 className="text-lg font-semibold text-gray-800 mb-3">Database Backup</h2>
            <p className="text-sm text-gray-600 mb-3">Run this command on your VPS terminal to create a backup:</p>
            <div className="bg-gray-900 text-green-400 rounded-lg p-4 text-sm font-mono overflow-x-auto">
              mongodump --db inovit_recruitment --out /opt/backups/$(date +%Y-%m-%d)
            </div>
            <p className="text-sm text-gray-500 mt-3">To set up daily automatic backups, ask your admin to run:</p>
            <div className="bg-gray-900 text-green-400 rounded-lg p-4 text-sm font-mono overflow-x-auto mt-2">
              echo "0 2 * * * mongodump --db inovit_recruitment --out /opt/backups/\$(date +\%Y-\%m-\%d) && find /opt/backups -mtime +30 -delete" | crontab -
            </div>
            <p className="text-xs text-gray-400 mt-2">This backs up daily at 2 AM and deletes backups older than 30 days.</p>
          </div>

          <div className="card">
            <h2 className="text-lg font-semibold text-gray-800 mb-3">Useful VPS Commands</h2>
            <div className="space-y-2 text-sm">
              {[
                ['Check app status', 'pm2 status'],
                ['View API logs', 'pm2 logs inovit-api --lines 50'],
                ['Restart all', 'pm2 restart all'],
                ['Update from GitHub', 'cd /opt/inovit-recruitment && git pull'],
                ['Rebuild frontend', 'cd /opt/inovit-recruitment/frontend && npm run build'],
                ['MongoDB shell', 'mongosh inovit_recruitment'],
                ['Check disk space', 'df -h'],
                ['Check memory', 'free -h'],
              ].map(([label, cmd]) => (
                <div key={label} className="flex items-center gap-3 p-2 rounded hover:bg-gray-50">
                  <span className="text-gray-500 w-40">{label}</span>
                  <code className="text-xs bg-gray-100 px-2 py-1 rounded font-mono text-gray-700 flex-1">{cmd}</code>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
