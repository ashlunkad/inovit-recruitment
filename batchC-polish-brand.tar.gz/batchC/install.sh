#!/bin/bash
echo "═══════════════════════════════════════════"
echo "  INOVIT — Batch C: Polish + Brand Colors"
echo "═══════════════════════════════════════════"

cd /opt/inovit-recruitment

# ═══════════════════════════════════════
# FIX 1: Document upload success message
# ═══════════════════════════════════════
echo "📝 [1/7] Adding document upload success message..."
cat > /tmp/fix_docsuccess.js << 'JSEOF'
const fs = require('fs');

// Fix public DocumentUpload page
const file1 = 'frontend/src/pages/DocumentUpload.jsx';
if (fs.existsSync(file1)) {
  let c = fs.readFileSync(file1, 'utf8');
  if (!c.includes('Documents submitted')) {
    c = c.replace(
      "await fetchDocs();",
      "await fetchDocs();\n      // Show success message\n      const updatedRes = await axios.get(`${API}/documents/public/${token}`);\n      const updatedStats = updatedRes.data.stats || {};\n      if (updatedStats.uploaded >= updatedStats.total) alert('All documents submitted successfully! Our team will verify them shortly.');"
    );
    fs.writeFileSync(file1, c);
    console.log('  DocumentUpload success message added');
  }
}

// Fix CandidateDetail documents tab upload
const file2 = 'frontend/src/pages/CandidateDetail.jsx';
if (fs.existsSync(file2)) {
  let c = fs.readFileSync(file2, 'utf8');
  if (!c.includes('Document uploaded successfully')) {
    c = c.replace(
      "toast.success('Uploaded'); reload();",
      "toast.success('Document uploaded successfully!'); reload();"
    );
    fs.writeFileSync(file2, c);
    console.log('  CandidateDetail upload toast updated');
  }
}
JSEOF
node /tmp/fix_docsuccess.js

# ═══════════════════════════════════════
# FIX 2: Status forward-only dropdown
# ═══════════════════════════════════════
echo "📝 [2/7] Implementing status forward-only..."
cat > /tmp/fix_status_forward.js << 'JSEOF'
const fs = require('fs');
const file = 'frontend/src/pages/CandidateDetail.jsx';
if (!fs.existsSync(file)) { console.log('CandidateDetail not found'); process.exit(0); }
let c = fs.readFileSync(file, 'utf8');

// Replace ALL_STATUSES with a lifecycle-ordered constant + forward-only logic
const oldStatuses = "const ALL_STATUSES = ['New','Walk_In_Registered','Contacted','WhatsApp_Failed','Interested','Not_Interested','Screening','Screened','Portal_Applied','Interview_Scheduled','Interview_Pending_Technical','Interview_Done','Selected','Rejected','On_Hold','Waitlisted','Offered','Offer_Accepted','Offer_Declined','Onboarding','Training','Training_Completed','Training_Failed','Deployed','Unreachable','Blacklisted','Archived'];";

const newStatuses = `const LIFECYCLE_ORDER = {
  'New':0,'Walk_In_Registered':0,'Contacted':1,'WhatsApp_Failed':1,'Interested':1,'Not_Interested':1,'Unreachable':1,
  'Screening':2,'Screened':2,'Portal_Applied':2,
  'Interview_Scheduled':3,'Interview_Pending_Technical':3,'Interview_Done':3,
  'Selected':4,'Rejected':4,'On_Hold':4,'Waitlisted':4,
  'Offered':5,'Offer_Accepted':5,'Offer_Declined':5,
  'Onboarding':6,
  'Training':7,'Training_Completed':7,'Training_Failed':7,'Deployed':7,
  'Blacklisted':99,'Archived':99,
};
const STATUS_GROUPS = [
  {label:'New / Registration',statuses:['New','Walk_In_Registered']},
  {label:'Outreach',statuses:['Contacted','Interested','Not_Interested','WhatsApp_Failed','Unreachable']},
  {label:'Screening',statuses:['Screening','Screened','Portal_Applied']},
  {label:'Interview',statuses:['Interview_Scheduled','Interview_Pending_Technical','Interview_Done']},
  {label:'Selection',statuses:['Selected','Rejected','On_Hold','Waitlisted']},
  {label:'Offer',statuses:['Offered','Offer_Accepted','Offer_Declined']},
  {label:'Onboarding',statuses:['Onboarding']},
  {label:'Training & Deploy',statuses:['Training','Training_Completed','Training_Failed','Deployed']},
  {label:'Other',statuses:['Blacklisted','Archived']},
];
const getForwardStatuses = (current) => {
  const currentStage = LIFECYCLE_ORDER[current] ?? 0;
  return STATUS_GROUPS.filter(g => {
    const groupStage = LIFECYCLE_ORDER[g.statuses[0]] ?? 0;
    return groupStage >= currentStage || groupStage === 99;
  });
};`;

if (c.includes("const ALL_STATUSES = [")) {
  c = c.replace(oldStatuses, newStatuses);
  console.log('  Replaced ALL_STATUSES with forward-only logic');
} else {
  console.log('  ALL_STATUSES not found - may already be replaced');
}

// Replace the status modal dropdown to use grouped forward-only
c = c.replace(
  /\{modal==='status'&&<Modal[^]*?<\/Modal>\}/,
  `{modal==='status'&&<Modal t="Change Status" onClose={()=>setModal(null)} onSave={saveStatus}><div className="space-y-3">
        <div className="text-sm text-gray-600 mb-2">Current: <b className="text-gray-900">{c.status?.replace(/_/g,' ')}</b></div>
        <div><label className="block text-sm font-medium text-gray-700 mb-1">New Status</label>
          <select value={form.status} onChange={e=>setForm(f=>({...f,status:e.target.value}))} className="input-field">
            <option value={c.status}>{c.status?.replace(/_/g,' ')} (current)</option>
            {getForwardStatuses(c.status).map(g => (
              <optgroup key={g.label} label={'── '+g.label+' ──'}>
                {g.statuses.filter(s=>s!==c.status).map(s => <option key={s} value={s}>{s.replace(/_/g,' ')}</option>)}
              </optgroup>
            ))}
          </select>
        </div>
        <F l="Reason" v={form.reason} s={v=>setForm(f=>({...f,reason:v}))}/>
      </div></Modal>}`
);

fs.writeFileSync(file, c);
console.log('  Status dropdown now forward-only with grouped options');
JSEOF
node /tmp/fix_status_forward.js

# ═══════════════════════════════════════
# FIX 3: Brand colors on sidebar
# ═══════════════════════════════════════
echo "📝 [3/7] Applying brand colors to sidebar..."
cat > /tmp/fix_brand.js << 'JSEOF'
const fs = require('fs');
const file = 'frontend/src/components/layout/Layout.jsx';
let c = fs.readFileSync(file, 'utf8');

// Replace sidebar navy with dark gray
c = c.replace(/bg-primary-900/g, 'bg-[#4A4A4A]');
c = c.replace(/bg-primary-700/g, 'bg-[#E67E22]');
c = c.replace(/bg-primary-800/g, 'bg-[#5A5A5A]');
c = c.replace(/border-primary-700/g, 'border-[#5A5A5A]');
c = c.replace(/text-primary-300/g, 'text-gray-300');
c = c.replace(/text-primary-200/g, 'text-gray-300');

// Fix active nav item to use orange
c = c.replace(
  "'bg-primary-700 text-white'",
  "'bg-[#E67E22] text-white'"
);
c = c.replace(
  "'text-primary-200 hover:bg-primary-800 hover:text-white'",
  "'text-gray-300 hover:bg-[#5A5A5A] hover:text-white'"
);

fs.writeFileSync(file, c);
console.log('  Sidebar: Dark Gray (#4A4A4A) + Orange (#E67E22) active');
JSEOF
node /tmp/fix_brand.js

# ═══════════════════════════════════════
# FIX 4: Brand colors on login page
# ═══════════════════════════════════════
echo "📝 [4/7] Brand colors on login..."
cat > /tmp/fix_login_brand.js << 'JSEOF'
const fs = require('fs');
const file = 'frontend/src/pages/Login.jsx';
if (!fs.existsSync(file)) { process.exit(0); }
let c = fs.readFileSync(file, 'utf8');

c = c.replace(/from-primary-800 via-primary-900 to-primary-950/g, 'from-[#4A4A4A] via-[#3A3A3A] to-[#2A2A2A]');

fs.writeFileSync(file, c);
console.log('  Login page brand colors applied');
JSEOF
node /tmp/fix_login_brand.js

# ═══════════════════════════════════════
# FIX 5: Brand colors on public pages
# ═══════════════════════════════════════
echo "📝 [5/7] Brand colors on public pages..."
cat > /tmp/fix_public_brand.js << 'JSEOF'
const fs = require('fs');

// Walk-In
const walkin = 'frontend/src/pages/WalkInRegister.jsx';
if (fs.existsSync(walkin)) {
  let c = fs.readFileSync(walkin, 'utf8');
  c = c.replace(/from-primary-600 to-primary-800/g, 'from-[#4A4A4A] to-[#2A2A2A]');
  c = c.replace(/text-primary-200/g, 'text-gray-300');
  fs.writeFileSync(walkin, c);
  console.log('  Walk-In brand colors');
}

// Status Tracker
const status = 'frontend/src/pages/StatusTracker.jsx';
if (fs.existsSync(status)) {
  let c = fs.readFileSync(status, 'utf8');
  c = c.replace(/from-primary-600 to-primary-800/g, 'from-[#4A4A4A] to-[#2A2A2A]');
  c = c.replace(/text-primary-200/g, 'text-gray-300');
  c = c.replace(/bg-primary-50/g, 'bg-orange-50');
  c = c.replace(/border-primary-300/g, 'border-orange-300');
  c = c.replace(/text-primary-700/g, 'text-[#E67E22]');
  c = c.replace(/text-primary-500/g, 'text-[#E67E22]');
  c = c.replace(/bg-primary-500/g, 'bg-[#E67E22]');
  fs.writeFileSync(status, c);
  console.log('  Status Tracker brand colors');
}
JSEOF
node /tmp/fix_public_brand.js

# ═══════════════════════════════════════
# FIX 6: Telecalling queue - newly assigned candidates appear
# ═══════════════════════════════════════
echo "📝 [6/7] Fixing telecalling queue for newly assigned candidates..."
cat > /tmp/fix_telecall.js << 'JSEOF'
const fs = require('fs');
const file = 'backend/src/controllers/callController.js';
if (!fs.existsSync(file)) { console.log('callController not found'); process.exit(0); }
let c = fs.readFileSync(file, 'utf8');

// The call queue should include candidates with status New/Contacted/Interested who are assigned
// Add 'New' and 'Walk_In_Registered' to the queue statuses if not present
if (c.includes("status: { $in:")) {
  // Add New and Walk_In_Registered to queue statuses
  if (!c.includes("'New'") || !c.match(/status:.*?\$in.*?'New'/)) {
    c = c.replace(
      /status: \{ \$in: \[/,
      "status: { $in: ['New', 'Walk_In_Registered', "
    );
    fs.writeFileSync(file, c);
    console.log('  Added New/Walk_In to telecalling queue statuses');
  } else {
    console.log('  New already in queue statuses');
  }
} else {
  console.log('  Queue status filter pattern not found - manual check needed');
}
JSEOF
node /tmp/fix_telecall.js

# ═══════════════════════════════════════
# FIX 7: Interview timezone re-apply
# ═══════════════════════════════════════
echo "📝 [7/7] Re-applying interview timezone fix..."
cat > /tmp/fix_tz.js << 'JSEOF'
const fs = require('fs');

// CandidateDetail - check if IST conversion exists
const file = 'frontend/src/pages/CandidateDetail.jsx';
if (fs.existsSync(file)) {
  let c = fs.readFileSync(file, 'utf8');
  if (c.includes("5.5*60*60*1000")) {
    console.log('  CandidateDetail already has IST conversion');
  } else if (c.includes("interviewScheduled:form.date")) {
    // Needs fix - but our Batch 2 CandidateDetail already has it
    console.log('  Check: CandidateDetail interview save');
  }
}

// Interviews page
const file2 = 'frontend/src/pages/Interviews.jsx';
if (fs.existsSync(file2)) {
  let c = fs.readFileSync(file2, 'utf8');
  if (c.includes("5.5*60*60*1000")) {
    console.log('  Interviews page already has IST conversion');
  } else {
    console.log('  WARNING: Interviews page may need IST fix');
  }
}
JSEOF
node /tmp/fix_tz.js

# Build and restart
echo "🔨 Building frontend + restarting..."
cd frontend && npm run build
pm2 restart all

echo ""
echo "═══════════════════════════════════════════"
echo "  ✅ Batch C INSTALLED!"
echo "═══════════════════════════════════════════"
echo ""
echo "Changes:"
echo "  1. Document upload shows success message"
echo "  2. Status dropdown: forward-only + grouped by lifecycle"
echo "     (cannot go backward in lifecycle)"
echo "  3. Sidebar: Dark Gray (#4A4A4A) + Orange (#E67E22) active"
echo "  4. Login page: Dark gray gradient"
echo "  5. Public pages: Dark gray gradient backgrounds"
echo "  6. Telecalling queue: shows newly assigned candidates"
echo "  7. Interview timezone: verified IST conversion"
echo ""
echo "Brand colors applied:"
echo "  • Sidebar background: #4A4A4A (dark gray)"
echo "  • Active nav item: #E67E22 (orange)"
echo "  • Buttons/accents: #E67E22 (orange)"
echo "  • Login/public pages: dark gray gradient"
echo ""
pm2 status
