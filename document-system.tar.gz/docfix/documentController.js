const { Candidate } = require('../models');
const TimelineService = require('../services/timelineService');
const path = require('path');
const fs = require('fs');

const DOC_TYPES = [
  { key: 'aadhaar_front', label: 'Aadhaar Card — Front', required: true },
  { key: 'aadhaar_back', label: 'Aadhaar Card — Back', required: true },
  { key: 'pan', label: 'PAN Card', required: true },
  { key: 'qualification', label: 'Qualification Certificate', required: true },
  { key: 'experience_letter', label: 'Experience / Relieving Letter', required: false },
  { key: 'photo', label: 'Passport Size Photo', required: true },
];

// Get document types list
exports.getDocTypes = (req, res) => {
  res.json({ docTypes: DOC_TYPES });
};

// Get documents for a candidate
exports.getCandidateDocs = async (req, res) => {
  try {
    const candidate = await Candidate.findById(req.params.id).select('fullName candidateId documents statusToken');
    if (!candidate) return res.status(404).json({ error: 'Candidate not found' });

    const docs = DOC_TYPES.map(dt => {
      const uploaded = (candidate.documents || []).find(d => d.type === dt.key);
      return {
        ...dt,
        status: uploaded ? uploaded.status : 'not_uploaded',
        url: uploaded?.url || null,
        uploadedAt: uploaded?.uploadedAt || null,
        verified: uploaded?.verified || false,
        verifiedBy: uploaded?.verifiedBy || null,
        verifiedAt: uploaded?.verifiedAt || null,
        rejectionReason: uploaded?.rejectionReason || null,
      };
    });

    const stats = {
      total: DOC_TYPES.filter(d => d.required).length,
      uploaded: docs.filter(d => d.status !== 'not_uploaded').length,
      verified: docs.filter(d => d.status === 'verified').length,
      rejected: docs.filter(d => d.status === 'rejected').length,
      pending: docs.filter(d => d.status === 'pending').length,
    };

    res.json({ docs, stats, candidateName: candidate.fullName, candidateId: candidate.candidateId });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// Upload document (HR upload — requires auth)
exports.uploadDoc = async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ error: 'No file uploaded' });
    const { docType } = req.body;
    if (!docType || !DOC_TYPES.find(d => d.key === docType)) return res.status(400).json({ error: 'Invalid document type' });

    const candidate = await Candidate.findById(req.params.id);
    if (!candidate) return res.status(404).json({ error: 'Candidate not found' });

    const fileUrl = '/uploads/' + req.file.filename;

    // Remove old doc of same type if exists
    candidate.documents = (candidate.documents || []).filter(d => d.type !== docType);

    // Add new doc
    candidate.documents.push({
      type: docType,
      url: fileUrl,
      uploadedAt: new Date(),
      verified: false,
      status: 'pending',
    });

    await candidate.save();

    await TimelineService.addEvent(candidate._id, 'document_event', {
      channel: 'system',
      content: `Document uploaded: ${DOC_TYPES.find(d => d.key === docType)?.label || docType}`,
      createdByName: req.user?.name || 'System',
    }, req.user?._id);

    res.json({ success: true, message: 'Document uploaded', url: fileUrl });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// Public upload (candidate self-upload via token — no auth)
exports.publicUpload = async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ error: 'No file uploaded' });
    const { token } = req.params;
    const { docType } = req.body;

    if (!docType || !DOC_TYPES.find(d => d.key === docType)) return res.status(400).json({ error: 'Invalid document type' });

    const candidate = await Candidate.findOne({ statusToken: token });
    if (!candidate) return res.status(404).json({ error: 'Invalid link' });

    const fileUrl = '/uploads/' + req.file.filename;

    candidate.documents = (candidate.documents || []).filter(d => d.type !== docType);
    candidate.documents.push({
      type: docType,
      url: fileUrl,
      uploadedAt: new Date(),
      verified: false,
      status: 'pending',
    });

    await candidate.save();

    await TimelineService.addEvent(candidate._id, 'document_event', {
      channel: 'system',
      content: `Document self-uploaded by candidate: ${DOC_TYPES.find(d => d.key === docType)?.label || docType}`,
    });

    res.json({ success: true, message: 'Document uploaded' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// Get public doc status (candidate facing — no auth)
exports.publicDocStatus = async (req, res) => {
  try {
    const { token } = req.params;
    const candidate = await Candidate.findOne({ statusToken: token }).select('fullName candidateId documents');
    if (!candidate) return res.status(404).json({ error: 'Invalid link' });

    const docs = DOC_TYPES.map(dt => {
      const uploaded = (candidate.documents || []).find(d => d.type === dt.key);
      return {
        ...dt,
        status: uploaded ? uploaded.status : 'not_uploaded',
        uploadedAt: uploaded?.uploadedAt || null,
        rejectionReason: uploaded?.rejectionReason || null,
      };
    });

    const stats = {
      total: DOC_TYPES.filter(d => d.required).length,
      uploaded: docs.filter(d => d.status !== 'not_uploaded').length,
      verified: docs.filter(d => d.status === 'verified').length,
      pending: docs.filter(d => d.status === 'pending').length,
      rejected: docs.filter(d => d.status === 'rejected').length,
    };

    res.json({ docs, stats, candidateName: candidate.fullName, candidateId: candidate.candidateId });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// Verify document (Team Lead / Admin only)
exports.verifyDoc = async (req, res) => {
  try {
    const { docType, action, rejectionReason } = req.body;
    if (!['approve', 'reject'].includes(action)) return res.status(400).json({ error: 'Action must be approve or reject' });

    const candidate = await Candidate.findById(req.params.id);
    if (!candidate) return res.status(404).json({ error: 'Candidate not found' });

    const doc = (candidate.documents || []).find(d => d.type === docType);
    if (!doc) return res.status(404).json({ error: 'Document not found' });

    if (action === 'approve') {
      doc.status = 'verified';
      doc.verified = true;
      doc.verifiedBy = req.user._id;
      doc.verifiedAt = new Date();
      doc.rejectionReason = null;
    } else {
      doc.status = 'rejected';
      doc.verified = false;
      doc.rejectionReason = rejectionReason || 'Document not acceptable';
    }

    await candidate.save();

    const docLabel = DOC_TYPES.find(d => d.key === docType)?.label || docType;
    await TimelineService.addEvent(candidate._id, 'document_event', {
      channel: 'system',
      content: `Document ${action === 'approve' ? 'verified' : 'rejected'}: ${docLabel}${action === 'reject' ? ' — ' + (rejectionReason || '') : ''}`,
      createdByName: req.user.name,
    }, req.user._id);

    res.json({ success: true, message: `Document ${action}d` });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// Get all candidates with pending documents (review queue)
exports.getDocQueue = async (req, res) => {
  try {
    const candidates = await Candidate.find({
      'documents.status': 'pending',
      status: { $nin: ['Rejected', 'Blacklisted', 'Archived'] }
    })
      .select('fullName candidateId phone status documents preferredLocation')
      .populate('preferredLocation', 'name city')
      .sort('updatedAt')
      .limit(100);

    const queue = candidates.map(c => {
      const docs = c.documents || [];
      return {
        _id: c._id,
        fullName: c.fullName,
        candidateId: c.candidateId,
        phone: c.phone,
        status: c.status,
        location: c.preferredLocation?.name || '-',
        totalDocs: docs.length,
        pendingDocs: docs.filter(d => d.status === 'pending').length,
        verifiedDocs: docs.filter(d => d.status === 'verified').length,
        rejectedDocs: docs.filter(d => d.status === 'rejected').length,
        pendingTypes: docs.filter(d => d.status === 'pending').map(d => d.type),
        oldestPending: docs.filter(d => d.status === 'pending').sort((a, b) => new Date(a.uploadedAt) - new Date(b.uploadedAt))[0]?.uploadedAt,
      };
    });

    res.json({ queue, total: queue.length });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
