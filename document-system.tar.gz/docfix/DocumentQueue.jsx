import { useState, useEffect } from 'react';
import api from '../services/api';
import { useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import { FileCheck, Clock, CheckCircle, XCircle, Eye, X, ChevronDown } from 'lucide-react';

const DOC_LABELS = { aadhaar_front: 'Aadhaar Front', aadhaar_back: 'Aadhaar Back', pan: 'PAN Card', qualification: 'Qualification Cert', experience_letter: 'Experience Letter', photo: 'Passport Photo' };
const fmtIST = (d) => d ? new Date(d).toLocaleString('en-IN', { dateStyle: 'short', timeStyle: 'short', timeZone: 'Asia/Kolkata' }) : '-';

export default function DocumentQueue() {
  const [queue, setQueue] = useState([]);
  const [loading, setLoading] = useState(true);
  const [reviewModal, setReviewModal] = useState(null); // { candidateId, candidateName }
  const [docs, setDocs] = useState([]);
  const [docStats, setDocStats] = useState({});
  const [previewUrl, setPreviewUrl] = useState(null);
  const [rejectReason, setRejectReason] = useState('');
  const navigate = useNavigate();

  const fetchQueue = async () => {
    setLoading(true);
    try {
      const res = await api.get('/documents/queue');
      setQueue(res.data.queue || []);
    } catch (err) { console.error(err); }
    finally { setLoading(false); }
  };

  useEffect(() => { fetchQueue(); }, []);

  const openReview = async (candidate) => {
    try {
      const res = await api.get('/documents/' + candidate._id);
      setDocs(res.data.docs || []);
      setDocStats(res.data.stats || {});
      setReviewModal(candidate);
    } catch { toast.error('Failed to load documents'); }
  };

  const verifyDoc = async (docType, action) => {
    try {
      await api.post('/documents/' + reviewModal._id + '/verify', {
        docType,
        action,
        rejectionReason: action === 'reject' ? (rejectReason || 'Document not acceptable') : undefined,
      });
      toast.success('Document ' + (action === 'approve' ? 'approved' : 'rejected'));
      setRejectReason('');
      // Refresh docs
      const res = await api.get('/documents/' + reviewModal._id);
      setDocs(res.data.docs || []);
      setDocStats(res.data.stats || {});
      fetchQueue();
    } catch (err) { toast.error(err.response?.data?.error || 'Failed'); }
  };

  const statusBadge = (status) => {
    if (status === 'verified') return <span className="badge bg-green-100 text-green-700 text-xs flex items-center gap-0.5"><CheckCircle size={11} /> Verified</span>;
    if (status === 'rejected') return <span className="badge bg-red-100 text-red-700 text-xs flex items-center gap-0.5"><XCircle size={11} /> Rejected</span>;
    if (status === 'pending') return <span className="badge bg-yellow-100 text-yellow-700 text-xs flex items-center gap-0.5"><Clock size={11} /> Pending</span>;
    return <span className="badge bg-gray-100 text-gray-500 text-xs">Not Uploaded</span>;
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-gray-900">Document Verification Queue</h1>
        <div className="flex items-center gap-2">
          <span className="text-sm text-gray-500">{queue.length} candidates with pending docs</span>
          <button onClick={fetchQueue} className="btn-outline text-sm">Refresh</button>
        </div>
      </div>

      {loading ? (
        <div className="flex justify-center py-12"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary-600"></div></div>
      ) : queue.length === 0 ? (
        <div className="card text-center py-12 text-gray-400">
          <FileCheck size={48} className="mx-auto mb-3 text-gray-300" />
          <p>No pending documents to review</p>
        </div>
      ) : (
        <div className="bg-white rounded-xl shadow-sm border overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-gray-50 border-b">
              <tr>
                <th className="px-4 py-3 text-left font-medium text-gray-500">Candidate</th>
                <th className="px-4 py-3 text-left font-medium text-gray-500">Status</th>
                <th className="px-4 py-3 text-left font-medium text-gray-500">Location</th>
                <th className="px-4 py-3 text-center font-medium text-gray-500">Pending</th>
                <th className="px-4 py-3 text-center font-medium text-gray-500">Verified</th>
                <th className="px-4 py-3 text-center font-medium text-gray-500">Rejected</th>
                <th className="px-4 py-3 text-left font-medium text-gray-500">Pending Types</th>
                <th className="px-4 py-3 text-left font-medium text-gray-500">Oldest</th>
                <th className="px-4 py-3 text-center font-medium text-gray-500">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {queue.map(c => (
                <tr key={c._id} className="hover:bg-gray-50">
                  <td className="px-4 py-3 cursor-pointer" onClick={() => navigate('/candidates/' + c._id)}>
                    <div className="font-medium text-gray-900">{c.fullName}</div>
                    <div className="text-xs text-gray-400">{c.candidateId} • {c.phone}</div>
                  </td>
                  <td className="px-4 py-3"><span className="badge bg-gray-100 text-gray-600 text-xs">{c.status?.replace(/_/g, ' ')}</span></td>
                  <td className="px-4 py-3 text-xs text-gray-600">{c.location}</td>
                  <td className="px-4 py-3 text-center"><span className="font-bold text-yellow-600">{c.pendingDocs}</span></td>
                  <td className="px-4 py-3 text-center"><span className="font-bold text-green-600">{c.verifiedDocs}</span></td>
                  <td className="px-4 py-3 text-center"><span className="font-bold text-red-500">{c.rejectedDocs}</span></td>
                  <td className="px-4 py-3">
                    <div className="flex flex-wrap gap-1">
                      {c.pendingTypes?.map(t => <span key={t} className="text-xs bg-yellow-50 text-yellow-700 px-1.5 py-0.5 rounded">{DOC_LABELS[t] || t}</span>)}
                    </div>
                  </td>
                  <td className="px-4 py-3 text-xs text-gray-500">{fmtIST(c.oldestPending)}</td>
                  <td className="px-4 py-3 text-center">
                    <button onClick={() => openReview(c)} className="bg-primary-600 hover:bg-primary-700 text-white text-xs py-1.5 px-3 rounded-lg flex items-center gap-1 mx-auto">
                      <Eye size={13} /> Review
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Review Modal */}
      {reviewModal && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between p-5 border-b">
              <div>
                <h3 className="text-lg font-bold text-gray-900">Review Documents</h3>
                <p className="text-sm text-gray-500">{reviewModal.fullName} • {reviewModal.candidateId}</p>
              </div>
              <button onClick={() => { setReviewModal(null); setPreviewUrl(null); }} className="text-gray-400 hover:text-gray-600"><X size={20} /></button>
            </div>

            <div className="p-5">
              {/* Progress bar */}
              <div className="flex items-center gap-3 mb-4 text-sm">
                <span className="text-green-600 font-medium">{docStats.verified || 0} verified</span>
                <span className="text-yellow-600 font-medium">{docStats.pending || 0} pending</span>
                <span className="text-red-500 font-medium">{docStats.rejected || 0} rejected</span>
                <div className="flex-1 bg-gray-200 rounded-full h-2">
                  <div className="bg-green-500 h-2 rounded-full" style={{ width: ((docStats.verified || 0) / (docStats.total || 1) * 100) + '%' }}></div>
                </div>
                <span className="text-gray-500">{docStats.verified || 0}/{docStats.total || 0}</span>
              </div>

              {/* Document list */}
              <div className="space-y-3">
                {docs.map(doc => (
                  <div key={doc.key} className={'border rounded-lg p-4 ' + (doc.status === 'verified' ? 'border-green-200 bg-green-50' : doc.status === 'rejected' ? 'border-red-200 bg-red-50' : doc.status === 'pending' ? 'border-yellow-200 bg-yellow-50' : 'border-gray-200')}>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div>
                          <div className="font-medium text-gray-800 text-sm">{doc.label} {doc.required && <span className="text-red-500">*</span>}</div>
                          {doc.uploadedAt && <div className="text-xs text-gray-400">Uploaded: {fmtIST(doc.uploadedAt)}</div>}
                          {doc.rejectionReason && <div className="text-xs text-red-600 mt-0.5">Reason: {doc.rejectionReason}</div>}
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        {statusBadge(doc.status)}
                      </div>
                    </div>

                    {doc.url && (
                      <div className="mt-3 flex items-center gap-2">
                        <button onClick={() => setPreviewUrl(doc.url === previewUrl ? null : doc.url)} className="btn-outline text-xs py-1">
                          {previewUrl === doc.url ? 'Hide' : 'Preview'}
                        </button>
                        <a href={doc.url} target="_blank" rel="noopener noreferrer" className="btn-outline text-xs py-1">Download</a>

                        {doc.status === 'pending' && (
                          <>
                            <button onClick={() => verifyDoc(doc.key, 'approve')} className="bg-green-600 hover:bg-green-700 text-white text-xs py-1 px-3 rounded-lg">Approve</button>
                            <div className="flex items-center gap-1">
                              <input value={rejectReason} onChange={e => setRejectReason(e.target.value)} placeholder="Reason..." className="input-field text-xs py-1 w-36" />
                              <button onClick={() => verifyDoc(doc.key, 'reject')} className="bg-red-500 hover:bg-red-600 text-white text-xs py-1 px-3 rounded-lg">Reject</button>
                            </div>
                          </>
                        )}
                      </div>
                    )}

                    {previewUrl === doc.url && doc.url && (
                      <div className="mt-3 border rounded-lg overflow-hidden bg-white">
                        {doc.url.match(/\.(jpg|jpeg|png|webp)$/i) ? (
                          <img src={doc.url} alt={doc.label} className="max-w-full max-h-96 mx-auto" />
                        ) : (
                          <iframe src={doc.url} className="w-full h-96" title={doc.label}></iframe>
                        )}
                      </div>
                    )}

                    {!doc.url && <div className="mt-2 text-xs text-gray-400">Not uploaded yet</div>}
                  </div>
                ))}
              </div>
            </div>

            <div className="flex gap-3 justify-end p-5 border-t">
              <button onClick={() => { setReviewModal(null); setPreviewUrl(null); }} className="btn-outline text-sm">Close</button>
              <button onClick={() => { setReviewModal(null); navigate('/candidates/' + reviewModal._id); }} className="btn-primary text-sm">Full Profile</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
