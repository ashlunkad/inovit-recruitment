import { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios';
import { Upload, CheckCircle, XCircle, Clock, FileText, AlertCircle } from 'lucide-react';

const API = import.meta.env.VITE_API_URL || '/api';
const DOC_LABELS = { aadhaar_front: 'Aadhaar Card — Front', aadhaar_back: 'Aadhaar Card — Back', pan: 'PAN Card', qualification: 'Qualification Certificate', experience_letter: 'Experience / Relieving Letter', photo: 'Passport Size Photo' };

export default function DocumentUpload() {
  const { token } = useParams();
  const [docs, setDocs] = useState([]);
  const [stats, setStats] = useState({});
  const [candidateName, setCandidateName] = useState('');
  const [candidateId, setCandidateId] = useState('');
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(null);
  const [error, setError] = useState('');

  const fetchDocs = async () => {
    try {
      const res = await axios.get(`${API}/documents/public/${token}`);
      setDocs(res.data.docs || []);
      setStats(res.data.stats || {});
      setCandidateName(res.data.candidateName);
      setCandidateId(res.data.candidateId);
    } catch (err) {
      setError('Invalid or expired link. Please contact HR.');
    } finally { setLoading(false); }
  };

  useEffect(() => { fetchDocs(); }, [token]);

  const handleUpload = async (docType, file) => {
    if (!file) return;
    const maxSize = 5 * 1024 * 1024; // 5MB
    if (file.size > maxSize) { alert('File too large. Maximum 5MB allowed.'); return; }

    setUploading(docType);
    try {
      const formData = new FormData();
      formData.append('file', file);
      formData.append('docType', docType);
      await axios.post(`${API}/documents/public/${token}/upload`, formData, {
        headers: { 'Content-Type': 'multipart/form-data' }
      });
      await fetchDocs();
    } catch (err) {
      alert(err.response?.data?.error || 'Upload failed. Please try again.');
    } finally { setUploading(null); }
  };

  const statusIcon = (status) => {
    if (status === 'verified') return <CheckCircle size={20} className="text-green-500" />;
    if (status === 'rejected') return <XCircle size={20} className="text-red-500" />;
    if (status === 'pending') return <Clock size={20} className="text-yellow-500" />;
    return <FileText size={20} className="text-gray-300" />;
  };

  const statusText = (status) => {
    if (status === 'verified') return 'Verified ✓';
    if (status === 'rejected') return 'Rejected — Please re-upload';
    if (status === 'pending') return 'Uploaded — Under review';
    return 'Not uploaded';
  };

  if (loading) return <div className="min-h-screen bg-gray-50 flex items-center justify-center"><div className="animate-spin rounded-full h-10 w-10 border-b-2 border-blue-600"></div></div>;
  if (error) return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-xl max-w-md w-full p-8 text-center">
        <AlertCircle size={48} className="mx-auto text-red-500 mb-4" />
        <h1 className="text-xl font-bold text-gray-900 mb-2">Link Not Valid</h1>
        <p className="text-gray-600">{error}</p>
      </div>
    </div>
  );

  const allDone = stats.verified >= stats.total;

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-600 to-blue-800 py-8 px-4">
      <div className="max-w-lg mx-auto">
        {/* Header */}
        <div className="text-center text-white mb-6">
          <h1 className="text-3xl font-bold">INOVIT</h1>
          <p className="text-blue-200 text-sm">Solutions Private Limited</p>
        </div>

        <div className="bg-white rounded-2xl shadow-xl p-6 md:p-8">
          <div className="text-center mb-6">
            <h2 className="text-xl font-bold text-gray-900">Document Upload</h2>
            <p className="text-sm text-gray-500 mt-1">Welcome, {candidateName} ({candidateId})</p>
          </div>

          {/* Progress */}
          <div className="mb-6">
            <div className="flex items-center justify-between text-sm mb-2">
              <span className="text-gray-600">Progress</span>
              <span className="font-bold text-blue-700">{stats.verified || 0} / {stats.total || 0} verified</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-3">
              <div className="bg-green-500 h-3 rounded-full transition-all" style={{ width: ((stats.verified || 0) / (stats.total || 1) * 100) + '%' }}></div>
            </div>
            {allDone && (
              <div className="mt-3 p-3 bg-green-50 border border-green-200 rounded-lg text-center">
                <CheckCircle size={24} className="mx-auto text-green-500 mb-1" />
                <p className="text-sm font-medium text-green-700">All documents verified! You're all set.</p>
              </div>
            )}
          </div>

          {/* Document list */}
          <div className="space-y-4">
            {docs.map(doc => (
              <div key={doc.key} className={'border-2 rounded-xl p-4 transition ' +
                (doc.status === 'verified' ? 'border-green-300 bg-green-50' :
                 doc.status === 'rejected' ? 'border-red-300 bg-red-50' :
                 doc.status === 'pending' ? 'border-yellow-300 bg-yellow-50' :
                 'border-gray-200 border-dashed')}>

                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    {statusIcon(doc.status)}
                    <div>
                      <div className="font-medium text-gray-800 text-sm">
                        {DOC_LABELS[doc.key] || doc.key}
                        {doc.required && <span className="text-red-500 ml-1">*</span>}
                      </div>
                      <div className={'text-xs ' + (doc.status === 'verified' ? 'text-green-600' : doc.status === 'rejected' ? 'text-red-600' : doc.status === 'pending' ? 'text-yellow-600' : 'text-gray-400')}>
                        {statusText(doc.status)}
                      </div>
                    </div>
                  </div>
                </div>

                {doc.rejectionReason && (
                  <div className="mb-2 p-2 bg-red-100 rounded text-xs text-red-700">
                    Reason: {doc.rejectionReason}. Please upload a clear, valid document.
                  </div>
                )}

                {(doc.status === 'not_uploaded' || doc.status === 'rejected') && (
                  <label className="flex items-center justify-center gap-2 p-3 border-2 border-dashed border-gray-300 rounded-lg cursor-pointer hover:bg-gray-50 transition">
                    {uploading === doc.key ? (
                      <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-blue-600"></div>
                    ) : (
                      <>
                        <Upload size={18} className="text-gray-400" />
                        <span className="text-sm text-gray-600">{doc.status === 'rejected' ? 'Re-upload' : 'Upload'} — JPG, PNG, or PDF (max 5MB)</span>
                      </>
                    )}
                    <input type="file" accept=".jpg,.jpeg,.png,.pdf,.webp" className="hidden"
                      onChange={e => handleUpload(doc.key, e.target.files[0])} disabled={uploading === doc.key} />
                  </label>
                )}
              </div>
            ))}
          </div>

          <p className="text-center text-xs text-gray-400 mt-6">INOVIT Solutions Private Limited © 2026</p>
        </div>
      </div>
    </div>
  );
}
