#!/bin/bash
echo "═══════════════════════════════════════════"
echo "  INOVIT — Document Verification System"
echo "═══════════════════════════════════════════"

DIR="$(cd "$(dirname "$0")" && pwd)"
cd /opt/inovit-recruitment

# 1. Add document controller
echo "📝 [1/7] Adding document controller..."
cp "$DIR/documentController.js" backend/src/controllers/

# 2. Add rejectionReason to documents subdocument in Candidate model
echo "📝 [2/7] Updating Candidate model with rejectionReason..."
node -e "
const fs = require('fs');
const file = 'backend/src/models/Candidate.js';
let c = fs.readFileSync(file, 'utf8');
if (!c.includes('rejectionReason')) {
  c = c.replace(
    \"status: { type: String, enum: ['pending', 'verified', 'rejected', 'reupload'], default: 'pending' }\",
    \"status: { type: String, enum: ['pending', 'verified', 'rejected', 'reupload'], default: 'pending' },\n    rejectionReason: String\"
  );
  fs.writeFileSync(file, c);
  console.log('  Added rejectionReason to documents subdoc');
} else { console.log('  rejectionReason already exists'); }
"

# 3. Add document routes
echo "📝 [3/7] Adding document routes..."
node -e "
const fs = require('fs');
const file = 'backend/src/routes/index.js';
let c = fs.readFileSync(file, 'utf8');

if (!c.includes('documentCtrl')) {
  // Add import
  c = c.replace(
    \"const walkinCtrl = require('../controllers/walkinController');\",
    \"const walkinCtrl = require('../controllers/walkinController');\nconst documentCtrl = require('../controllers/documentController');\"
  );

  // Add routes before walk-in routes
  c = c.replace(
    \"// ── Walk-In (Public routes) ──\",
    \"// ── Documents ──\nrouter.get('/documents/types', auth, documentCtrl.getDocTypes);\nrouter.get('/documents/queue', auth, authorize('super_admin', 'team_lead'), documentCtrl.getDocQueue);\nrouter.get('/documents/:id', auth, documentCtrl.getCandidateDocs);\nrouter.post('/documents/:id/upload', auth, require('../middleware/upload').uploadDocument.single('file'), documentCtrl.uploadDoc);\nrouter.post('/documents/:id/verify', auth, authorize('super_admin', 'team_lead'), documentCtrl.verifyDoc);\n\n// ── Documents (Public — candidate self-upload) ──\nrouter.get('/documents/public/:token', documentCtrl.publicDocStatus);\nrouter.post('/documents/public/:token/upload', require('../middleware/upload').uploadDocument.single('file'), documentCtrl.publicUpload);\n\n// ── Walk-In (Public routes) ──\"
  );

  fs.writeFileSync(file, c);
  console.log('  Added document routes');
} else { console.log('  Document routes already exist'); }
"

# 4. Add frontend pages
echo "📝 [4/7] Adding DocumentQueue page..."
cp "$DIR/DocumentQueue.jsx" frontend/src/pages/

echo "📝 [5/7] Adding DocumentUpload page (public)..."
cp "$DIR/DocumentUpload.jsx" frontend/src/pages/

# 6. Update App.jsx with new routes
echo "📝 [6/7] Updating App.jsx..."
node -e "
const fs = require('fs');
const file = 'frontend/src/App.jsx';
let c = fs.readFileSync(file, 'utf8');

if (!c.includes('DocumentQueue')) {
  // Add imports
  c = c.replace(
    \"import Settings from './pages/Settings';\",
    \"import Settings from './pages/Settings';\nimport DocumentQueue from './pages/DocumentQueue';\nimport DocumentUpload from './pages/DocumentUpload';\"
  );

  // Add routes - doc queue (protected) and doc upload (public)
  c = c.replace(
    \"<Route path=\\\"settings\\\" element={<Settings />} />\",
    \"<Route path=\\\"documents\\\" element={<DocumentQueue />} />\n          <Route path=\\\"settings\\\" element={<Settings />} />\"
  );

  // Add public doc upload route
  c = c.replace(
    '<Route path=\"/status/:token\"',
    '<Route path=\"/documents/:token\" element={<DocumentUpload />} />\n        <Route path=\"/status/:token\"'
  );

  fs.writeFileSync(file, c);
  console.log('  Updated App.jsx');
} else { console.log('  App.jsx already has DocumentQueue'); }
"

# 7. Update Layout.jsx with nav item
echo "📝 [7/7] Updating Layout nav..."
node -e "
const fs = require('fs');
const file = 'frontend/src/components/layout/Layout.jsx';
let c = fs.readFileSync(file, 'utf8');

if (!c.includes('documents')) {
  // Add FileCheck import
  c = c.replace(
    'GraduationCap, Gift, Settings',
    'GraduationCap, Gift, Settings, FileCheck'
  );

  // Add nav item after Training
  c = c.replace(
    \"{ to: '/training', icon: GraduationCap, label: 'Training', roles: ['super_admin', 'team_lead'] },\",
    \"{ to: '/training', icon: GraduationCap, label: 'Training', roles: ['super_admin', 'team_lead'] },\n  { to: '/documents', icon: FileCheck, label: 'Documents', roles: ['super_admin', 'team_lead'] },\"
  );

  fs.writeFileSync(file, c);
  console.log('  Added Documents to nav');
} else { console.log('  Documents already in nav'); }
"

# Build and restart
echo "🔨 Building frontend..."
cd frontend && npm run build

echo "🔄 Restarting..."
pm2 restart all

echo ""
echo "═══════════════════════════════════════════"
echo "  ✅ Document Verification System INSTALLED!"
echo "═══════════════════════════════════════════"
echo ""
echo "New pages:"
echo "  • Documents (sidebar) — Review queue for Team Lead/Admin"
echo "    See all candidates with pending docs, approve/reject with preview"
echo ""
echo "  • hire.inovit.in/documents/{token} — Candidate self-upload"
echo "    Public page, no login, upload all required documents"
echo ""
echo "Required documents:"
echo "  1. Aadhaar Card — Front (mandatory)"
echo "  2. Aadhaar Card — Back (mandatory)"
echo "  3. PAN Card (mandatory)"
echo "  4. Qualification Certificate (mandatory)"
echo "  5. Experience / Relieving Letter (optional)"
echo "  6. Passport Size Photo (mandatory)"
echo ""
echo "How it works:"
echo "  1. Candidate/HR uploads docs → status: PENDING"
echo "  2. Team Lead/Admin opens Documents page → clicks Review"
echo "  3. Preview each doc → Approve or Reject (with reason)"
echo "  4. Rejected docs: candidate sees reason, re-uploads"
echo "  5. All mandatory docs verified → ready for deployment"
echo ""
echo "Share upload link with candidate:"
echo "  https://hire.inovit.in/documents/{statusToken}"
echo "  (Find statusToken in candidate detail page URL or database)"
echo ""
pm2 status
