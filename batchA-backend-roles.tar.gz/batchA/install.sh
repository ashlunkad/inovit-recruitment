#!/bin/bash
echo "═══════════════════════════════════════════════════"
echo "  INOVIT — Batch A: Backend (Roles + Permissions)"
echo "═══════════════════════════════════════════════════"

cd /opt/inovit-recruitment

# ═══════════════════════════════════════
# 1. Update User model — add new roles
# ═══════════════════════════════════════
echo "📝 [1/8] Adding new roles to User model..."
node -e "
const fs = require('fs');
const file = 'backend/src/models/User.js';
let c = fs.readFileSync(file, 'utf8');

// Replace role enum with 8 roles
c = c.replace(
  /role: \{[^}]*enum: \[[^\]]*\][^}]*\}/,
  \"role: { type: String, enum: ['super_admin', 'team_lead', 'hr', 'agent', 'telecaller', 'personal_interviewer', 'technical_interviewer', 'trainer'], required: true }\"
);

fs.writeFileSync(file, c);
console.log('  8 roles added: super_admin, team_lead, hr, agent, telecaller, personal_interviewer, technical_interviewer, trainer');
"

# ═══════════════════════════════════════
# 2. Update routes — new role permissions
# ═══════════════════════════════════════
echo "📝 [2/8] Updating route permissions..."
cat > backend/src/routes/index.js << 'ROUTESEOF'
const express = require('express');
const router = express.Router();
const { auth, authorize } = require('../middleware/auth');
const { uploadImport, uploadDocument } = require('../middleware/upload');

const authCtrl = require('../controllers/authController');
const candidateCtrl = require('../controllers/candidateController');
const importCtrl = require('../controllers/importController');
const callCtrl = require('../controllers/callController');
const locationCtrl = require('../controllers/locationController');
const dashboardCtrl = require('../controllers/dashboardController');
const walkinCtrl = require('../controllers/walkinController');

let documentCtrl, offerCtrl;
try { documentCtrl = require('../controllers/documentController'); } catch(e) {}
try { offerCtrl = require('../controllers/offerController'); } catch(e) {}

// ── Auth ──
router.post('/auth/login', authCtrl.login);
router.post('/auth/register', auth, authorize('super_admin'), authCtrl.register);
router.get('/auth/me', auth, authCtrl.getMe);
router.put('/auth/profile', auth, authCtrl.updateProfile);
if (authCtrl.changePassword) router.put('/auth/change-password', auth, authCtrl.changePassword);
router.get('/users', auth, authorize('super_admin', 'team_lead', 'hr'), authCtrl.getUsers);
router.put('/users/:id', auth, authorize('super_admin'), authCtrl.updateUser);
if (authCtrl.resetPassword) router.put('/users/:id/reset-password', auth, authorize('super_admin'), authCtrl.resetPassword);

// ── Dashboard ──
router.get('/dashboard/stats', auth, dashboardCtrl.getDashboardStats);

// ── Candidates ──
router.get('/candidates', auth, candidateCtrl.getCandidates);
router.get('/candidates/search-phone', auth, candidateCtrl.searchByPhone);
router.get('/candidates/pipeline-stats', auth, candidateCtrl.getPipelineStats);
router.get('/candidates/:id', auth, candidateCtrl.getCandidate);
router.post('/candidates', auth, authorize('super_admin', 'team_lead', 'hr', 'agent'), candidateCtrl.createCandidate);
router.put('/candidates/:id', auth, candidateCtrl.updateCandidate);
router.post('/candidates/:id/panel-decision', auth, authorize('super_admin', 'team_lead', 'hr'), candidateCtrl.panelDecision);
router.post('/candidates/bulk-decision', auth, authorize('super_admin', 'team_lead', 'hr'), candidateCtrl.bulkPanelDecision);
router.post('/candidates/:id/notes', auth, candidateCtrl.addNote);

// ── Interview Scoring ──
router.post('/candidates/:id/score-personal', auth, authorize('super_admin', 'hr', 'personal_interviewer'), candidateCtrl.scorePersonalInterview);
router.post('/candidates/:id/score-technical', auth, authorize('super_admin', 'technical_interviewer'), candidateCtrl.scoreTechnicalInterview);
router.post('/candidates/:id/score-interview', auth, authorize('super_admin', 'hr', 'personal_interviewer', 'technical_interviewer'), candidateCtrl.scoreInterview);

// ── Offer (HR + Admin only) ──
if (offerCtrl) router.get('/candidates/:id/offer-pdf', auth, authorize('super_admin', 'hr'), offerCtrl.generateOfferPDF);

// ── Import ──
router.post('/import/upload', auth, authorize('super_admin', 'team_lead', 'hr'), uploadImport.single('file'), importCtrl.uploadFile);
router.post('/import/process', auth, authorize('super_admin', 'team_lead', 'hr'), importCtrl.processImport);
router.get('/import/history', auth, authorize('super_admin', 'team_lead', 'hr'), importCtrl.getImports);

// ── Telecalling ──
router.post('/calls/log', auth, candidateCtrl.addNote ? callCtrl.logCall : callCtrl.logCall);
router.get('/calls/queue', auth, callCtrl.getCallQueue);
router.get('/calls/history', auth, callCtrl.getAgentCalls);
router.get('/calls/stats/:agentId?', auth, callCtrl.getTelecallerStats);

// ── Locations ──
router.get('/locations', auth, locationCtrl.getLocations);
router.post('/locations', auth, authorize('super_admin'), locationCtrl.createLocation);
router.put('/locations/:id', auth, authorize('super_admin'), locationCtrl.updateLocation);
router.get('/locations/quota-dashboard', auth, locationCtrl.getQuotaDashboard);

// ── Documents ──
if (documentCtrl) {
  router.get('/documents/types', auth, documentCtrl.getDocTypes);
  router.get('/documents/queue', auth, authorize('super_admin', 'team_lead', 'hr'), documentCtrl.getDocQueue);
  router.get('/documents/:id', auth, documentCtrl.getCandidateDocs);
  router.post('/documents/:id/upload', auth, uploadDocument.single('file'), documentCtrl.uploadDoc);
  router.post('/documents/:id/verify', auth, authorize('super_admin', 'team_lead', 'hr'), documentCtrl.verifyDoc);
  router.get('/documents/public/:token', documentCtrl.publicDocStatus);
  router.post('/documents/public/:token/upload', uploadDocument.single('file'), documentCtrl.publicUpload);
}

// ── Walk-In (Public) ──
router.get('/walkin/form-data', walkinCtrl.getFormData);
router.post('/walkin/register', walkinCtrl.register);
router.get('/status/:token', walkinCtrl.checkStatus);

module.exports = router;
ROUTESEOF
echo "  Routes updated with 8-role permissions"

# ═══════════════════════════════════════
# 3. Update dashboard controller — role-aware stats
# ═══════════════════════════════════════
echo "📝 [3/8] Updating dashboard controller for role-specific data..."
node -e "
const fs = require('fs');
const file = 'backend/src/controllers/dashboardController.js';
let c = fs.readFileSync(file, 'utf8');

// Add agent/telecaller filter to dashboard stats
if (!c.includes('agentFilter')) {
  c = c.replace(
    'exports.getDashboardStats = async (req, res) => {',
    'exports.getDashboardStats = async (req, res) => {\n    // Role-based filtering\n    const agentFilter = [\"agent\", \"telecaller\"].includes(req.user.role) ? { assignedAgent: req.user._id } : {};\n    const isPersonalInterviewer = req.user.role === \"personal_interviewer\";\n    const isTechInterviewer = req.user.role === \"technical_interviewer\";\n    const isTrainer = req.user.role === \"trainer\";'
  );

  // Add agentFilter to candidate count queries
  c = c.replace(
    'const total = await Candidate.countDocuments();',
    'const total = await Candidate.countDocuments(agentFilter);'
  );
  
  // Add agentFilter to pipeline stats
  c = c.replace(
    \"const pipeline = await Candidate.aggregate([\",
    \"const pipeline = await Candidate.aggregate([\n      { \\$match: agentFilter },\"
  );

  fs.writeFileSync(file, c);
  console.log('  Dashboard now filters by agent for agent/telecaller roles');
} else {
  console.log('  agentFilter already in dashboard');
}
"

# ═══════════════════════════════════════
# 4. Update candidates controller — agent sees only assigned
# ═══════════════════════════════════════
echo "📝 [4/8] Filtering candidates by assigned agent for agent/telecaller..."
node -e "
const fs = require('fs');
const file = 'backend/src/controllers/candidateController.js';
let c = fs.readFileSync(file, 'utf8');

// Add agent filter at the start of getCandidates
if (!c.includes('agent/telecaller filter')) {
  c = c.replace(
    'const query = {};',
    'const query = {};\n    // agent/telecaller filter — only see assigned candidates\n    if ([\"agent\", \"telecaller\"].includes(req.user.role)) {\n      query.assignedAgent = req.user._id;\n    }'
  );
  fs.writeFileSync(file, c);
  console.log('  getCandidates now filters by assigned agent for agent/telecaller');
} else {
  console.log('  Agent filter already exists');
}
"

# ═══════════════════════════════════════
# 5. Update telecalling — agent sees only their queue
# ═══════════════════════════════════════
echo "📝 [5/8] Fixing telecalling queue for agent filter..."
node -e "
const fs = require('fs');
const file = 'backend/src/controllers/callController.js';
let c = fs.readFileSync(file, 'utf8');

// Ensure getCallQueue filters by agent for telecaller/agent roles
if (!c.includes('telecaller/agent filter')) {
  c = c.replace(
    'exports.getCallQueue = async (req, res) => {',
    'exports.getCallQueue = async (req, res) => {\n  // telecaller/agent filter — only see assigned candidates'
  );
  
  // Add filter to the queue query
  c = c.replace(
    /const queue = await Candidate\.find\(\{/,
    'const agentMatch = [\"agent\", \"telecaller\"].includes(req.user.role) ? { assignedAgent: req.user._id } : {};\n    const queue = await Candidate.find({ ...agentMatch,'
  );
  
  fs.writeFileSync(file, c);
  console.log('  Call queue now filters by assigned agent');
} else {
  console.log('  Telecall agent filter already exists');
}
"

# ═══════════════════════════════════════
# 6. Update document types — DL mandatory, police non-mandatory
# ═══════════════════════════════════════
echo "📝 [6/8] Fixing document required flags..."
node -e "
const fs = require('fs');
const file = 'backend/src/controllers/documentController.js';
let c = fs.readFileSync(file, 'utf8');

// Swap DL and police clearance required flags
c = c.replace(
  \"{ key: 'driving_license', label: 'Driving License', required: false, phase: 'post_selection' },\",
  \"{ key: 'driving_license', label: 'Driving License', required: true, phase: 'post_selection' },\"
);
c = c.replace(
  \"{ key: 'police_clearance', label: 'Police Clearance Certificate', required: true, phase: 'post_selection' },\",
  \"{ key: 'police_clearance', label: 'Police Clearance Certificate', required: false, phase: 'post_selection' },\"
);

fs.writeFileSync(file, c);
console.log('  DL → mandatory, Police Clearance → optional');
"

# ═══════════════════════════════════════
# 7. Update constants — add new roles
# ═══════════════════════════════════════
echo "📝 [7/8] Updating constants..."
node -e "
const fs = require('fs');
const file = 'backend/src/config/constants.js';
let c = fs.readFileSync(file, 'utf8');

// Update ROLES
c = c.replace(
  /ROLES: \[.*?\]/s,
  \"ROLES: ['super_admin', 'team_lead', 'hr', 'agent', 'telecaller', 'personal_interviewer', 'technical_interviewer', 'trainer']\"
);

fs.writeFileSync(file, c);
console.log('  Constants updated with 8 roles');
"

# ═══════════════════════════════════════
# 8. Restart backend
# ═══════════════════════════════════════
echo "🔄 [8/8] Restarting backend..."
pm2 restart inovit-api

echo ""
echo "═══════════════════════════════════════════════════"
echo "  ✅ Batch A: Backend INSTALLED!"
echo "═══════════════════════════════════════════════════"
echo ""
echo "New roles (8 total):"
echo "  1. super_admin     — Full access"
echo "  2. team_lead       — Candidates, Import, Selection, Analytics"
echo "  3. hr (NEW)        — Personal Interview, Documents, Offers"
echo "  4. agent           — Only assigned candidates"
echo "  5. telecaller      — Only assigned candidates, call queue"
echo "  6. personal_interviewer (NEW) — Score personal interviews"
echo "  7. technical_interviewer (NEW) — Score technical interviews"
echo "  8. trainer (NEW)   — Training attendance + scores only"
echo ""
echo "Permission changes:"
echo "  • Score personal: super_admin, hr, personal_interviewer"
echo "  • Score technical: super_admin, technical_interviewer"
echo "  • Offer PDF: super_admin, hr ONLY"
echo "  • Documents verify: super_admin, team_lead, hr"
echo "  • Agent/telecaller: see only their assigned candidates"
echo "  • Dashboard: filtered by agent for agent/telecaller"
echo "  • DL: mandatory, Police Clearance: optional"
echo ""
echo "Create new users with these roles via User Management."
echo ""
pm2 status
