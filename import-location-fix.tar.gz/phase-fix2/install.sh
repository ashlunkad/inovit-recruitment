#!/bin/bash
echo "═══════════════════════════════════════════"
echo "  INOVIT — Import + Location Fields Fix"
echo "═══════════════════════════════════════════"

DIR="$(cd "$(dirname "$0")" && pwd)"
cd /opt/inovit-recruitment

echo "📝 [1/4] Updating import controller (all phone fixes + 3 locations + father name)..."
cp "$DIR/importController.js" backend/src/controllers/

echo "📝 [2/4] Adding homeLocation + fatherName + externalCode to Candidate model..."
# Add homeLocation after currentLocation block
node -e "
const fs = require('fs');
const file = 'backend/src/models/Candidate.js';
let c = fs.readFileSync(file, 'utf8');

// Add homeLocation if not present
if (!c.includes('homeLocation')) {
  c = c.replace(
    'currentLocation: {',
    'homeLocation: {\n    city: String,\n    state: String,\n    district: String,\n    pincode: String,\n  },\n  currentLocation: {'
  );
}

// Add fatherName if not present
if (!c.includes('fatherName')) {
  c = c.replace(
    'gender: { type: String',
    'fatherName: { type: String, trim: true },\n  gender: { type: String'
  );
}

// Add externalCode if not present
if (!c.includes('externalCode')) {
  c = c.replace(
    'sourceDetail: String',
    'sourceDetail: String,\n  externalCode: { type: String, index: true }, // Original ID from source database'
  );
}

// Fix referral code to use 6 digits
c = c.replace('Math.floor(1000 + Math.random() * 9000)', 'Math.floor(100000 + Math.random() * 900000)');

fs.writeFileSync(file, c);
console.log('Model updated');
"

echo "📝 [3/4] Adding sourceName to ImportBatch model..."
node -e "
const fs = require('fs');
const file = 'backend/src/models/ImportBatch.js';
let c = fs.readFileSync(file, 'utf8');
if (!c.includes('sourceName')) {
  c = c.replace('fileName:', 'sourceName: String,\n  fileName:');
  fs.writeFileSync(file, c);
  console.log('ImportBatch model updated');
} else { console.log('Already has sourceName'); }
"

echo "🔨 [4/4] Restarting backend..."
pm2 restart inovit-api

echo ""
echo "═══════════════════════════════════════════"
echo "  ✅ Import + Location Fix INSTALLED!"
echo "═══════════════════════════════════════════"
echo ""
echo "Import now supports:"
echo "  • Database/Source Name (required)"
echo "  • External ID / Unique Code mapping"
echo "  • Home City + Home State + Home District (permanent address)"
echo "  • Current City + Current State (working location)"
echo "  • Preferred Location (deployment preference — existing)"
echo "  • Father Name"
echo "  • Robust phone cleaning (decimals, scientific notation, leading zeros)"
echo "  • Gender normalization (male/m/Male → Male)"
echo "  • 6-digit referral codes (fewer collisions)"
echo ""
echo "3 Location Fields per Candidate:"
echo "  • Home Location — where they are from (Aligarh)"
echo "  • Current Location — where they work now (Noida)"
echo "  • Preferred Location — where they want to be deployed (Jaipur)"
echo ""
pm2 status
