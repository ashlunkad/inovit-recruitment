#!/bin/bash
echo "═══════════════════════════════════════════"
echo "  INOVIT — Interview, Salary, TZ, Source Fix"
echo "═══════════════════════════════════════════"

DIR="$(cd "$(dirname "$0")" && pwd)"
cd /opt/inovit-recruitment

# ── FIX 1: Update Candidate model — salary fields + interview scoring + source enum ──
echo "📝 [1/6] Updating Candidate model..."
node -e "
const fs = require('fs');
const file = 'backend/src/models/Candidate.js';
let c = fs.readFileSync(file, 'utf8');

// Add counterOfferSalary and finalSalary after offerSalary
if (!c.includes('counterOfferSalary')) {
  c = c.replace(
    'offerSalary: Number,',
    'offerSalary: Number,\n  counterOfferSalary: Number,\n  finalSalary: Number,'
  );
  console.log('Added salary fields');
}

// Update interview breakdown to use Poor/Average/Good/Excellent (stored as 1-4)
// Also add teamLeading parameter
if (!c.includes('teamLeading')) {
  c = c.replace(
    \"quizNormalized: { type: Number, default: 0, max: 10 }\",
    \"quizNormalized: { type: Number, default: 0, max: 10 },\n    teamLeading: { type: Number, default: 0, max: 4 }\"
  );
  console.log('Added teamLeading to interview breakdown');
}

// Update SOURCE enum to include custom sources
if (!c.includes('SOURCE:')) {
  // The source field references constants — we'll fix the constants file instead
}

fs.writeFileSync(file, c);
console.log('Candidate model updated');
"

# ── FIX 2: Update constants — add more source types ──
echo "📝 [2/6] Updating constants (source types)..."
node -e "
const fs = require('fs');
const file = 'backend/src/config/constants.js';
let c = fs.readFileSync(file, 'utf8');

// Replace SOURCE array with more options
c = c.replace(
  /SOURCE: \[.*?\]/s,
  \"SOURCE: ['Excel', 'CSV', 'GSheet', 'Manual', 'Walk_In', 'Referral', 'Job_Portal', 'Job_Fair', 'Social_Media', 'WhatsApp', 'Telecall', 'Website', 'Other']\"
);

fs.writeFileSync(file, c);
console.log('Constants updated');
"

# ── FIX 3: Update import controller — source fix ──
echo "📝 [3/6] Fixing import source handling..."
node -e "
const fs = require('fs');
const file = 'backend/src/controllers/importController.js';
let c = fs.readFileSync(file, 'utf8');

// Change source assignment to always use file type, put custom name in sourceDetail only
const oldSource = \"const sourceLabel = sourceName || (fileType === 'csv' ? 'CSV' : 'Excel');\";
const newSource = \"const sourceLabel = fileType === 'csv' ? 'CSV' : 'Excel';\";
c = c.replace(oldSource, newSource);

// Update sourceDetail to include the custom source name
c = c.replace(
  /source: sourceLabel,/,
  'source: sourceLabel,'
);

c = c.replace(
  /sourceDetail: .*?,/,
  \"sourceDetail: sourceName ? sourceName + ' (' + batch.fileName + ')' : batch.fileName,\"
);

fs.writeFileSync(file, c);
console.log('Import source fixed');
"

# ── FIX 4: Update interview scoring in candidateController ──
echo "📝 [4/6] Updating interview scoring endpoint..."
node -e "
const fs = require('fs');
const file = 'backend/src/controllers/candidateController.js';
let c = fs.readFileSync(file, 'utf8');

// Replace scoreInterview function
const oldFunc = c.match(/exports\.scoreInterview = async[\s\S]*?(?=\n\/\/ |\nexports\.)/);
if (oldFunc) {
  c = c.replace(oldFunc[0], \`exports.scoreInterview = async (req, res) => {
  try {
    const { technical, practical, communication, experience, locationAvailability, teamLeading, notes } = req.body;
    const candidate = await Candidate.findById(req.params.id);
    if (!candidate) return res.status(404).json({ error: 'Candidate not found' });

    const oldScore = candidate.interviewScore;
    candidate.interviewBreakdown = { technical, practical, communication, experience, locationAvailability, teamLeading };
    // Each parameter is 1-4 (Poor=1, Average=2, Good=3, Excellent=4), total max = 24
    candidate.interviewScore = (technical||0) + (practical||0) + (communication||0) + (experience||0) + (locationAvailability||0) + (teamLeading||0);
    candidate.interviewNotes = notes;
    candidate.status = 'Interview_Done';
    candidate.statusHistory.push({
      status: 'Interview_Done', changedBy: req.user._id, changedAt: new Date(),
      reason: 'Interview scored: ' + candidate.interviewScore + '/24'
    });

    await candidate.save();
    await TimelineService.scoreUpdate(candidate._id, 'Interview Score', oldScore, candidate.interviewScore, req.user._id, req.user.name);

    res.json({ candidate });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

\`);
  console.log('Interview scoring updated');
} else { console.log('Could not find scoreInterview function'); }

fs.writeFileSync(file, c);
"

# ── FIX 5: Update CandidateDetail.jsx — new scoring UI + salary fields + IST timezone ──
echo "📝 [5/6] Updating CandidateDetail page..."
cp "$DIR/CandidateDetail.jsx" frontend/src/pages/

# ── FIX 6: Build and restart ──
echo "🔨 [6/6] Building frontend + restarting..."
cd frontend && npm run build
pm2 restart all

echo ""
echo "═══════════════════════════════════════════"
echo "  ✅ All 4 Fixes INSTALLED!"
echo "═══════════════════════════════════════════"
echo ""
echo "1. Interview Scoring: Poor(1)/Average(2)/Good(3)/Excellent(4)"
echo "   Parameters: Technical, Practical, Communication,"
echo "   Experience, Location, Team Leading — Total: /24"
echo ""
echo "2. Salary: Offered → Counter Offer → Final Accepted"
echo ""
echo "3. Timezone: All dates now display in IST"
echo ""
echo "4. Source: Custom name saved in sourceDetail,"
echo "   source type auto-set to Excel/CSV"
echo ""
pm2 status
