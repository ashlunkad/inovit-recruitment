import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { candidateAPI, locationAPI, authAPI } from '../services/api';
import api from '../services/api';
import toast from 'react-hot-toast';
import { ArrowLeft, Phone, Mail, MapPin, Star, Clock, Send, FileText, Edit2, X, Save, UserCheck, Calendar, Briefcase, ChevronDown } from 'lucide-react';

const eventIcons = { whatsapp_out:'📤', whatsapp_in:'📩', call_outbound:'📞', call_inbound:'📲', sms_sent:'📱', internal_note:'📝', status_change:'🔄', document_event:'📄', score_update:'🎯', panel_decision:'✅', system_event:'⚙️' };
const eventColors = { whatsapp_out:'border-green-300 bg-green-50', whatsapp_in:'border-green-400 bg-green-50', call_outbound:'border-blue-300 bg-blue-50', call_inbound:'border-blue-400 bg-blue-50', status_change:'border-yellow-300 bg-yellow-50', panel_decision:'border-emerald-300 bg-emerald-50', internal_note:'border-purple-300 bg-purple-50', system_event:'border-gray-300 bg-gray-50', score_update:'border-orange-300 bg-orange-50', document_event:'border-indigo-300 bg-indigo-50' };

const ALL_STATUSES = ['New','Walk_In_Registered','Contacted','WhatsApp_Failed','Interested','Not_Interested','Screening','Screened','Portal_Applied','Interview_Scheduled','Interview_Done','Selected','Rejected','On_Hold','Waitlisted','Offered','Offer_Accepted','Offer_Declined','Onboarding','Training','Training_Completed','Training_Failed','Deployed','Unreachable','Blacklisted','Archived'];
const QUALIFICATIONS = [{v:'ITI_Electrical',l:'ITI - Electrical'},{v:'ITI_Other',l:'ITI - Other'},{v:'Diploma_Electrical',l:'Diploma - Electrical'},{v:'Diploma_Other',l:'Diploma - Other'},{v:'BTech_Electrical',l:'B.Tech - Electrical'},{v:'BTech_Other',l:'B.Tech - Other'},{v:'BSc',l:'B.Sc'},{v:'HSC',l:'12th / HSC'},{v:'10th',l:'10th'},{v:'Other',l:'Other'}];
const SCORE_LABELS = { 1: 'Poor', 2: 'Average', 3: 'Good', 4: 'Excellent' };
const SCORE_COLORS = { 1: 'bg-red-100 text-red-700 border-red-300', 2: 'bg-yellow-100 text-yellow-700 border-yellow-300', 3: 'bg-blue-100 text-blue-700 border-blue-300', 4: 'bg-green-100 text-green-700 border-green-300' };

// Format date in IST
const fmtIST = (d, opts = { dateStyle:'short', timeStyle:'short' }) => d ? new Date(d).toLocaleString('en-IN', { ...opts, timeZone: 'Asia/Kolkata' }) : '-';
const fmtDateIST = (d) => d ? new Date(d).toLocaleDateString('en-IN', { day:'numeric', month:'short', year:'numeric', timeZone:'Asia/Kolkata' }) : '-';
const fmtTimeIST = (d) => d ? new Date(d).toLocaleString('en-IN', { dateStyle:'medium', timeStyle:'short', timeZone:'Asia/Kolkata' }) : '-';

export default function CandidateDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [candidate, setCandidate] = useState(null);
  const [timeline, setTimeline] = useState([]);
  const [loading, setLoading] = useState(true);
  const [note, setNote] = useState('');
  const [timelineFilter, setTimelineFilter] = useState('all');
  const [editModal, setEditModal] = useState(false);
  const [statusModal, setStatusModal] = useState(false);
  const [assignModal, setAssignModal] = useState(false);
  const [interviewModal, setInterviewModal] = useState(false);
  const [offerModal, setOfferModal] = useState(false);
  const [scoreModal, setScoreModal] = useState(false);
  const [salaryModal, setSalaryModal] = useState(false);
  const [locations, setLocations] = useState([]);
  const [users, setUsers] = useState([]);
  const [editForm, setEditForm] = useState({});
  const [statusForm, setStatusForm] = useState({ status:'', reason:'' });
  const [assignForm, setAssignForm] = useState({ agent:'', team:'' });
  const [interviewForm, setInterviewForm] = useState({ date:'', type:'virtual', interviewer:'', link:'' });
  const [offerForm, setOfferForm] = useState({ salary:18000, location:'', joiningDate:'' });
  const [scoreForm, setScoreForm] = useState({ technical:0, practical:0, communication:0, experience:0, locationAvailability:0, teamLeading:0, notes:'' });
  const [salaryForm, setSalaryForm] = useState({ counterOffer:0, finalSalary:0 });

  const reload = () => {
    candidateAPI.getOne(id).then(res => { setCandidate(res.data.candidate); setTimeline(res.data.timeline || []); }).catch(() => toast.error('Candidate not found')).finally(() => setLoading(false));
  };
  useEffect(() => {
    reload();
    locationAPI.getAll().then(r => setLocations(r.data.locations || [])).catch(() => {});
    authAPI.getUsers().then(r => setUsers(r.data.users || [])).catch(() => {});
  }, [id]);

  const addNote = async () => { if (!note.trim()) return; try { await candidateAPI.addNote(id, { content: note }); toast.success('Note added'); setNote(''); reload(); } catch { toast.error('Failed'); } };

  // Edit
  const openEdit = () => { const c = candidate; setEditForm({ fullName:c.fullName||'', phone:c.phone||'', alternatePhone:c.alternatePhone||'', email:c.email||'', qualification:c.qualification||'', experienceYears:c.experienceYears||0, electricalTrade:c.electricalTrade||false, currentCity:c.currentLocation?.city||'', currentState:c.currentLocation?.state||'', preferredLocation:c.preferredLocation?._id||'', preferredCity:c.preferredCity||'', gender:c.gender||'', fatherName:c.fatherName||'', externalCode:c.externalCode||'' }); setEditModal(true); };
  const saveEdit = async () => { try { await candidateAPI.update(id, { fullName:editForm.fullName, phone:editForm.phone, alternatePhone:editForm.alternatePhone, email:editForm.email, qualification:editForm.qualification, experienceYears:Number(editForm.experienceYears), electricalTrade:editForm.electricalTrade, currentLocation:{city:editForm.currentCity,state:editForm.currentState}, preferredLocation:editForm.preferredLocation||undefined, preferredCity:editForm.preferredCity, gender:editForm.gender, fatherName:editForm.fatherName, externalCode:editForm.externalCode }); toast.success('Updated'); setEditModal(false); reload(); } catch(err) { toast.error(err.response?.data?.error||'Failed'); } };

  // Status
  const openStatus = () => { setStatusForm({ status:candidate.status, reason:'' }); setStatusModal(true); };
  const saveStatus = async () => { if (statusForm.status===candidate.status) { setStatusModal(false); return; } try { await candidateAPI.update(id, { status:statusForm.status, statusChangeReason:statusForm.reason }); toast.success('Status changed'); setStatusModal(false); reload(); } catch(err) { toast.error(err.response?.data?.error||'Failed'); } };

  // Assign
  const openAssign = () => { setAssignForm({ agent:candidate.assignedAgent?._id||'', team:candidate.assignedTeam||'' }); setAssignModal(true); };
  const saveAssign = async () => { try { await candidateAPI.update(id, { assignedAgent:assignForm.agent||undefined, assignedTeam:assignForm.team||undefined }); toast.success('Assigned'); setAssignModal(false); reload(); } catch { toast.error('Failed'); } };

  // Interview
  const openInterview = () => { setInterviewForm({ date:candidate.interviewScheduled?candidate.interviewScheduled.slice(0,16):'', type:candidate.interviewType||'virtual', interviewer:candidate.interviewer?._id||'', link:candidate.interviewLink||'' }); setInterviewModal(true); };
  const saveInterview = async () => { try { await candidateAPI.update(id, { interviewScheduled:interviewForm.date, interviewType:interviewForm.type, interviewer:interviewForm.interviewer||undefined, interviewLink:interviewForm.link, status:'Interview_Scheduled', statusChangeReason:'Interview scheduled' }); toast.success('Interview scheduled'); setInterviewModal(false); reload(); } catch { toast.error('Failed'); } };

  // Offer
  const openOffer = () => { setOfferForm({ salary:candidate.offerSalary||18000, location:candidate.offerLocation?._id||candidate.preferredLocation?._id||'', joiningDate:candidate.offerJoiningDate?candidate.offerJoiningDate.slice(0,10):'' }); setOfferModal(true); };
  const saveOffer = async () => { try { await candidateAPI.update(id, { offerSalary:Number(offerForm.salary), offerLocation:offerForm.location, offerJoiningDate:offerForm.joiningDate, offerSentAt:new Date().toISOString(), offerExpiresAt:new Date(Date.now()+72*60*60*1000).toISOString(), status:'Offered', statusChangeReason:'Offer sent' }); toast.success('Offer created'); setOfferModal(false); reload(); } catch { toast.error('Failed'); } };

  // Accept/Decline
  const acceptOffer = async () => { try { await candidateAPI.update(id, { status:'Offer_Accepted', offerAcceptedAt:new Date().toISOString(), statusChangeReason:'Offer accepted' }); toast.success('Accepted!'); reload(); } catch { toast.error('Failed'); } };
  const declineOffer = async () => { const r = prompt('Decline reason:'); if (!r) return; try { await candidateAPI.update(id, { status:'Offer_Declined', offerDeclinedAt:new Date().toISOString(), offerDeclineReason:r, statusChangeReason:'Declined: '+r }); toast.success('Declined'); reload(); } catch { toast.error('Failed'); } };

  // Salary negotiation
  const openSalary = () => { setSalaryForm({ counterOffer:candidate.counterOfferSalary||0, finalSalary:candidate.finalSalary||candidate.offerSalary||0 }); setSalaryModal(true); };
  const saveSalary = async () => { try { await candidateAPI.update(id, { counterOfferSalary:Number(salaryForm.counterOffer)||undefined, finalSalary:Number(salaryForm.finalSalary) }); toast.success('Salary updated'); setSalaryModal(false); reload(); } catch { toast.error('Failed'); } };

  // Score Interview — Poor/Average/Good/Excellent
  const openScore = () => { const b = candidate.interviewBreakdown||{}; setScoreForm({ technical:b.technical||0, practical:b.practical||0, communication:b.communication||0, experience:b.experience||0, locationAvailability:b.locationAvailability||0, teamLeading:b.teamLeading||0, notes:candidate.interviewNotes||'' }); setScoreModal(true); };
  const saveScore = async () => { try { await candidateAPI.scoreInterview(id, scoreForm); toast.success('Scored'); setScoreModal(false); reload(); } catch(err) { toast.error(err.response?.data?.error||'Failed'); } };

  // Blacklist
  const toggleBlacklist = async () => { const r = candidate.blacklisted?null:prompt('Blacklist reason:'); if (!candidate.blacklisted&&!r) return; try { await candidateAPI.update(id, { blacklisted:!candidate.blacklisted, blacklistReason:r||'', status:candidate.blacklisted?candidate.status:'Blacklisted', statusChangeReason:candidate.blacklisted?'Removed from blacklist':'Blacklisted: '+r }); toast.success(candidate.blacklisted?'Unblacklisted':'Blacklisted'); reload(); } catch { toast.error('Failed'); } };

  const filteredTimeline = timelineFilter==='all'?timeline:timeline.filter(e => { if (timelineFilter==='whatsapp') return e.eventType?.includes('whatsapp'); if (timelineFilter==='calls') return e.eventType?.includes('call'); if (timelineFilter==='notes') return e.eventType==='internal_note'; if (timelineFilter==='system') return ['status_change','system_event','panel_decision','score_update'].includes(e.eventType); return true; });

  if (loading) return <div className="flex items-center justify-center h-64"><div className="animate-spin rounded-full h-10 w-10 border-b-2 border-primary-600"></div></div>;
  if (!candidate) return <div className="text-center py-10 text-gray-500">Candidate not found</div>;
  const c = candidate;
  const scoreColor = (s,max=24) => { const pct=s/max*100; return pct>=75?'text-green-600 bg-green-50':pct>=50?'text-blue-600 bg-blue-50':pct>=25?'text-yellow-600 bg-yellow-50':'text-red-500 bg-red-50'; };
  const statusColor = (s) => { if (['Deployed','Training_Completed'].includes(s)) return 'bg-green-100 text-green-700'; if (['Selected','Offered','Offer_Accepted'].includes(s)) return 'bg-blue-100 text-blue-700'; if (['Rejected','Blacklisted','Archived'].includes(s)) return 'bg-red-100 text-red-700'; if (['On_Hold','Waitlisted'].includes(s)) return 'bg-amber-100 text-amber-700'; return 'bg-gray-100 text-gray-700'; };
  const agents = users.filter(u=>['agent','team_lead','telecaller'].includes(u.role));
  const interviewers = users.filter(u=>['interviewer','super_admin','team_lead'].includes(u.role));

  return (
    <div className="space-y-6">
      <button onClick={() => navigate(-1)} className="flex items-center gap-1 text-sm text-gray-500 hover:text-gray-700"><ArrowLeft size={16} /> Back</button>

      {/* Header */}
      <div className="card flex flex-col md:flex-row md:items-center gap-4">
        <div className="w-14 h-14 rounded-full bg-primary-100 flex items-center justify-center text-primary-700 font-bold text-xl">{c.fullName?.split(' ').map(n=>n[0]).join('').slice(0,2)}</div>
        <div className="flex-1">
          <div className="flex items-center gap-2 flex-wrap">
            <h1 className="text-xl font-bold text-gray-900">{c.fullName}</h1>
            <span className={'text-xs px-2 py-0.5 rounded-full font-medium '+statusColor(c.status)}>{c.status?.replace(/_/g,' ')}</span>
            {c.blacklisted && <span className="text-xs px-2 py-0.5 rounded-full font-medium bg-red-600 text-white">BLACKLISTED</span>}
          </div>
          <div className="flex flex-wrap gap-3 mt-1 text-sm text-gray-500">
            <span className="flex items-center gap-1"><Phone size={13} /> {c.phone}</span>
            {c.email && <span className="flex items-center gap-1"><Mail size={13} /> {c.email}</span>}
            <span className="flex items-center gap-1"><MapPin size={13} /> {c.currentLocation?.city||c.preferredCity||'N/A'}</span>
            <span className="flex items-center gap-1"><FileText size={13} /> {c.candidateId}</span>
            {c.externalCode && <span className="text-xs bg-gray-100 px-2 py-0.5 rounded">Ext: {c.externalCode}</span>}
          </div>
        </div>
        <div className="flex gap-2">
          <div className={'text-center px-3 py-2 rounded-lg '+scoreColor(c.interviewScore||0,24)}>
            <div className="text-xl font-bold">{c.interviewScore||0}/24</div>
            <div className="text-xs">Interview</div>
          </div>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="flex flex-wrap gap-2">
        <button onClick={openEdit} className="btn-outline text-sm flex items-center gap-1"><Edit2 size={14} /> Edit</button>
        <button onClick={openStatus} className="btn-outline text-sm flex items-center gap-1"><ChevronDown size={14} /> Status</button>
        <button onClick={openAssign} className="btn-outline text-sm flex items-center gap-1"><UserCheck size={14} /> Assign</button>
        <button onClick={openInterview} className="btn-outline text-sm flex items-center gap-1"><Calendar size={14} /> Interview</button>
        {['Interview_Done','Interview_Scheduled'].includes(c.status) && <button onClick={openScore} className="btn-outline text-sm flex items-center gap-1"><Star size={14} /> Score</button>}
        {c.panelDecision==='Selected'&&!['Offered','Offer_Accepted'].includes(c.status) && <button onClick={openOffer} className="btn-primary text-sm flex items-center gap-1"><Briefcase size={14} /> Create Offer</button>}
        {c.status==='Offered' && <><button onClick={acceptOffer} className="bg-green-600 hover:bg-green-700 text-white text-sm px-3 py-1.5 rounded-lg">Accept</button><button onClick={declineOffer} className="bg-red-500 hover:bg-red-600 text-white text-sm px-3 py-1.5 rounded-lg">Decline</button></>}
        {c.offerSalary && <button onClick={openSalary} className="btn-outline text-sm flex items-center gap-1">₹ Salary</button>}
        <button onClick={toggleBlacklist} className={'text-sm px-3 py-1.5 rounded-lg '+(c.blacklisted?'bg-gray-200 text-gray-700 hover:bg-gray-300':'bg-red-50 text-red-600 hover:bg-red-100')}>{c.blacklisted?'Remove Blacklist':'Blacklist'}</button>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        <div className="lg:col-span-1 space-y-4">
          {/* Details */}
          <div className="card">
            <h3 className="font-semibold text-gray-800 mb-3">Details</h3>
            <dl className="space-y-2 text-sm">
              {[['Status',c.status?.replace(/_/g,' ')],['Qualification',c.qualification?.replace(/_/g,' ')],['Experience',(c.experienceYears||0)+' years'],['Source',c.source+(c.sourceDetail?' — '+c.sourceDetail:'')],['Current City',c.currentLocation?.city||'-'],['Preferred City',c.preferredCity||c.preferredLocation?.name||'-'],['Language',c.preferredLanguage==='hi'?'Hindi':'English'],['Panel',c.panelDecision],['Assigned To',c.assignedAgent?.name||'Unassigned'],['Team',c.assignedTeam||'-'],['Father',c.fatherName||'-'],['External ID',c.externalCode||'-']].map(([l,v])=>(
                <div key={l} className="flex justify-between"><dt className="text-gray-500">{l}</dt><dd className="font-medium text-gray-800 text-right max-w-[60%] truncate">{v||'-'}</dd></div>
              ))}
            </dl>
          </div>

          {/* Offer Info */}
          {c.offerSalary && (
            <div className="card border-blue-200 bg-blue-50">
              <h3 className="font-semibold text-blue-800 mb-2">Offer & Salary</h3>
              <dl className="space-y-1.5 text-sm">
                <div className="flex justify-between"><dt className="text-blue-600">Offered Salary</dt><dd className="font-bold text-blue-900">₹{c.offerSalary?.toLocaleString('en-IN')}/month</dd></div>
                {c.counterOfferSalary>0 && <div className="flex justify-between"><dt className="text-orange-600">Counter Offer</dt><dd className="font-bold text-orange-700">₹{c.counterOfferSalary?.toLocaleString('en-IN')}/month</dd></div>}
                {c.finalSalary>0 && <div className="flex justify-between"><dt className="text-green-600">Final Accepted</dt><dd className="font-bold text-green-700">₹{c.finalSalary?.toLocaleString('en-IN')}/month</dd></div>}
                <div className="flex justify-between"><dt className="text-blue-600">Location</dt><dd>{c.offerLocation?.name||c.preferredLocation?.name||'-'}</dd></div>
                {c.offerJoiningDate && <div className="flex justify-between"><dt className="text-blue-600">Joining</dt><dd>{fmtDateIST(c.offerJoiningDate)}</dd></div>}
                {c.offerSentAt && <div className="flex justify-between"><dt className="text-blue-600">Sent</dt><dd>{fmtDateIST(c.offerSentAt)}</dd></div>}
                {c.offerAcceptedAt && <div className="flex justify-between"><dt className="text-green-600">Accepted</dt><dd className="text-green-700 font-bold">{fmtDateIST(c.offerAcceptedAt)}</dd></div>}
                {c.offerDeclinedAt && <div className="flex justify-between"><dt className="text-red-600">Declined</dt><dd className="text-red-700">{c.offerDeclineReason}</dd></div>}
              </dl>
            </div>
          )}

          {/* Interview Info */}
          {c.interviewScheduled && (
            <div className="card border-purple-200 bg-purple-50">
              <h3 className="font-semibold text-purple-800 mb-2">Interview</h3>
              <dl className="space-y-1.5 text-sm">
                <div className="flex justify-between"><dt className="text-purple-600">Date & Time</dt><dd className="font-bold">{fmtTimeIST(c.interviewScheduled)}</dd></div>
                <div className="flex justify-between"><dt className="text-purple-600">Type</dt><dd>{c.interviewType||'-'}</dd></div>
                <div className="flex justify-between"><dt className="text-purple-600">Interviewer</dt><dd>{c.interviewer?.name||'-'}</dd></div>
                {c.interviewLink && <div className="flex justify-between"><dt className="text-purple-600">Link</dt><dd><a href={c.interviewLink} target="_blank" className="text-blue-600 underline text-xs">Join</a></dd></div>}
              </dl>
            </div>
          )}

          {/* Interview Breakdown */}
          {c.interviewScore > 0 && (
            <div className="card">
              <h3 className="font-semibold text-gray-800 mb-3">Interview Scores ({c.interviewScore}/24)</h3>
              <div className="space-y-2">
                {[['Technical',c.interviewBreakdown?.technical],['Practical',c.interviewBreakdown?.practical],['Communication',c.interviewBreakdown?.communication],['Experience',c.interviewBreakdown?.experience],['Location',c.interviewBreakdown?.locationAvailability],['Team Leading',c.interviewBreakdown?.teamLeading]].map(([label,val])=>(
                  <div key={label} className="flex items-center justify-between text-sm">
                    <span className="text-gray-600 w-28">{label}</span>
                    <span className={'text-xs px-2 py-0.5 rounded-full font-medium border '+(SCORE_COLORS[val]||'bg-gray-100 text-gray-500 border-gray-200')}>{SCORE_LABELS[val]||'Not scored'}</span>
                  </div>
                ))}
              </div>
              {c.interviewNotes && <div className="mt-3 pt-3 border-t text-sm text-gray-600"><span className="font-medium">Notes:</span> {c.interviewNotes}</div>}
            </div>
          )}
        </div>

        {/* Timeline */}
        <div className="lg:col-span-2">
          <div className="card">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold text-gray-800">Unified Timeline</h3>
              <div className="flex gap-1">{['all','whatsapp','calls','notes','system'].map(f=>(<button key={f} onClick={()=>setTimelineFilter(f)} className={'text-xs px-2 py-1 rounded-full transition '+(timelineFilter===f?'bg-primary-100 text-primary-700 font-medium':'text-gray-500 hover:bg-gray-100')}>{f==='all'?'All':f.charAt(0).toUpperCase()+f.slice(1)}</button>))}</div>
            </div>
            <div className="flex gap-2 mb-4"><input value={note} onChange={e=>setNote(e.target.value)} placeholder="Add a note..." className="input-field flex-1" onKeyDown={e=>e.key==='Enter'&&addNote()} /><button onClick={addNote} className="btn-primary flex items-center gap-1"><Send size={14} /> Add</button></div>
            <div className="space-y-3 max-h-[600px] overflow-y-auto">
              {filteredTimeline.length===0?(<div className="text-center text-gray-400 py-8">No events</div>):filteredTimeline.map((event,i)=>(
                <div key={event._id||i} className={'border-l-4 rounded-r-lg p-3 '+(eventColors[event.eventType]||'border-gray-300 bg-gray-50')}>
                  <div className="flex items-start justify-between">
                    <div className="flex items-start gap-2"><span className="text-base">{eventIcons[event.eventType]||'📌'}</span><div>
                      <div className="text-sm text-gray-800">{event.content||event.eventType?.replace(/_/g,' ')}</div>
                      {event.oldStatus && <div className="text-xs text-gray-500 mt-0.5">{event.oldStatus} → {event.newStatus}</div>}
                    </div></div>
                    <div className="text-xs text-gray-400 whitespace-nowrap ml-2">{fmtIST(event.createdAt)}</div>
                  </div>
                  <div className="text-xs text-gray-400 mt-1 ml-7">by {event.createdByName||event.createdBy?.name||'System'}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* ═══ MODALS ═══ */}

      {editModal && (<Modal title="Edit Details" onClose={()=>setEditModal(false)} onSave={saveEdit}><div className="grid grid-cols-2 gap-3">
        <F label="Full Name *" value={editForm.fullName} set={v=>setEditForm(f=>({...f,fullName:v}))} />
        <F label="Phone *" value={editForm.phone} set={v=>setEditForm(f=>({...f,phone:v}))} />
        <F label="Alt Phone" value={editForm.alternatePhone} set={v=>setEditForm(f=>({...f,alternatePhone:v}))} />
        <F label="Email" value={editForm.email} set={v=>setEditForm(f=>({...f,email:v}))} type="email" />
        <F label="External ID" value={editForm.externalCode} set={v=>setEditForm(f=>({...f,externalCode:v}))} />
        <F label="Father Name" value={editForm.fatherName} set={v=>setEditForm(f=>({...f,fatherName:v}))} />
        <div><label className="block text-sm font-medium text-gray-700 mb-1">Qualification</label><select value={editForm.qualification} onChange={e=>setEditForm(f=>({...f,qualification:e.target.value}))} className="input-field"><option value="">Select</option>{QUALIFICATIONS.map(q=><option key={q.v} value={q.v}>{q.l}</option>)}</select></div>
        <F label="Experience (Yrs)" value={editForm.experienceYears} set={v=>setEditForm(f=>({...f,experienceYears:v}))} type="number" />
        <F label="Current City" value={editForm.currentCity} set={v=>setEditForm(f=>({...f,currentCity:v}))} />
        <F label="Current State" value={editForm.currentState} set={v=>setEditForm(f=>({...f,currentState:v}))} />
        <F label="Preferred City" value={editForm.preferredCity} set={v=>setEditForm(f=>({...f,preferredCity:v}))} />
        <div><label className="block text-sm font-medium text-gray-700 mb-1">Preferred Location</label><select value={editForm.preferredLocation} onChange={e=>setEditForm(f=>({...f,preferredLocation:e.target.value}))} className="input-field"><option value="">Select</option>{locations.map(l=><option key={l._id} value={l._id}>{l.name} ({l.city})</option>)}</select></div>
        <div><label className="block text-sm font-medium text-gray-700 mb-1">Gender</label><select value={editForm.gender} onChange={e=>setEditForm(f=>({...f,gender:e.target.value}))} className="input-field"><option value="">-</option><option value="Male">Male</option><option value="Female">Female</option><option value="Other">Other</option></select></div>
      </div></Modal>)}

      {statusModal && (<Modal title="Change Status" onClose={()=>setStatusModal(false)} onSave={saveStatus}><div className="space-y-3">
        <div><label className="block text-sm font-medium text-gray-700 mb-1">Current: <b>{c.status?.replace(/_/g,' ')}</b></label><select value={statusForm.status} onChange={e=>setStatusForm(f=>({...f,status:e.target.value}))} className="input-field">{ALL_STATUSES.map(s=><option key={s} value={s}>{s.replace(/_/g,' ')}</option>)}</select></div>
        <F label="Reason" value={statusForm.reason} set={v=>setStatusForm(f=>({...f,reason:v}))} />
      </div></Modal>)}

      {assignModal && (<Modal title="Assign Agent" onClose={()=>setAssignModal(false)} onSave={saveAssign}><div className="space-y-3">
        <div><label className="block text-sm font-medium text-gray-700 mb-1">Agent</label><select value={assignForm.agent} onChange={e=>setAssignForm(f=>({...f,agent:e.target.value}))} className="input-field"><option value="">Unassigned</option>{agents.map(a=><option key={a._id} value={a._id}>{a.name} ({a.role})</option>)}</select></div>
        <div><label className="block text-sm font-medium text-gray-700 mb-1">Team</label><select value={assignForm.team} onChange={e=>setAssignForm(f=>({...f,team:e.target.value}))} className="input-field"><option value="">-</option>{['Alpha','Beta','Gamma','Delta'].map(t=><option key={t} value={t}>{t}</option>)}</select></div>
      </div></Modal>)}

      {interviewModal && (<Modal title="Schedule Interview" onClose={()=>setInterviewModal(false)} onSave={saveInterview}><div className="space-y-3">
        <F label="Date & Time *" value={interviewForm.date} set={v=>setInterviewForm(f=>({...f,date:v}))} type="datetime-local" />
        <div><label className="block text-sm font-medium text-gray-700 mb-1">Type</label><select value={interviewForm.type} onChange={e=>setInterviewForm(f=>({...f,type:e.target.value}))} className="input-field"><option value="virtual">Virtual</option><option value="physical">Physical</option></select></div>
        <div><label className="block text-sm font-medium text-gray-700 mb-1">Interviewer</label><select value={interviewForm.interviewer} onChange={e=>setInterviewForm(f=>({...f,interviewer:e.target.value}))} className="input-field"><option value="">Select</option>{interviewers.map(u=><option key={u._id} value={u._id}>{u.name}</option>)}</select></div>
        <F label="Meeting Link" value={interviewForm.link} set={v=>setInterviewForm(f=>({...f,link:v}))} placeholder="https://meet.google.com/..." />
      </div></Modal>)}

      {offerModal && (<Modal title="Create Offer" onClose={()=>setOfferModal(false)} onSave={saveOffer}><div className="space-y-3">
        <F label="Offered Salary (₹/month) *" value={offerForm.salary} set={v=>setOfferForm(f=>({...f,salary:v}))} type="number" />
        <div><label className="block text-sm font-medium text-gray-700 mb-1">Deployment Location</label><select value={offerForm.location} onChange={e=>setOfferForm(f=>({...f,location:e.target.value}))} className="input-field"><option value="">Select</option>{locations.map(l=><option key={l._id} value={l._id}>{l.name} ({l.city})</option>)}</select></div>
        <F label="Joining Date" value={offerForm.joiningDate} set={v=>setOfferForm(f=>({...f,joiningDate:v}))} type="date" />
      </div></Modal>)}

      {salaryModal && (<Modal title="Salary Negotiation" onClose={()=>setSalaryModal(false)} onSave={saveSalary}><div className="space-y-3">
        <div className="bg-blue-50 rounded-lg p-3 text-sm"><span className="text-blue-600">Original Offer:</span> <b className="text-blue-900">₹{c.offerSalary?.toLocaleString('en-IN')}/month</b></div>
        <F label="Counter Offer by Candidate (₹/month)" value={salaryForm.counterOffer} set={v=>setSalaryForm(f=>({...f,counterOffer:v}))} type="number" />
        <F label="Final Accepted Salary (₹/month) *" value={salaryForm.finalSalary} set={v=>setSalaryForm(f=>({...f,finalSalary:v}))} type="number" />
      </div></Modal>)}

      {/* Score Modal — Poor/Average/Good/Excellent */}
      {scoreModal && (<Modal title="Score Interview" onClose={()=>setScoreModal(false)} onSave={saveScore} wide>
        <div className="space-y-4">
          {[['technical','Technical Knowledge'],['practical','Practical Skills'],['communication','Communication & Attitude'],['experience','Relevant Experience'],['locationAvailability','Location Willingness'],['teamLeading','Team Leading']].map(([key,label])=>(
            <div key={key}>
              <label className="block text-sm font-medium text-gray-700 mb-2">{label}</label>
              <div className="flex gap-2">
                {[{v:1,l:'Poor'},{v:2,l:'Average'},{v:3,l:'Good'},{v:4,l:'Excellent'}].map(opt=>(
                  <button key={opt.v} type="button" onClick={()=>setScoreForm(f=>({...f,[key]:opt.v}))}
                    className={'flex-1 py-2 px-3 rounded-lg border-2 text-sm font-medium transition '+(scoreForm[key]===opt.v ? SCORE_COLORS[opt.v]+' border-current' : 'bg-gray-50 text-gray-400 border-gray-200 hover:bg-gray-100')}>
                    {opt.l}
                  </button>
                ))}
              </div>
            </div>
          ))}
          <div className="pt-3 border-t text-center"><span className="text-lg font-bold text-primary-700">Total: {Object.entries(scoreForm).filter(([k])=>k!=='notes').reduce((s,[,v])=>s+Number(v),0)}/24</span></div>
          <div><label className="block text-sm font-medium text-gray-700 mb-1">Notes</label><textarea value={scoreForm.notes} onChange={e=>setScoreForm(f=>({...f,notes:e.target.value}))} className="input-field" rows={3} placeholder="Key observations..." /></div>
        </div>
      </Modal>)}
    </div>
  );
}

function Modal({title,children,onClose,onSave,wide}) { return (<div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4"><div className={'bg-white rounded-xl shadow-xl w-full max-h-[90vh] overflow-y-auto '+(wide?'max-w-lg':'max-w-md')}><div className="flex items-center justify-between p-5 border-b"><h3 className="text-lg font-bold text-gray-900">{title}</h3><button onClick={onClose} className="text-gray-400 hover:text-gray-600"><X size={20}/></button></div><div className="p-5">{children}</div><div className="flex gap-3 justify-end p-5 border-t"><button onClick={onClose} className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 text-sm">Cancel</button><button onClick={onSave} className="btn-primary py-2 text-sm"><Save size={14} className="inline mr-1"/>Save</button></div></div></div>); }
function F({label,value,set,type='text',placeholder}) { return (<div><label className="block text-sm font-medium text-gray-700 mb-1">{label}</label><input type={type} value={value} onChange={e=>set(e.target.value)} placeholder={placeholder} className="input-field"/></div>); }
