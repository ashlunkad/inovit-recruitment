#!/bin/bash
echo "═══════════════════════════════════════════"
echo "  INOVIT Phase 2 — HIGH Priority Installer"
echo "═══════════════════════════════════════════"

DIR="$(cd "$(dirname "$0")" && pwd)"
cd /opt/inovit-recruitment

echo "📝 [1/6] Updating Candidates page (Add, Export, Bulk Assign)..."
cp "$DIR/Candidates.jsx" frontend/src/pages/

echo "📝 [2/6] Updating User Management (Reset Password)..."
cp "$DIR/UserManagement.jsx" frontend/src/pages/

echo "📝 [3/6] Updating backend auth (password reset/change)..."
cp "$DIR/authController.js" backend/src/controllers/

echo "📝 [4/6] Updating backend routes..."
cp "$DIR/routes-index.js" backend/src/routes/index.js

echo "📝 [5/6] Building frontend..."
cd frontend && npm run build

echo "🔄 [6/6] Restarting services..."
pm2 restart all

echo ""
echo "═══════════════════════════════════════════"
echo "  ✅ Phase 2 HIGH Priority Fixes INSTALLED!"
echo "═══════════════════════════════════════════"
echo ""
echo "New features:"
echo "  • Candidates → 'Add Candidate' button (manual entry)"
echo "  • Candidates → 'Export' button (downloads CSV)"
echo "  • Candidates → Checkbox + 'Bulk Assign Agent'"
echo "  • Candidates → Agent column shows assigned/unassigned"
echo "  • User Management → Reset Password button (key icon)"
echo "  • Backend → /auth/change-password endpoint"
echo "  • Backend → /users/:id/reset-password endpoint"
echo ""
pm2 status
