import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { candidateAPI, locationAPI, authAPI } from '../services/api';
import api from '../services/api';
import toast from 'react-hot-toast';
import { Search, Filter, ChevronLeft, ChevronRight, UserPlus, Download, Users, X, Save } from 'lucide-react';

const statusColors = {
  New: 'bg-blue-100 text-blue-700', Walk_In_Registered: 'bg-teal-100 text-teal-700',
  Interested: 'bg-green-100 text-green-700', Screening: 'bg-yellow-100 text-yellow-700',
  Portal_Applied: 'bg-purple-100 text-purple-700', Interview_Scheduled: 'bg-indigo-100 text-indigo-700',
  Interview_Done: 'bg-indigo-200 text-indigo-800', Selected: 'bg-emerald-100 text-emerald-700',
  Rejected: 'bg-red-100 text-red-700', On_Hold: 'bg-amber-100 text-amber-700',
  Offered: 'bg-orange-100 text-orange-700', Offer_Accepted: 'bg-green-200 text-green-800',
  Deployed: 'bg-green-300 text-green-900', Training: 'bg-cyan-100 text-cyan-700',
  Onboarding: 'bg-lime-100 text-lime-700', Offer_Declined: 'bg-red-50 text-red-500',
  Waitlisted: 'bg-amber-50 text-amber-600', Blacklisted: 'bg-red-200 text-red-800',
  WhatsApp_Failed: 'bg-red-50 text-red-600', Unreachable: 'bg-gray-200 text-gray-600',
};
const scoreColor = (s) => s >= 80 ? 'text-green-600' : s >= 60 ? 'text-blue-600' : s >= 40 ? 'text-yellow-600' : 'text-red-500';
const QUALIFICATIONS = [
  {v:'ITI_Electrical',l:'ITI - Electrical'},{v:'ITI_Other',l:'ITI - Other'},{v:'Diploma_Electrical',l:'Diploma - Electrical'},
  {v:'Diploma_Other',l:'Diploma - Other'},{v:'BTech_Electrical',l:'B.Tech - Electrical'},{v:'BTech_Other',l:'B.Tech - Other'},
  {v:'BSc',l:'B.Sc'},{v:'HSC',l:'12th / HSC'},{v:'10th',l:'10th'},{v:'Other',l:'Other'}
];

export default function Candidates() {
  const [candidates, setCandidates] = useState([]);
  const [pagination, setPagination] = useState({ total: 0, page: 1, pages: 1 });
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [filters, setFilters] = useState({ status: '', source: '', qualification: '' });
  const [showFilters, setShowFilters] = useState(false);
  const [selected, setSelected] = useState(new Set());
  const [addModal, setAddModal] = useState(false);
  const [assignModal, setAssignModal] = useState(false);
  const [locations, setLocations] = useState([]);
  const [agents, setAgents] = useState([]);
  const [addForm, setAddForm] = useState({ fullName: '', phone: '', email: '', qualification: '', experienceYears: 0, currentCity: '', currentState: '', preferredLocation: '', source: 'Manual' });
  const [assignForm, setAssignForm] = useState({ agent: '', team: '' });
  const navigate = useNavigate();

  const fetchCandidates = async (page = 1) => {
    setLoading(true);
    try {
      const params = { page, limit: 25, sort: '-createdAt', search };
      if (filters.status) params.status = filters.status;
      if (filters.source) params.source = filters.source;
      if (filters.qualification) params.qualification = filters.qualification;
      const res = await candidateAPI.getAll(params);
      setCandidates(res.data.candidates);
      setPagination(res.data.pagination);
    } catch (err) { console.error(err); }
    finally { setLoading(false); }
  };

  useEffect(() => { fetchCandidates(); }, [filters]);
  useEffect(() => {
    locationAPI.getAll().then(r => setLocations(r.data.locations || [])).catch(() => {});
    authAPI.getUsers().then(r => setAgents((r.data.users || []).filter(u => ['agent','team_lead','telecaller'].includes(u.role)))).catch(() => {});
  }, []);

  const handleSearch = (e) => { e.preventDefault(); fetchCandidates(1); };

  const toggleSelect = (id) => {
    const s = new Set(selected);
    s.has(id) ? s.delete(id) : s.add(id);
    setSelected(s);
  };
  const toggleAll = () => {
    if (selected.size === candidates.length) setSelected(new Set());
    else setSelected(new Set(candidates.map(c => c._id)));
  };

  // Add candidate
  const submitAdd = async () => {
    if (!addForm.fullName || !addForm.phone) { toast.error('Name and phone are required'); return; }
    try {
      await candidateAPI.create({
        ...addForm, experienceYears: Number(addForm.experienceYears),
        currentLocation: { city: addForm.currentCity, state: addForm.currentState },
        preferredLocation: addForm.preferredLocation || undefined,
      });
      toast.success('Candidate added');
      setAddModal(false);
      setAddForm({ fullName: '', phone: '', email: '', qualification: '', experienceYears: 0, currentCity: '', currentState: '', preferredLocation: '', source: 'Manual' });
      fetchCandidates();
    } catch (err) { toast.error(err.response?.data?.error || 'Failed to add'); }
  };

  // Bulk assign
  const submitBulkAssign = async () => {
    if (selected.size === 0) return;
    let success = 0, failed = 0;
    for (const id of selected) {
      try {
        await candidateAPI.update(id, {
          assignedAgent: assignForm.agent || undefined,
          assignedTeam: assignForm.team || undefined
        });
        success++;
      } catch { failed++; }
    }
    toast.success(success + ' candidates assigned' + (failed ? ', ' + failed + ' failed' : ''));
    setAssignModal(false); setSelected(new Set());
    fetchCandidates(pagination.page);
  };

  // Export to CSV
  const exportCSV = async () => {
    try {
      toast.loading('Exporting...');
      const params = { limit: 5000, sort: '-createdAt' };
      if (filters.status) params.status = filters.status;
      if (filters.source) params.source = filters.source;
      if (filters.qualification) params.qualification = filters.qualification;
      if (search) params.search = search;
      const res = await candidateAPI.getAll(params);
      const data = res.data.candidates;

      const headers = ['ID','Name','Phone','Email','Qualification','Experience','City','State','Preferred Location','Source','Status','Panel Decision','Combined Score','Pre-Screen','Interview Score','Assigned Agent','Team','Created'];
      const rows = data.map(c => [
        c.candidateId, c.fullName, c.phone, c.email||'', c.qualification||'', c.experienceYears||0,
        c.currentLocation?.city||'', c.currentLocation?.state||'', c.preferredLocation?.name||'',
        c.source||'', c.status||'', c.panelDecision||'', c.combinedScore||0, c.preScreenScore||0,
        c.interviewScore||0, c.assignedAgent?.name||'', c.assignedTeam||'',
        new Date(c.createdAt).toLocaleDateString('en-IN')
      ]);

      const csv = [headers.join(','), ...rows.map(r => r.map(v => '"' + String(v).replace(/"/g, '""') + '"').join(','))].join('\n');
      const blob = new Blob([csv], { type: 'text/csv' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url; a.download = 'candidates-export-' + new Date().toISOString().slice(0,10) + '.csv';
      a.click(); URL.revokeObjectURL(url);
      toast.dismiss(); toast.success('Exported ' + data.length + ' candidates');
    } catch { toast.dismiss(); toast.error('Export failed'); }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-gray-900">Candidates</h1>
        <div className="flex items-center gap-2">
          <span className="text-sm text-gray-500">{pagination.total} total</span>
          <button onClick={exportCSV} className="btn-outline text-sm flex items-center gap-1"><Download size={14} /> Export</button>
          <button onClick={() => setAddModal(true)} className="btn-primary text-sm flex items-center gap-1"><UserPlus size={14} /> Add Candidate</button>
        </div>
      </div>

      {/* Search + Filters */}
      <div className="card !p-4">
        <div className="flex gap-3">
          <form onSubmit={handleSearch} className="flex-1 flex gap-2">
            <div className="relative flex-1">
              <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
              <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search by name, phone, or ID..." className="input-field pl-9" />
            </div>
            <button type="submit" className="btn-primary">Search</button>
          </form>
          <button onClick={() => setShowFilters(!showFilters)} className={'btn-outline flex items-center gap-1 ' + (showFilters ? 'bg-primary-50 border-primary-300' : '')}>
            <Filter size={14} /> Filters
          </button>
        </div>
        {showFilters && (
          <div className="flex flex-wrap gap-3 mt-3 pt-3 border-t">
            <select value={filters.status} onChange={e => setFilters(f => ({...f, status: e.target.value}))} className="input-field w-auto text-sm">
              <option value="">All Status</option>
              {Object.keys(statusColors).map(s => <option key={s} value={s}>{s.replace(/_/g, ' ')}</option>)}
            </select>
            <select value={filters.source} onChange={e => setFilters(f => ({...f, source: e.target.value}))} className="input-field w-auto text-sm">
              <option value="">All Sources</option>
              {['Excel','CSV','Walk_In','Manual','Referral','GSheet'].map(s => <option key={s} value={s}>{s.replace(/_/g,' ')}</option>)}
            </select>
            <select value={filters.qualification} onChange={e => setFilters(f => ({...f, qualification: e.target.value}))} className="input-field w-auto text-sm">
              <option value="">All Qualifications</option>
              {QUALIFICATIONS.map(q => <option key={q.v} value={q.v}>{q.l}</option>)}
            </select>
            <button onClick={() => setFilters({ status: '', source: '', qualification: '' })} className="text-sm text-gray-500 hover:text-gray-700">Clear</button>
          </div>
        )}
      </div>

      {/* Bulk actions */}
      {selected.size > 0 && (
        <div className="card !p-3 flex items-center gap-3 bg-primary-50 border-primary-200">
          <span className="text-sm font-medium text-primary-700">{selected.size} selected</span>
          <button onClick={() => setAssignModal(true)} className="btn-primary text-xs py-1.5 flex items-center gap-1"><Users size={13} /> Bulk Assign Agent</button>
          <button onClick={() => setSelected(new Set())} className="text-xs text-gray-500 hover:text-gray-700 ml-2">Clear</button>
        </div>
      )}

      {/* Table */}
      <div className="bg-white rounded-xl shadow-sm border overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-gray-50 border-b">
            <tr>
              <th className="px-3 py-3 w-10"><input type="checkbox" checked={selected.size === candidates.length && candidates.length > 0} onChange={toggleAll} className="rounded" /></th>
              <th className="px-4 py-3 text-left font-medium text-gray-500">Candidate</th>
              <th className="px-4 py-3 text-left font-medium text-gray-500">Phone</th>
              <th className="px-4 py-3 text-left font-medium text-gray-500">Qualification</th>
              <th className="px-4 py-3 text-left font-medium text-gray-500">Location</th>
              <th className="px-4 py-3 text-left font-medium text-gray-500">Source</th>
              <th className="px-4 py-3 text-center font-medium text-gray-500">Score</th>
              <th className="px-4 py-3 text-left font-medium text-gray-500">Agent</th>
              <th className="px-4 py-3 text-left font-medium text-gray-500">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {loading ? (
              <tr><td colSpan={9} className="py-12 text-center text-gray-400">Loading...</td></tr>
            ) : candidates.length === 0 ? (
              <tr><td colSpan={9} className="py-12 text-center text-gray-400">No candidates found</td></tr>
            ) : candidates.map(c => (
              <tr key={c._id} className={'hover:bg-gray-50 cursor-pointer transition ' + (selected.has(c._id) ? 'bg-primary-50' : '')}>
                <td className="px-3 py-3" onClick={e => e.stopPropagation()}>
                  <input type="checkbox" checked={selected.has(c._id)} onChange={() => toggleSelect(c._id)} className="rounded" />
                </td>
                <td className="px-4 py-3" onClick={() => navigate('/candidates/' + c._id)}>
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-primary-100 flex items-center justify-center text-primary-700 font-medium text-xs">
                      {c.fullName?.split(' ').map(n => n[0]).join('').slice(0,2)}
                    </div>
                    <div>
                      <div className="font-medium text-gray-900">{c.fullName}</div>
                      <div className="text-xs text-gray-400">{c.candidateId} • {c.experienceYears}yr</div>
                    </div>
                  </div>
                </td>
                <td className="px-4 py-3 text-gray-600 font-mono text-xs" onClick={() => navigate('/candidates/' + c._id)}>{c.phone}</td>
                <td className="px-4 py-3 text-gray-600 text-xs" onClick={() => navigate('/candidates/' + c._id)}>{c.qualification?.replace(/_/g,' ')}</td>
                <td className="px-4 py-3 text-gray-600 text-xs" onClick={() => navigate('/candidates/' + c._id)}>{c.currentLocation?.city || c.preferredLocation?.name || '-'}</td>
                <td className="px-4 py-3" onClick={() => navigate('/candidates/' + c._id)}><span className="badge bg-gray-100 text-gray-600 text-xs">{c.source?.replace(/_/g,' ')}</span></td>
                <td className="px-4 py-3 text-center" onClick={() => navigate('/candidates/' + c._id)}><span className={'font-bold ' + scoreColor(c.combinedScore)}>{c.combinedScore || '-'}</span></td>
                <td className="px-4 py-3 text-xs text-gray-500" onClick={() => navigate('/candidates/' + c._id)}>{c.assignedAgent?.name || <span className="text-red-400">Unassigned</span>}</td>
                <td className="px-4 py-3" onClick={() => navigate('/candidates/' + c._id)}><span className={'badge text-xs ' + (statusColors[c.status] || 'bg-gray-100 text-gray-600')}>{c.status?.replace(/_/g,' ')}</span></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Pagination */}
      {pagination.pages > 1 && (
        <div className="flex items-center justify-between">
          <span className="text-sm text-gray-500">Page {pagination.page} of {pagination.pages}</span>
          <div className="flex gap-2">
            <button onClick={() => fetchCandidates(pagination.page - 1)} disabled={pagination.page <= 1} className="btn-outline disabled:opacity-30"><ChevronLeft size={16} /></button>
            <button onClick={() => fetchCandidates(pagination.page + 1)} disabled={pagination.page >= pagination.pages} className="btn-outline disabled:opacity-30"><ChevronRight size={16} /></button>
          </div>
        </div>
      )}

      {/* Add Candidate Modal */}
      {addModal && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between p-5 border-b">
              <h3 className="text-lg font-bold text-gray-900">Add New Candidate</h3>
              <button onClick={() => setAddModal(false)} className="text-gray-400 hover:text-gray-600"><X size={20} /></button>
            </div>
            <div className="p-5 space-y-3">
              <div><label className="block text-sm font-medium text-gray-700 mb-1">Full Name *</label>
                <input value={addForm.fullName} onChange={e => setAddForm(f=>({...f, fullName: e.target.value}))} className="input-field" placeholder="e.g., Rahul Kumar" /></div>
              <div><label className="block text-sm font-medium text-gray-700 mb-1">Phone *</label>
                <input value={addForm.phone} onChange={e => setAddForm(f=>({...f, phone: e.target.value}))} className="input-field font-mono" placeholder="10-digit number" maxLength={10} type="tel" /></div>
              <div><label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
                <input value={addForm.email} onChange={e => setAddForm(f=>({...f, email: e.target.value}))} className="input-field" type="email" /></div>
              <div><label className="block text-sm font-medium text-gray-700 mb-1">Qualification</label>
                <select value={addForm.qualification} onChange={e => setAddForm(f=>({...f, qualification: e.target.value}))} className="input-field">
                  <option value="">Select</option>{QUALIFICATIONS.map(q => <option key={q.v} value={q.v}>{q.l}</option>)}
                </select></div>
              <div><label className="block text-sm font-medium text-gray-700 mb-1">Experience (Years)</label>
                <input type="number" value={addForm.experienceYears} onChange={e => setAddForm(f=>({...f, experienceYears: e.target.value}))} className="input-field" min={0} max={30} /></div>
              <div className="grid grid-cols-2 gap-3">
                <div><label className="block text-sm font-medium text-gray-700 mb-1">City</label>
                  <input value={addForm.currentCity} onChange={e => setAddForm(f=>({...f, currentCity: e.target.value}))} className="input-field" /></div>
                <div><label className="block text-sm font-medium text-gray-700 mb-1">State</label>
                  <input value={addForm.currentState} onChange={e => setAddForm(f=>({...f, currentState: e.target.value}))} className="input-field" /></div>
              </div>
              <div><label className="block text-sm font-medium text-gray-700 mb-1">Preferred Location</label>
                <select value={addForm.preferredLocation} onChange={e => setAddForm(f=>({...f, preferredLocation: e.target.value}))} className="input-field">
                  <option value="">Select</option>{locations.map(l => <option key={l._id} value={l._id}>{l.name} ({l.city})</option>)}
                </select></div>
              <div><label className="block text-sm font-medium text-gray-700 mb-1">Source</label>
                <select value={addForm.source} onChange={e => setAddForm(f=>({...f, source: e.target.value}))} className="input-field">
                  {['Manual','Walk_In','Referral','Excel','CSV'].map(s => <option key={s} value={s}>{s.replace(/_/g,' ')}</option>)}
                </select></div>
            </div>
            <div className="flex gap-3 justify-end p-5 border-t">
              <button onClick={() => setAddModal(false)} className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 text-sm">Cancel</button>
              <button onClick={submitAdd} className="btn-primary py-2 text-sm"><Save size={14} className="inline mr-1" />Add Candidate</button>
            </div>
          </div>
        </div>
      )}

      {/* Bulk Assign Modal */}
      {assignModal && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-sm w-full">
            <div className="flex items-center justify-between p-5 border-b">
              <h3 className="text-lg font-bold text-gray-900">Assign {selected.size} Candidates</h3>
              <button onClick={() => setAssignModal(false)} className="text-gray-400 hover:text-gray-600"><X size={20} /></button>
            </div>
            <div className="p-5 space-y-3">
              <div><label className="block text-sm font-medium text-gray-700 mb-1">Agent</label>
                <select value={assignForm.agent} onChange={e => setAssignForm(f=>({...f, agent: e.target.value}))} className="input-field">
                  <option value="">Select agent</option>
                  {agents.map(a => <option key={a._id} value={a._id}>{a.name} ({a.role})</option>)}
                </select></div>
              <div><label className="block text-sm font-medium text-gray-700 mb-1">Team</label>
                <select value={assignForm.team} onChange={e => setAssignForm(f=>({...f, team: e.target.value}))} className="input-field">
                  <option value="">Select team</option>
                  {['Alpha','Beta','Gamma','Delta'].map(t => <option key={t} value={t}>{t}</option>)}
                </select></div>
            </div>
            <div className="flex gap-3 justify-end p-5 border-t">
              <button onClick={() => setAssignModal(false)} className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 text-sm">Cancel</button>
              <button onClick={submitBulkAssign} className="btn-primary py-2 text-sm">Assign All</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
