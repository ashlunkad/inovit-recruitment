import { useState, useEffect } from 'react';
import { dashboardAPI, candidateAPI, callAPI } from '../services/api';
import { useAuth } from '../context/AuthContext';
import { useNavigate } from 'react-router-dom';
import { Users, Briefcase, Phone, MapPin, TrendingUp, Star, FileCheck, Clock } from 'lucide-react';

const O = '#E67E22'; // INOVIT Orange
const G = '#4A4A4A'; // INOVIT Dark Gray
const LIFECYCLE_GROUPS = [
  { label:'New', statuses:['New','Walk_In_Registered'], color:'bg-blue-100 text-blue-700', border:'border-blue-300' },
  { label:'Outreach', statuses:['Contacted','Interested','Not_Interested','WhatsApp_Failed','Unreachable'], color:'bg-sky-100 text-sky-700', border:'border-sky-300' },
  { label:'Screening', statuses:['Screening','Screened','Portal_Applied'], color:'bg-yellow-100 text-yellow-700', border:'border-yellow-300' },
  { label:'Interview', statuses:['Interview_Scheduled','Interview_Pending_Technical','Interview_Done'], color:'bg-purple-100 text-purple-700', border:'border-purple-300' },
  { label:'Selection', statuses:['Selected','Rejected','On_Hold','Waitlisted'], color:'bg-emerald-100 text-emerald-700', border:'border-emerald-300' },
  { label:'Offer', statuses:['Offered','Offer_Accepted','Offer_Declined'], color:'bg-orange-100 text-orange-700', border:'border-orange-300' },
  { label:'Onboarding', statuses:['Onboarding'], color:'bg-lime-100 text-lime-700', border:'border-lime-300' },
  { label:'Training & Deploy', statuses:['Training','Training_Completed','Training_Failed','Deployed'], color:'bg-green-100 text-green-700', border:'border-green-300' },
];
const fmtIST = (d) => d ? new Date(d).toLocaleString('en-IN',{dateStyle:'short',timeStyle:'short',timeZone:'Asia/Kolkata'}) : '-';

export default function Dashboard() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    dashboardAPI.getStats().then(r => setStats(r.data)).catch(console.error).finally(() => setLoading(false));
  }, []);

  if (loading) return <div className="flex items-center justify-center h-64"><div className="animate-spin rounded-full h-10 w-10 border-b-2" style={{borderColor:O}}></div></div>;
  if (!stats) return <div className="text-center py-10 text-gray-500">Failed to load dashboard</div>;

  const role = user?.role;
  const pipeline = stats.pipeline || [];
  const getCount = (s) => pipeline.find(p => p._id === s)?.count || 0;
  const total = stats.total || 0;
  const deployed = getCount('Deployed');
  const target = 500;

  // Group pipeline by lifecycle
  const lifecycleData = LIFECYCLE_GROUPS.map(g => ({
    ...g,
    count: g.statuses.reduce((sum, s) => sum + getCount(s), 0),
    breakdown: g.statuses.map(s => ({ status: s, count: getCount(s) })).filter(x => x.count > 0),
  }));

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold" style={{color:G}}>
            {role === 'telecaller' ? 'My Telecalling Dashboard' :
             role === 'agent' ? 'My Dashboard' :
             role === 'personal_interviewer' ? 'Personal Interview Dashboard' :
             role === 'technical_interviewer' ? 'Technical Interview Dashboard' :
             role === 'trainer' ? 'Training Dashboard' :
             role === 'hr' ? 'HR Dashboard' :
             role === 'team_lead' ? 'Team Lead Dashboard' :
             'Admin Dashboard'}
          </h1>
          <p className="text-sm text-gray-500">Welcome, {user?.name}</p>
        </div>
        <div className="text-right">
          <div className="text-3xl font-bold" style={{color:O}}>{deployed}<span className="text-lg text-gray-400">/{target}</span></div>
          <div className="text-xs text-gray-500">Deployed</div>
          <div className="w-32 bg-gray-200 rounded-full h-2 mt-1"><div className="h-2 rounded-full" style={{width:`${Math.min(deployed/target*100,100)}%`,backgroundColor:O}}></div></div>
        </div>
      </div>

      {/* Stat Cards — role aware */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard icon={Users} label="Total Candidates" value={total} color="#3B82F6" />
        <StatCard icon={Briefcase} label="Deployed" value={deployed} color="#22C55E" />
        <StatCard icon={TrendingUp} label="Selected" value={getCount('Selected')+getCount('Offered')+getCount('Offer_Accepted')} color={O} />
        <StatCard icon={Star} label="Interviewed" value={getCount('Interview_Done')+getCount('Interview_Pending_Technical')} color="#8B5CF6" />
      </div>

      {/* TELECALLER DASHBOARD */}
      {(role === 'telecaller' || role === 'agent') && (
        <div className="grid md:grid-cols-2 gap-4">
          <div className="card">
            <h3 className="font-semibold mb-3" style={{color:G}}>My Performance</h3>
            <div className="grid grid-cols-3 gap-3 text-center">
              <div className="bg-blue-50 rounded-lg p-3"><div className="text-2xl font-bold text-blue-700">{total}</div><div className="text-xs text-blue-600">Assigned</div></div>
              <div className="bg-green-50 rounded-lg p-3"><div className="text-2xl font-bold text-green-700">{getCount('Contacted')+getCount('Interested')}</div><div className="text-xs text-green-600">Contacted</div></div>
              <div className="bg-amber-50 rounded-lg p-3"><div className="text-2xl font-bold text-amber-700">{getCount('New')+getCount('Walk_In_Registered')}</div><div className="text-xs text-amber-600">Pending</div></div>
            </div>
          </div>
          {stats.callOutcomes?.length > 0 && (
            <div className="card">
              <h3 className="font-semibold mb-3" style={{color:G}}>Call Outcomes Today</h3>
              <div className="space-y-2">
                {stats.callOutcomes.map(o => (
                  <div key={o._id} className="flex items-center justify-between text-sm">
                    <span className="text-gray-600">{(o._id||'Unknown').replace(/_/g,' ')}</span>
                    <span className="font-bold" style={{color:O}}>{o.count}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* INTERVIEWER DASHBOARD */}
      {(role === 'personal_interviewer' || role === 'technical_interviewer') && (
        <div className="card">
          <h3 className="font-semibold mb-3" style={{color:G}}>Today's Interviews</h3>
          <div className="grid grid-cols-3 gap-4 text-center">
            <div className="bg-purple-50 rounded-lg p-4"><div className="text-2xl font-bold text-purple-700">{getCount('Interview_Scheduled')+(role==='technical_interviewer'?getCount('Interview_Pending_Technical'):0)}</div><div className="text-xs text-purple-600">Assigned</div></div>
            <div className="bg-green-50 rounded-lg p-4"><div className="text-2xl font-bold text-green-700">{getCount('Interview_Done')}</div><div className="text-xs text-green-600">Interviewed</div></div>
            <div className="bg-amber-50 rounded-lg p-4"><div className="text-2xl font-bold text-amber-700">{getCount('Interview_Scheduled')}</div><div className="text-xs text-amber-600">Pending</div></div>
          </div>
          <button onClick={() => navigate('/interviews')} className="mt-4 w-full text-center text-sm font-medium py-2 rounded-lg" style={{backgroundColor:'#FEF3E2',color:O}}>
            Open Interview Panel →
          </button>
        </div>
      )}

      {/* TRAINER DASHBOARD */}
      {role === 'trainer' && (
        <div className="card">
          <h3 className="font-semibold mb-3" style={{color:G}}>Training Status</h3>
          <div className="grid grid-cols-4 gap-4 text-center">
            <div className="bg-blue-50 rounded-lg p-4"><div className="text-2xl font-bold text-blue-700">{getCount('Offer_Accepted')}</div><div className="text-xs text-blue-600">Ready</div></div>
            <div className="bg-purple-50 rounded-lg p-4"><div className="text-2xl font-bold text-purple-700">{getCount('Training')}</div><div className="text-xs text-purple-600">In Training</div></div>
            <div className="bg-green-50 rounded-lg p-4"><div className="text-2xl font-bold text-green-700">{getCount('Training_Completed')}</div><div className="text-xs text-green-600">Completed</div></div>
            <div className="bg-red-50 rounded-lg p-4"><div className="text-2xl font-bold text-red-700">{getCount('Training_Failed')}</div><div className="text-xs text-red-600">Failed</div></div>
          </div>
          <button onClick={() => navigate('/training')} className="mt-4 w-full text-center text-sm font-medium py-2 rounded-lg" style={{backgroundColor:'#FEF3E2',color:O}}>
            Open Training Panel →
          </button>
        </div>
      )}

      {/* HR DASHBOARD */}
      {role === 'hr' && (
        <div className="grid md:grid-cols-3 gap-4">
          <div className="card">
            <h3 className="font-semibold mb-2" style={{color:G}}>Personal Interviews</h3>
            <div className="grid grid-cols-3 gap-2 text-center">
              <div className="bg-purple-50 rounded p-2"><div className="text-lg font-bold text-purple-700">{getCount('Interview_Scheduled')}</div><div className="text-[10px] text-purple-600">Assigned</div></div>
              <div className="bg-green-50 rounded p-2"><div className="text-lg font-bold text-green-700">{getCount('Interview_Done')+getCount('Interview_Pending_Technical')}</div><div className="text-[10px] text-green-600">Done</div></div>
              <div className="bg-amber-50 rounded p-2"><div className="text-lg font-bold text-amber-700">{getCount('Interview_Scheduled')}</div><div className="text-[10px] text-amber-600">Pending</div></div>
            </div>
          </div>
          <div className="card">
            <h3 className="font-semibold mb-2" style={{color:G}}>Documents</h3>
            <div className="grid grid-cols-2 gap-2 text-center">
              <div className="bg-green-50 rounded p-2"><div className="text-lg font-bold text-green-700">{getCount('Onboarding')}</div><div className="text-[10px] text-green-600">In Progress</div></div>
              <div className="bg-amber-50 rounded p-2"><div className="text-lg font-bold text-amber-700">-</div><div className="text-[10px] text-amber-600">Pending Review</div></div>
            </div>
          </div>
          <div className="card">
            <h3 className="font-semibold mb-2" style={{color:G}}>Offer Letters</h3>
            <div className="grid grid-cols-3 gap-2 text-center">
              <div className="bg-orange-50 rounded p-2"><div className="text-lg font-bold text-orange-700">{getCount('Offered')}</div><div className="text-[10px] text-orange-600">Sent</div></div>
              <div className="bg-green-50 rounded p-2"><div className="text-lg font-bold text-green-700">{getCount('Offer_Accepted')}</div><div className="text-[10px] text-green-600">Accepted</div></div>
              <div className="bg-red-50 rounded p-2"><div className="text-lg font-bold text-red-700">{getCount('Offer_Declined')}</div><div className="text-[10px] text-red-600">Declined</div></div>
            </div>
          </div>
        </div>
      )}

      {/* PIPELINE — Lifecycle Grouped (Admin, Team Lead, HR) */}
      {['super_admin','team_lead','hr'].includes(role) && (
        <div className="card">
          <h3 className="font-semibold mb-4" style={{color:G}}>Pipeline Overview — Lifecycle Stages</h3>
          <div className="space-y-3">
            {lifecycleData.map(g => (
              <div key={g.label} className={'border rounded-lg p-3 '+g.border}>
                <div className="flex items-center justify-between mb-2">
                  <span className={'text-sm font-medium px-2 py-0.5 rounded-full '+g.color}>{g.label}</span>
                  <span className="text-lg font-bold" style={{color:G}}>{g.count}</span>
                </div>
                {g.breakdown.length > 0 && (
                  <div className="flex flex-wrap gap-2">
                    {g.breakdown.map(b => (
                      <span key={b.status} className="text-xs bg-white border rounded px-2 py-1 text-gray-600 cursor-pointer hover:bg-gray-50"
                        onClick={() => navigate('/candidates?status='+b.status)}>
                        {b.status.replace(/_/g,' ')}: <b>{b.count}</b>
                      </span>
                    ))}
                  </div>
                )}
                <div className="w-full bg-gray-100 rounded-full h-1.5 mt-2"><div className="h-1.5 rounded-full" style={{width:`${Math.min(g.count/Math.max(total,1)*100,100)}%`,backgroundColor:O}}></div></div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TEAM LEAD — Agent Performance */}
      {role === 'team_lead' && stats.agentPerformance && (
        <div className="card">
          <h3 className="font-semibold mb-3" style={{color:G}}>Agent Performance</h3>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-gray-50"><tr>
                <th className="px-3 py-2 text-left font-medium text-gray-500">Agent</th>
                <th className="px-3 py-2 text-center font-medium text-gray-500">Assigned</th>
                <th className="px-3 py-2 text-center font-medium text-gray-500">Contacted</th>
                <th className="px-3 py-2 text-center font-medium text-gray-500">Interviewed</th>
                <th className="px-3 py-2 text-center font-medium text-gray-500">Selected</th>
              </tr></thead>
              <tbody className="divide-y">
                {(stats.agentPerformance||[]).map(a => (
                  <tr key={a._id} className="hover:bg-gray-50">
                    <td className="px-3 py-2 font-medium">{a.name}</td>
                    <td className="px-3 py-2 text-center">{a.total}</td>
                    <td className="px-3 py-2 text-center">{a.contacted}</td>
                    <td className="px-3 py-2 text-center">{a.interviewed}</td>
                    <td className="px-3 py-2 text-center font-bold" style={{color:O}}>{a.selected}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* CALL OUTCOMES — Admin/Team Lead */}
      {['super_admin','team_lead'].includes(role) && stats.callOutcomes?.length > 0 && (
        <div className="card">
          <h3 className="font-semibold mb-3" style={{color:G}}>Call Outcomes Today</h3>
          <div className="flex flex-wrap gap-3">
            {stats.callOutcomes.map(o => (
              <div key={o._id} className="bg-gray-50 rounded-lg px-4 py-3 text-center border">
                <div className="text-xl font-bold" style={{color:O}}>{o.count}</div>
                <div className="text-xs text-gray-500">{(o._id||'Unknown').replace(/_/g,' ')}</div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* SOURCE DISTRIBUTION — Admin/Team Lead/HR */}
      {['super_admin','team_lead','hr'].includes(role) && stats.sources?.length > 0 && (
        <div className="card">
          <h3 className="font-semibold mb-3" style={{color:G}}>Source Distribution</h3>
          <div className="space-y-2">
            {stats.sources.sort((a,b) => b.count - a.count).map(s => (
              <div key={s._id} className="flex items-center gap-3">
                <span className="text-sm text-gray-600 w-24">{(s._id||'Unknown').replace(/_/g,' ')}</span>
                <div className="flex-1 bg-gray-100 rounded-full h-4"><div className="h-4 rounded-full text-[10px] text-white font-medium flex items-center px-2" style={{width:`${Math.max(s.count/Math.max(total,1)*100,3)}%`,backgroundColor:O}}>{s.count}</div></div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* LOCATION QUOTA — Admin/Team Lead/HR */}
      {['super_admin','team_lead','hr'].includes(role) && stats.locationQuota?.length > 0 && (
        <div className="card">
          <h3 className="font-semibold mb-3" style={{color:G}}>Location Quota</h3>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-gray-50"><tr>
                <th className="px-3 py-2 text-left font-medium text-gray-500">Location</th>
                <th className="px-3 py-2 text-center font-medium text-gray-500">Quota</th>
                <th className="px-3 py-2 text-center font-medium text-gray-500">Deployed</th>
                <th className="px-3 py-2 text-center font-medium text-gray-500">Remaining</th>
                <th className="px-3 py-2 font-medium text-gray-500">Progress</th>
              </tr></thead>
              <tbody className="divide-y">
                {stats.locationQuota.map(l => (
                  <tr key={l._id} className="hover:bg-gray-50">
                    <td className="px-3 py-2 font-medium">{l.name}</td>
                    <td className="px-3 py-2 text-center">{l.quota}</td>
                    <td className="px-3 py-2 text-center font-bold" style={{color:O}}>{l.deployed}</td>
                    <td className="px-3 py-2 text-center">{l.quota - l.deployed}</td>
                    <td className="px-3 py-2"><div className="w-full bg-gray-200 rounded-full h-2"><div className="h-2 rounded-full" style={{width:`${Math.min(l.deployed/Math.max(l.quota,1)*100,100)}%`,backgroundColor:O}}></div></div></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* RECENT ACTIVITY — all roles */}
      {stats.recentActivity?.length > 0 && (
        <div className="card">
          <h3 className="font-semibold mb-3" style={{color:G}}>Recent Activity</h3>
          <div className="space-y-2">
            {stats.recentActivity.slice(0,8).map((ev,i) => (
              <div key={ev._id||i} className="flex items-start gap-3 text-sm border-l-2 pl-3 py-1" style={{borderColor:O}}>
                <div className="flex-1">
                  <span className="text-gray-800">{ev.content||ev.eventType?.replace(/_/g,' ')}</span>
                  {ev.candidate && <span className="text-gray-400 ml-2">— {ev.candidate.fullName}</span>}
                </div>
                <span className="text-xs text-gray-400 shrink-0">{fmtIST(ev.createdAt)}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function StatCard({ icon: Icon, label, value, color }) {
  return (
    <div className="bg-white rounded-xl border p-4 flex items-center gap-3">
      <div className="w-10 h-10 rounded-lg flex items-center justify-center" style={{backgroundColor:color+'15'}}><Icon size={20} style={{color}} /></div>
      <div><div className="text-2xl font-bold" style={{color:'#4A4A4A'}}>{value}</div><div className="text-xs text-gray-500">{label}</div></div>
    </div>
  );
}
