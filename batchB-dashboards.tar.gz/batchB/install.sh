#!/bin/bash
echo "═══════════════════════════════════════════"
echo "  INOVIT — Batch B: Role Dashboards + Brand"
echo "═══════════════════════════════════════════"

DIR="$(cd "$(dirname "$0")" && pwd)"
cd /opt/inovit-recruitment

echo "📝 [1/3] Replacing Dashboard with role-specific views..."
cp "$DIR/Dashboard.jsx" frontend/src/pages/

echo "📝 [2/3] Adding agent performance to backend dashboard..."
cat > /tmp/fix_dash_backend.js << 'EOF'
const fs = require('fs');
const file = 'backend/src/controllers/dashboardController.js';
let c = fs.readFileSync(file, 'utf8');

// Add agentPerformance and locationQuota to dashboard response if not present
if (!c.includes('agentPerformance')) {
  c = c.replace(
    'const recentActivity',
    `// Agent performance (for team lead)
    const agentPerformance = await Candidate.aggregate([
      { $match: { assignedAgent: { $ne: null } } },
      { $lookup: { from: 'users', localField: 'assignedAgent', foreignField: '_id', as: 'agent' } },
      { $unwind: '$agent' },
      { $group: {
        _id: '$assignedAgent',
        name: { $first: '$agent.name' },
        total: { $sum: 1 },
        contacted: { $sum: { $cond: [{ $in: ['$status', ['Contacted','Interested','Interview_Scheduled','Interview_Done','Selected','Offered','Offer_Accepted','Deployed']] }, 1, 0] } },
        interviewed: { $sum: { $cond: [{ $in: ['$status', ['Interview_Done','Interview_Pending_Technical','Selected','Offered','Offer_Accepted','Deployed']] }, 1, 0] } },
        selected: { $sum: { $cond: [{ $in: ['$status', ['Selected','Offered','Offer_Accepted','Deployed']] }, 1, 0] } },
      }},
      { $sort: { total: -1 } },
      { $limit: 20 }
    ]);

    // Location quota
    const locationQuota = await DeploymentLocation.find({ active: { $ne: false } }).select('name city quota deployed').sort('name').lean();

    const recentActivity`
  );

  // Add to response
  c = c.replace(
    'recentActivity,',
    'recentActivity,\n      agentPerformance,\n      locationQuota,'
  );

  fs.writeFileSync(file, c);
  console.log('  Added agentPerformance + locationQuota to dashboard');
} else {
  console.log('  Already has agentPerformance');
}
EOF
node /tmp/fix_dash_backend.js

echo "🔨 [3/3] Building + restarting..."
cd frontend && npm run build
pm2 restart all

echo ""
echo "✅ Batch B: Role Dashboards INSTALLED!"
echo ""
echo "Each role now sees a different dashboard:"
echo "  Admin/Team Lead: Full stats + lifecycle pipeline + agent performance + locations"
echo "  HR: Interview stats + document stats + offer letter stats"  
echo "  Agent/Telecaller: Only their assigned data + call outcomes"
echo "  Personal/Tech Interviewer: Today's interviews assigned/done/pending"
echo "  Trainer: Training ready/in progress/completed/failed"
echo ""
echo "Brand colors: Orange (#E67E22) + Dark Gray (#4A4A4A)"
echo "Pipeline grouped by 8 lifecycle stages"
pm2 status
