#!/bin/bash
echo "🎨 Updating logos..."
cd /opt/inovit-recruitment

# Reverse (white) logo for dark backgrounds
cp "$(dirname "$0")/logo.png" frontend/public/logo.png
cp "$(dirname "$0")/logo-small.png" frontend/public/logo-small.png
cp "$(dirname "$0")/logo-medium.png" frontend/public/logo-medium.png
cp "$(dirname "$0")/logo-reverse.png" frontend/public/logo-reverse.png

# Dark logo for PDF (white logo on white PDF won't work)
mkdir -p backend/uploads
cp "$(dirname "$0")/logo-pdf.png" backend/uploads/logo.png

echo "🔨 Building..."
cd frontend && npm run build
pm2 restart all

echo ""
echo "✅ Logos updated!"
echo "  • Sidebar, Login, Walk-In, Doc Upload → White/reverse logo"
echo "  • Offer letter PDF → Original dark logo"
pm2 status
