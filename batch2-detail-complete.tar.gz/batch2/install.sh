#!/bin/bash
echo "═══════════════════════════════════════════════════"
echo "  INOVIT — Batch 2: Candidate Detail Completion"
echo "═══════════════════════════════════════════════════"

DIR="$(cd "$(dirname "$0")" && pwd)"
cd /opt/inovit-recruitment

echo "📝 [1/2] Replacing CandidateDetail.jsx (all features)..."
cp "$DIR/CandidateDetail.jsx" frontend/src/pages/

echo "🔨 [2/2] Building + restarting..."
cd frontend && npm run build
pm2 restart all

echo ""
echo "═══════════════════════════════════════════════════"
echo "  ✅ Batch 2: Candidate Detail COMPLETE!"
echo "═══════════════════════════════════════════════════"
echo ""
echo "New on Candidate Detail page:"
echo ""
echo "  DUAL SCORING:"
echo "    • 'Score Personal' button (purple) — Round 1, /24"
echo "    • 'Score Technical' button (orange) — Round 2, /24"
echo "    • Header shows: Personal /24 + Technical /24 = Total /48"
echo "    • Two separate score breakdown cards"
echo "    • Recommended Location field in score modals"
echo "    • Buttons only appear when appropriate round is pending"
echo ""
echo "  DOCUMENTS TAB:"
echo "    • New 'Documents' tab next to Timeline"
echo "    • Shows all doc types with status (verified/pending/rejected)"
echo "    • Upload button per document (HR can upload on behalf)"
echo "    • Progress bar: X/Y mandatory docs verified"
echo "    • 'Copy Upload Link' button to share with candidate"
echo ""
echo "  DEPLOY BUTTON:"
echo "    • Green 'Deploy' button (only when eligible)"
echo "    • Pre-deployment checklist: docs verified + training done"
echo "    • Auto-increments location.deployed counter"
echo ""
echo "  OTHER:"
echo "    • 'Doc Link' button copies hire.inovit.in/documents/{token}"
echo "    • 'Offer PDF' button downloads offer letter"
echo "    • Edit form has: fatherName, externalCode, preferredCity"
echo "    • All times in IST"
echo "    • Interview scheduling with IST conversion"
echo ""
pm2 status
