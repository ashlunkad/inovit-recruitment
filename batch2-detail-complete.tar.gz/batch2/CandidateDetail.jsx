import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { candidateAPI, locationAPI, authAPI, documentAPI } from '../services/api';
import api from '../services/api';
import toast from 'react-hot-toast';
import { ArrowLeft, Phone, Mail, MapPin, Star, Send, FileText, Edit2, X, Save, UserCheck, Calendar, Briefcase, ChevronDown, Upload, CheckCircle, XCircle, Clock, Link2, Rocket, Copy } from 'lucide-react';

const SCORE_LABELS = {1:'Poor',2:'Average',3:'Good',4:'Excellent'};
const SCORE_COLORS = {1:'bg-red-100 text-red-700 border-red-300',2:'bg-yellow-100 text-yellow-700 border-yellow-300',3:'bg-blue-100 text-blue-700 border-blue-300',4:'bg-green-100 text-green-700 border-green-300'};
const ALL_STATUSES = ['New','Walk_In_Registered','Contacted','WhatsApp_Failed','Interested','Not_Interested','Screening','Screened','Portal_Applied','Interview_Scheduled','Interview_Pending_Technical','Interview_Done','Selected','Rejected','On_Hold','Waitlisted','Offered','Offer_Accepted','Offer_Declined','Onboarding','Training','Training_Completed','Training_Failed','Deployed','Unreachable','Blacklisted','Archived'];
const QUALIFICATIONS = [{v:'ITI_Electrical',l:'ITI - Electrical'},{v:'ITI_Other',l:'ITI - Other'},{v:'Diploma_Electrical',l:'Diploma - Electrical'},{v:'Diploma_Other',l:'Diploma - Other'},{v:'BTech_Electrical',l:'B.Tech - Electrical'},{v:'BTech_Other',l:'B.Tech - Other'},{v:'BSc',l:'B.Sc'},{v:'HSC',l:'12th / HSC'},{v:'10th',l:'10th'},{v:'Other',l:'Other'}];
const DOC_LABELS = {aadhaar_front:'Aadhaar Front',aadhaar_back:'Aadhaar Back',pan:'PAN Card',qualification:'Qualification Cert',photo:'Passport Photo',cv_resume:'CV/Resume',experience_letter:'Experience Letter',bank_passbook:'Bank Passbook',driving_license:'Driving License',police_clearance:'Police Clearance'};
const fmtIST = (d,opts={dateStyle:'short',timeStyle:'short'}) => d ? new Date(d).toLocaleString('en-IN',{...opts,timeZone:'Asia/Kolkata'}) : '-';
const fmtDateIST = (d) => d ? new Date(d).toLocaleDateString('en-IN',{day:'numeric',month:'short',year:'numeric',timeZone:'Asia/Kolkata'}) : '-';

const eventIcons = {whatsapp_out:'📤',whatsapp_in:'📩',call_outbound:'📞',call_inbound:'📲',sms_sent:'📱',internal_note:'📝',status_change:'🔄',document_event:'📄',score_update:'🎯',panel_decision:'✅',system_event:'⚙️'};
const eventColors = {whatsapp_out:'border-green-300 bg-green-50',whatsapp_in:'border-green-400 bg-green-50',call_outbound:'border-blue-300 bg-blue-50',call_inbound:'border-blue-400 bg-blue-50',status_change:'border-yellow-300 bg-yellow-50',panel_decision:'border-emerald-300 bg-emerald-50',internal_note:'border-purple-300 bg-purple-50',system_event:'border-gray-300 bg-gray-50',score_update:'border-orange-300 bg-orange-50',document_event:'border-indigo-300 bg-indigo-50'};

export default function CandidateDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [c, setC] = useState(null);
  const [timeline, setTimeline] = useState([]);
  const [loading, setLoading] = useState(true);
  const [note, setNote] = useState('');
  const [tlFilter, setTlFilter] = useState('all');
  const [tab, setTab] = useState('timeline'); // timeline, documents
  const [locations, setLocations] = useState([]);
  const [users, setUsers] = useState([]);
  const [docs, setDocs] = useState([]);
  const [docStats, setDocStats] = useState({});
  // Modals
  const [modal, setModal] = useState(null); // edit,status,assign,interview,scorePersonal,scoreTechnical,offer,salary,deploy
  const [form, setForm] = useState({});

  const reload = () => {
    candidateAPI.getOne(id).then(res => { setC(res.data.candidate); setTimeline(res.data.timeline||[]); }).catch(() => toast.error('Not found')).finally(() => setLoading(false));
    documentAPI.getCandidateDocs(id).then(res => { setDocs(res.data.docs||[]); setDocStats(res.data.stats||{}); }).catch(() => {});
  };
  useEffect(() => {
    reload();
    locationAPI.getAll().then(r => setLocations(r.data.locations||[])).catch(() => {});
    authAPI.getUsers().then(r => setUsers(r.data.users||[])).catch(() => {});
  }, [id]);

  const addNote = async () => { if (!note.trim()) return; try { await candidateAPI.addNote(id,{content:note}); toast.success('Note added'); setNote(''); reload(); } catch { toast.error('Failed'); } };

  // ── Actions ──
  const saveEdit = async () => { try { await candidateAPI.update(id,{fullName:form.fullName,phone:form.phone,alternatePhone:form.alternatePhone,email:form.email,qualification:form.qualification,experienceYears:Number(form.experienceYears),electricalTrade:form.electricalTrade,currentLocation:{city:form.currentCity,state:form.currentState},preferredLocation:form.preferredLocation||undefined,preferredCity:form.preferredCity,gender:form.gender,fatherName:form.fatherName,externalCode:form.externalCode}); toast.success('Updated'); setModal(null); reload(); } catch(e) { toast.error(e.response?.data?.error||'Failed'); } };
  const saveStatus = async () => { if (form.status===c.status) { setModal(null); return; } try { await candidateAPI.update(id,{status:form.status,statusChangeReason:form.reason}); toast.success('Status changed'); setModal(null); reload(); } catch(e) { toast.error(e.response?.data?.error||'Failed'); } };
  const saveAssign = async () => { try { await candidateAPI.update(id,{assignedAgent:form.agent||undefined,assignedTeam:form.team||undefined}); toast.success('Assigned'); setModal(null); reload(); } catch { toast.error('Failed'); } };
  const saveInterview = async () => { try { const dt = form.date ? new Date(new Date(form.date).getTime()-(5.5*60*60*1000)).toISOString() : undefined; await candidateAPI.update(id,{interviewScheduled:dt,interviewType:form.type,interviewer:form.interviewer||undefined,interviewLink:form.link,status:'Interview_Scheduled',statusChangeReason:'Interview scheduled'}); toast.success('Scheduled'); setModal(null); reload(); } catch { toast.error('Failed'); } };
  const saveScorePersonal = async () => { try { await candidateAPI.scorePersonalInterview(id,form); toast.success('Personal interview scored'); setModal(null); reload(); } catch(e) { toast.error(e.response?.data?.error||'Failed'); } };
  const saveScoreTechnical = async () => { try { await candidateAPI.scoreTechnicalInterview(id,form); toast.success('Technical interview scored'); setModal(null); reload(); } catch(e) { toast.error(e.response?.data?.error||'Failed'); } };
  const saveOffer = async () => { try { await candidateAPI.update(id,{offerSalary:Number(form.salary),offerLocation:form.location,offerJoiningDate:form.joiningDate,offerSentAt:new Date().toISOString(),status:'Offered',statusChangeReason:'Offer sent'}); toast.success('Offer created'); setModal(null); reload(); } catch { toast.error('Failed'); } };
  const saveSalary = async () => { try { await candidateAPI.update(id,{counterOfferSalary:Number(form.counterOffer)||undefined,finalSalary:Number(form.finalSalary)}); toast.success('Salary updated'); setModal(null); reload(); } catch { toast.error('Failed'); } };
  const acceptOffer = async () => { try { await candidateAPI.update(id,{status:'Offer_Accepted',offerAcceptedAt:new Date().toISOString(),statusChangeReason:'Offer accepted'}); toast.success('Accepted!'); reload(); } catch { toast.error('Failed'); } };
  const declineOffer = async () => { const r=prompt('Decline reason:'); if(!r) return; try { await candidateAPI.update(id,{status:'Offer_Declined',offerDeclinedAt:new Date().toISOString(),offerDeclineReason:r,statusChangeReason:'Declined: '+r}); toast.success('Declined'); reload(); } catch { toast.error('Failed'); } };
  const toggleBlacklist = async () => { const r=c.blacklisted?null:prompt('Blacklist reason:'); if(!c.blacklisted&&!r)return; try { await candidateAPI.update(id,{blacklisted:!c.blacklisted,blacklistReason:r||'',status:c.blacklisted?c.status:'Blacklisted',statusChangeReason:c.blacklisted?'Unblacklisted':'Blacklisted: '+r}); toast.success(c.blacklisted?'Unblacklisted':'Blacklisted'); reload(); } catch { toast.error('Failed'); } };
  const deployCandidate = async () => { try { await candidateAPI.update(id,{status:'Deployed',deployedAt:new Date().toISOString(),deploymentLocation:c.offerLocation?._id||c.preferredLocation?._id,statusChangeReason:'Deployed to location'}); toast.success('Deployed!'); setModal(null); reload(); } catch(e) { toast.error(e.response?.data?.error||'Failed'); } };
  const downloadOfferPDF = async () => { try { const res = await candidateAPI.getOfferPDF(id); const url = URL.createObjectURL(res.data); const a = document.createElement('a'); a.href=url; a.download=`Offer_${c.candidateId}.pdf`; a.click(); } catch { toast.error('PDF generation failed'); } };
  const uploadDoc = async (docType, file) => { if(!file) return; const fd=new FormData(); fd.append('file',file); fd.append('docType',docType); try { await documentAPI.uploadDoc(id,fd); toast.success('Uploaded'); reload(); } catch(e) { toast.error(e.response?.data?.error||'Upload failed'); } };
  const copyDocLink = () => { const link=`${window.location.origin}/documents/${c.statusToken}`; navigator.clipboard?.writeText(link); toast.success('Document upload link copied!'); };

  const filteredTL = tlFilter==='all'?timeline:timeline.filter(e=>{if(tlFilter==='whatsapp')return e.eventType?.includes('whatsapp');if(tlFilter==='calls')return e.eventType?.includes('call');if(tlFilter==='notes')return e.eventType==='internal_note';return['status_change','system_event','panel_decision','score_update','document_event'].includes(e.eventType);});

  if (loading) return <div className="flex items-center justify-center h-64"><div className="animate-spin rounded-full h-10 w-10 border-b-2 border-primary-600"></div></div>;
  if (!c) return <div className="text-center py-10 text-gray-500">Not found</div>;

  const totalScore = (c.personalInterviewScore||0)+(c.technicalInterviewScore||0);
  const hasPersonal = c.personalInterviewScore > 0;
  const hasTechnical = c.technicalInterviewScore > 0;
  const scoreColor = (s,max) => { const pct=s/max*100; return pct>=75?'text-green-600 bg-green-50':pct>=50?'text-blue-600 bg-blue-50':pct>=25?'text-yellow-600 bg-yellow-50':'text-red-500 bg-red-50'; };
  const statusColor = (s) => { if(['Deployed','Training_Completed'].includes(s))return'bg-green-100 text-green-700';if(['Selected','Offered','Offer_Accepted'].includes(s))return'bg-blue-100 text-blue-700';if(['Rejected','Blacklisted'].includes(s))return'bg-red-100 text-red-700';if(['On_Hold','Waitlisted','Interview_Pending_Technical'].includes(s))return'bg-amber-100 text-amber-700';return'bg-gray-100 text-gray-700'; };
  const agents = users.filter(u=>['agent','team_lead','telecaller'].includes(u.role));
  const interviewers = users.filter(u=>['interviewer','super_admin','team_lead'].includes(u.role));
  const mandatoryDocsVerified = docs.filter(d=>d.required&&d.status==='verified').length;
  const mandatoryDocsTotal = docs.filter(d=>d.required).length;
  const allDocsVerified = mandatoryDocsVerified >= mandatoryDocsTotal && mandatoryDocsTotal > 0;
  const canDeploy = allDocsVerified && ['Training_Completed','Offer_Accepted','Selected'].includes(c.status);

  return (
    <div className="space-y-4">
      <button onClick={()=>navigate(-1)} className="flex items-center gap-1 text-sm text-gray-500 hover:text-gray-700"><ArrowLeft size={16}/> Back</button>

      {/* Header */}
      <div className="card flex flex-col md:flex-row md:items-center gap-4">
        <div className="w-14 h-14 rounded-full bg-primary-100 flex items-center justify-center text-primary-700 font-bold text-xl">{c.fullName?.split(' ').map(n=>n[0]).join('').slice(0,2)}</div>
        <div className="flex-1">
          <div className="flex items-center gap-2 flex-wrap">
            <h1 className="text-xl font-bold text-gray-900">{c.fullName}</h1>
            <span className={'text-xs px-2 py-0.5 rounded-full font-medium '+statusColor(c.status)}>{c.status?.replace(/_/g,' ')}</span>
            {c.blacklisted&&<span className="text-xs px-2 py-0.5 rounded-full font-medium bg-red-600 text-white">BLACKLISTED</span>}
          </div>
          <div className="flex flex-wrap gap-3 mt-1 text-sm text-gray-500">
            <span className="flex items-center gap-1"><Phone size={13}/> {c.phone}</span>
            {c.email&&<span className="flex items-center gap-1"><Mail size={13}/> {c.email}</span>}
            <span className="flex items-center gap-1"><MapPin size={13}/> {c.currentLocation?.city||c.preferredCity||'N/A'}</span>
            <span className="flex items-center gap-1"><FileText size={13}/> {c.candidateId}</span>
            {c.externalCode&&<span className="text-xs bg-gray-100 px-2 py-0.5 rounded">Ext: {c.externalCode}</span>}
          </div>
        </div>
        <div className="flex gap-2">
          {hasPersonal&&<div className={'text-center px-3 py-2 rounded-lg '+scoreColor(c.personalInterviewScore,24)}><div className="text-lg font-bold">{c.personalInterviewScore}/24</div><div className="text-xs">Personal</div></div>}
          {hasTechnical&&<div className={'text-center px-3 py-2 rounded-lg '+scoreColor(c.technicalInterviewScore,24)}><div className="text-lg font-bold">{c.technicalInterviewScore}/24</div><div className="text-xs">Technical</div></div>}
          {(hasPersonal||hasTechnical)&&<div className={'text-center px-3 py-2 rounded-lg '+scoreColor(totalScore,48)}><div className="text-lg font-bold">{totalScore}/48</div><div className="text-xs">Total</div></div>}
        </div>
      </div>

      {/* Actions */}
      <div className="flex flex-wrap gap-2">
        <button onClick={()=>{setForm({fullName:c.fullName||'',phone:c.phone||'',alternatePhone:c.alternatePhone||'',email:c.email||'',qualification:c.qualification||'',experienceYears:c.experienceYears||0,electricalTrade:c.electricalTrade||false,currentCity:c.currentLocation?.city||'',currentState:c.currentLocation?.state||'',preferredLocation:c.preferredLocation?._id||'',preferredCity:c.preferredCity||'',gender:c.gender||'',fatherName:c.fatherName||'',externalCode:c.externalCode||''});setModal('edit');}} className="btn-outline text-xs flex items-center gap-1"><Edit2 size={13}/> Edit</button>
        <button onClick={()=>{setForm({status:c.status,reason:''});setModal('status');}} className="btn-outline text-xs flex items-center gap-1"><ChevronDown size={13}/> Status</button>
        <button onClick={()=>{setForm({agent:c.assignedAgent?._id||'',team:c.assignedTeam||''});setModal('assign');}} className="btn-outline text-xs flex items-center gap-1"><UserCheck size={13}/> Assign</button>
        <button onClick={()=>{setForm({date:c.interviewScheduled?c.interviewScheduled.slice(0,16):'',type:c.interviewType||'virtual',interviewer:c.interviewer?._id||'',link:c.interviewLink||''});setModal('interview');}} className="btn-outline text-xs flex items-center gap-1"><Calendar size={13}/> Interview</button>
        {['Interview_Scheduled','Interview_Done','Interview_Pending_Technical'].includes(c.status)&&!hasPersonal&&<button onClick={()=>{const b=c.personalInterviewBreakdown||{};setForm({technical:b.technical||0,practical:b.practical||0,communication:b.communication||0,experience:b.experience||0,locationAvailability:b.locationAvailability||0,teamLeading:b.teamLeading||0,notes:c.personalInterviewNotes||'',recommendedLocation:c.recommendedLocation||''});setModal('scorePersonal');}} className="bg-purple-600 hover:bg-purple-700 text-white text-xs px-3 py-1.5 rounded-lg flex items-center gap-1"><Star size={13}/> Score Personal</button>}
        {hasPersonal&&!hasTechnical&&<button onClick={()=>{const b=c.technicalInterviewBreakdown||{};setForm({technical:b.technical||0,practical:b.practical||0,communication:b.communication||0,experience:b.experience||0,locationAvailability:b.locationAvailability||0,teamLeading:b.teamLeading||0,notes:c.technicalInterviewNotes||'',recommendedLocation:c.recommendedLocation||''});setModal('scoreTechnical');}} className="bg-orange-600 hover:bg-orange-700 text-white text-xs px-3 py-1.5 rounded-lg flex items-center gap-1"><Star size={13}/> Score Technical</button>}
        {c.panelDecision==='Selected'&&!['Offered','Offer_Accepted'].includes(c.status)&&<button onClick={()=>{setForm({salary:c.offerSalary||18000,location:c.offerLocation?._id||c.preferredLocation?._id||'',joiningDate:c.offerJoiningDate?c.offerJoiningDate.slice(0,10):''});setModal('offer');}} className="btn-primary text-xs flex items-center gap-1"><Briefcase size={13}/> Create Offer</button>}
        {c.status==='Offered'&&<><button onClick={acceptOffer} className="bg-green-600 hover:bg-green-700 text-white text-xs px-3 py-1.5 rounded-lg">Accept</button><button onClick={declineOffer} className="bg-red-500 hover:bg-red-600 text-white text-xs px-3 py-1.5 rounded-lg">Decline</button></>}
        {c.offerSalary&&<button onClick={()=>{setForm({counterOffer:c.counterOfferSalary||0,finalSalary:c.finalSalary||c.offerSalary||0});setModal('salary');}} className="btn-outline text-xs">₹ Salary</button>}
        {c.offerSalary&&<button onClick={downloadOfferPDF} className="btn-outline text-xs flex items-center gap-1"><FileText size={13}/> Offer PDF</button>}
        {canDeploy&&<button onClick={()=>setModal('deploy')} className="bg-green-700 hover:bg-green-800 text-white text-xs px-3 py-1.5 rounded-lg flex items-center gap-1"><Rocket size={13}/> Deploy</button>}
        {c.statusToken&&<button onClick={copyDocLink} className="btn-outline text-xs flex items-center gap-1"><Link2 size={13}/> Doc Link</button>}
        <button onClick={toggleBlacklist} className={'text-xs px-3 py-1.5 rounded-lg '+(c.blacklisted?'bg-gray-200 text-gray-700':'bg-red-50 text-red-600')}>{c.blacklisted?'Unblacklist':'Blacklist'}</button>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 bg-gray-100 p-1 rounded-lg w-fit">
        {['timeline','documents'].map(t=><button key={t} onClick={()=>setTab(t)} className={'px-4 py-1.5 text-sm rounded-md transition '+(tab===t?'bg-white text-primary-700 font-medium shadow-sm':'text-gray-500')}>{t==='timeline'?'Timeline':'Documents ('+mandatoryDocsVerified+'/'+mandatoryDocsTotal+')'}</button>)}
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Left Panel */}
        <div className="lg:col-span-1 space-y-4">
          <div className="card"><h3 className="font-semibold text-gray-800 mb-3">Details</h3>
            <dl className="space-y-1.5 text-sm">
              {[['Status',c.status?.replace(/_/g,' ')],['Qualification',c.qualification?.replace(/_/g,' ')],['Experience',(c.experienceYears||0)+' years'],['Source',c.source+(c.sourceDetail?' — '+c.sourceDetail:'')],['Current City',c.currentLocation?.city],['Preferred',c.preferredCity||c.preferredLocation?.name],['Recommended',c.recommendedLocation],['Panel',c.panelDecision],['Assigned',c.assignedAgent?.name||'Unassigned'],['Team',c.assignedTeam],['Father',c.fatherName],['External ID',c.externalCode]].filter(([,v])=>v).map(([l,v])=>(<div key={l} className="flex justify-between"><dt className="text-gray-500">{l}</dt><dd className="font-medium text-gray-800 text-right max-w-[60%] truncate">{v}</dd></div>))}
            </dl>
          </div>

          {c.offerSalary&&<div className="card border-blue-200 bg-blue-50"><h3 className="font-semibold text-blue-800 mb-2">Offer & Salary</h3>
            <dl className="space-y-1 text-sm">
              <div className="flex justify-between"><dt className="text-blue-600">Offered</dt><dd className="font-bold text-blue-900">₹{c.offerSalary?.toLocaleString('en-IN')}/mo</dd></div>
              {c.counterOfferSalary>0&&<div className="flex justify-between"><dt className="text-orange-600">Counter</dt><dd className="font-bold text-orange-700">₹{c.counterOfferSalary?.toLocaleString('en-IN')}/mo</dd></div>}
              {c.finalSalary>0&&<div className="flex justify-between"><dt className="text-green-600">Final</dt><dd className="font-bold text-green-700">₹{c.finalSalary?.toLocaleString('en-IN')}/mo</dd></div>}
              {c.offerJoiningDate&&<div className="flex justify-between"><dt className="text-blue-600">Joining</dt><dd>{fmtDateIST(c.offerJoiningDate)}</dd></div>}
              {c.offerAcceptedAt&&<div className="flex justify-between"><dt className="text-green-600">Accepted</dt><dd className="text-green-700 font-bold">{fmtDateIST(c.offerAcceptedAt)}</dd></div>}
              {c.offerDeclinedAt&&<div className="flex justify-between"><dt className="text-red-600">Declined</dt><dd className="text-red-700">{c.offerDeclineReason}</dd></div>}
            </dl></div>}

          {c.interviewScheduled&&<div className="card border-purple-200 bg-purple-50"><h3 className="font-semibold text-purple-800 mb-2">Interview</h3>
            <dl className="space-y-1 text-sm">
              <div className="flex justify-between"><dt className="text-purple-600">Date</dt><dd className="font-bold">{fmtIST(c.interviewScheduled,{dateStyle:'medium',timeStyle:'short'})}</dd></div>
              <div className="flex justify-between"><dt className="text-purple-600">Type</dt><dd>{c.interviewType||'-'}</dd></div>
              <div className="flex justify-between"><dt className="text-purple-600">Interviewer</dt><dd>{c.interviewer?.name||'-'}</dd></div>
            </dl></div>}

          {/* Score Breakdowns */}
          {hasPersonal&&<div className="card"><h3 className="font-semibold text-gray-800 mb-2">Personal Interview ({c.personalInterviewScore}/24)</h3>
            <div className="space-y-1.5">{[['Technical',c.personalInterviewBreakdown?.technical],['Practical',c.personalInterviewBreakdown?.practical],['Communication',c.personalInterviewBreakdown?.communication],['Experience',c.personalInterviewBreakdown?.experience],['Location',c.personalInterviewBreakdown?.locationAvailability],['Team Leading',c.personalInterviewBreakdown?.teamLeading]].map(([l,v])=>(<div key={l} className="flex items-center justify-between text-sm"><span className="text-gray-600">{l}</span><span className={'text-xs px-2 py-0.5 rounded-full font-medium border '+(SCORE_COLORS[v]||'bg-gray-100 text-gray-500 border-gray-200')}>{SCORE_LABELS[v]||'-'}</span></div>))}
            </div>
            {c.personalInterviewNotes&&<p className="mt-2 pt-2 border-t text-xs text-gray-600">{c.personalInterviewNotes}</p>}
            {c.personalInterviewBy&&<p className="text-xs text-gray-400 mt-1">By: {c.personalInterviewBy.name||'—'}</p>}
          </div>}

          {hasTechnical&&<div className="card"><h3 className="font-semibold text-gray-800 mb-2">Technical Interview ({c.technicalInterviewScore}/24)</h3>
            <div className="space-y-1.5">{[['Technical',c.technicalInterviewBreakdown?.technical],['Practical',c.technicalInterviewBreakdown?.practical],['Communication',c.technicalInterviewBreakdown?.communication],['Experience',c.technicalInterviewBreakdown?.experience],['Location',c.technicalInterviewBreakdown?.locationAvailability],['Team Leading',c.technicalInterviewBreakdown?.teamLeading]].map(([l,v])=>(<div key={l} className="flex items-center justify-between text-sm"><span className="text-gray-600">{l}</span><span className={'text-xs px-2 py-0.5 rounded-full font-medium border '+(SCORE_COLORS[v]||'bg-gray-100 text-gray-500 border-gray-200')}>{SCORE_LABELS[v]||'-'}</span></div>))}
            </div>
            {c.technicalInterviewNotes&&<p className="mt-2 pt-2 border-t text-xs text-gray-600">{c.technicalInterviewNotes}</p>}
          </div>}
        </div>

        {/* Right Panel */}
        <div className="lg:col-span-2">
          {/* Timeline Tab */}
          {tab==='timeline'&&<div className="card">
            <div className="flex items-center justify-between mb-4"><h3 className="font-semibold text-gray-800">Timeline</h3>
              <div className="flex gap-1">{['all','whatsapp','calls','notes','system'].map(f=><button key={f} onClick={()=>setTlFilter(f)} className={'text-xs px-2 py-1 rounded-full '+(tlFilter===f?'bg-primary-100 text-primary-700 font-medium':'text-gray-500 hover:bg-gray-100')}>{f==='all'?'All':f.charAt(0).toUpperCase()+f.slice(1)}</button>)}</div>
            </div>
            <div className="flex gap-2 mb-4"><input value={note} onChange={e=>setNote(e.target.value)} placeholder="Add a note..." className="input-field flex-1" onKeyDown={e=>e.key==='Enter'&&addNote()}/><button onClick={addNote} className="btn-primary flex items-center gap-1"><Send size={14}/> Add</button></div>
            <div className="space-y-2 max-h-[600px] overflow-y-auto">
              {filteredTL.length===0?<div className="text-center text-gray-400 py-8">No events</div>:filteredTL.map((ev,i)=>(
                <div key={ev._id||i} className={'border-l-4 rounded-r-lg p-3 '+(eventColors[ev.eventType]||'border-gray-300 bg-gray-50')}>
                  <div className="flex items-start justify-between"><div className="flex items-start gap-2"><span>{eventIcons[ev.eventType]||'📌'}</span><div><div className="text-sm text-gray-800">{ev.content||ev.eventType?.replace(/_/g,' ')}</div>{ev.oldStatus&&<div className="text-xs text-gray-500">{ev.oldStatus} → {ev.newStatus}</div>}</div></div>
                  <div className="text-xs text-gray-400 ml-2">{fmtIST(ev.createdAt)}</div></div>
                  <div className="text-xs text-gray-400 mt-1 ml-7">by {ev.createdByName||ev.createdBy?.name||'System'}</div>
                </div>
              ))}
            </div>
          </div>}

          {/* Documents Tab */}
          {tab==='documents'&&<div className="card">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold text-gray-800">Documents ({mandatoryDocsVerified}/{mandatoryDocsTotal} verified)</h3>
              {c.statusToken&&<button onClick={copyDocLink} className="btn-outline text-xs flex items-center gap-1"><Copy size={13}/> Copy Upload Link</button>}
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2 mb-4"><div className="bg-green-500 h-2 rounded-full" style={{width:(mandatoryDocsVerified/Math.max(mandatoryDocsTotal,1)*100)+'%'}}></div></div>
            <div className="space-y-3">
              {docs.map(doc=>(
                <div key={doc.key} className={'border rounded-lg p-3 '+(doc.status==='verified'?'border-green-200 bg-green-50':doc.status==='rejected'?'border-red-200 bg-red-50':doc.status==='pending'?'border-yellow-200 bg-yellow-50':'border-gray-200')}>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      {doc.status==='verified'?<CheckCircle size={16} className="text-green-500"/>:doc.status==='rejected'?<XCircle size={16} className="text-red-500"/>:doc.status==='pending'?<Clock size={16} className="text-yellow-500"/>:<FileText size={16} className="text-gray-300"/>}
                      <div><div className="text-sm font-medium text-gray-800">{DOC_LABELS[doc.key]||doc.key}{doc.required&&<span className="text-red-500 ml-1">*</span>}</div>
                        {doc.uploadedAt&&<div className="text-xs text-gray-400">Uploaded: {fmtIST(doc.uploadedAt)}</div>}
                        {doc.rejectionReason&&<div className="text-xs text-red-600">Reason: {doc.rejectionReason}</div>}
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      {doc.url&&<a href={doc.url} target="_blank" className="text-xs text-blue-600 hover:underline">View</a>}
                      {(doc.status==='not_uploaded'||doc.status==='rejected')&&(
                        <label className="bg-primary-50 text-primary-700 text-xs px-2 py-1 rounded cursor-pointer hover:bg-primary-100 flex items-center gap-1">
                          <Upload size={12}/> Upload
                          <input type="file" accept=".jpg,.jpeg,.png,.pdf,.webp" className="hidden" onChange={e=>uploadDoc(doc.key,e.target.files[0])}/>
                        </label>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>}
        </div>
      </div>

      {/* ═══ MODALS ═══ */}
      {modal==='edit'&&<Modal t="Edit Details" onClose={()=>setModal(null)} onSave={saveEdit}><div className="grid grid-cols-2 gap-3">
        <F l="Full Name *" v={form.fullName} s={v=>setForm(f=>({...f,fullName:v}))}/><F l="Phone *" v={form.phone} s={v=>setForm(f=>({...f,phone:v}))}/>
        <F l="Alt Phone" v={form.alternatePhone} s={v=>setForm(f=>({...f,alternatePhone:v}))}/><F l="Email" v={form.email} s={v=>setForm(f=>({...f,email:v}))} type="email"/>
        <F l="Father Name" v={form.fatherName} s={v=>setForm(f=>({...f,fatherName:v}))}/><F l="External ID" v={form.externalCode} s={v=>setForm(f=>({...f,externalCode:v}))}/>
        <div><label className="block text-sm font-medium text-gray-700 mb-1">Qualification</label><select value={form.qualification} onChange={e=>setForm(f=>({...f,qualification:e.target.value}))} className="input-field"><option value="">Select</option>{QUALIFICATIONS.map(q=><option key={q.v} value={q.v}>{q.l}</option>)}</select></div>
        <F l="Experience" v={form.experienceYears} s={v=>setForm(f=>({...f,experienceYears:v}))} type="number"/>
        <F l="Current City" v={form.currentCity} s={v=>setForm(f=>({...f,currentCity:v}))}/><F l="Current State" v={form.currentState} s={v=>setForm(f=>({...f,currentState:v}))}/>
        <F l="Preferred City" v={form.preferredCity} s={v=>setForm(f=>({...f,preferredCity:v}))}/>
        <div><label className="block text-sm font-medium text-gray-700 mb-1">Preferred Location</label><select value={form.preferredLocation} onChange={e=>setForm(f=>({...f,preferredLocation:e.target.value}))} className="input-field"><option value="">-</option>{locations.map(l=><option key={l._id} value={l._id}>{l.name}</option>)}</select></div>
        <div><label className="block text-sm font-medium text-gray-700 mb-1">Gender</label><select value={form.gender} onChange={e=>setForm(f=>({...f,gender:e.target.value}))} className="input-field"><option value="">-</option><option value="Male">Male</option><option value="Female">Female</option><option value="Other">Other</option></select></div>
      </div></Modal>}

      {modal==='status'&&<Modal t="Change Status" onClose={()=>setModal(null)} onSave={saveStatus}><div className="space-y-3">
        <div><label className="block text-sm font-medium text-gray-700 mb-1">Current: <b>{c.status?.replace(/_/g,' ')}</b></label><select value={form.status} onChange={e=>setForm(f=>({...f,status:e.target.value}))} className="input-field">{ALL_STATUSES.map(s=><option key={s} value={s}>{s.replace(/_/g,' ')}</option>)}</select></div>
        <F l="Reason" v={form.reason} s={v=>setForm(f=>({...f,reason:v}))}/>
      </div></Modal>}

      {modal==='assign'&&<Modal t="Assign Agent" onClose={()=>setModal(null)} onSave={saveAssign}><div className="space-y-3">
        <div><label className="block text-sm font-medium text-gray-700 mb-1">Agent</label><select value={form.agent} onChange={e=>setForm(f=>({...f,agent:e.target.value}))} className="input-field"><option value="">Unassigned</option>{agents.map(a=><option key={a._id} value={a._id}>{a.name} ({a.role})</option>)}</select></div>
        <div><label className="block text-sm font-medium text-gray-700 mb-1">Team</label><select value={form.team} onChange={e=>setForm(f=>({...f,team:e.target.value}))} className="input-field"><option value="">-</option>{['Alpha','Beta','Gamma','Delta'].map(t=><option key={t} value={t}>{t}</option>)}</select></div>
      </div></Modal>}

      {modal==='interview'&&<Modal t="Schedule Interview" onClose={()=>setModal(null)} onSave={saveInterview}><div className="space-y-3">
        <F l="Date & Time *" v={form.date} s={v=>setForm(f=>({...f,date:v}))} type="datetime-local"/>
        <div><label className="block text-sm font-medium text-gray-700 mb-1">Type</label><select value={form.type} onChange={e=>setForm(f=>({...f,type:e.target.value}))} className="input-field"><option value="virtual">Virtual</option><option value="physical">Physical</option></select></div>
        <div><label className="block text-sm font-medium text-gray-700 mb-1">Interviewer</label><select value={form.interviewer} onChange={e=>setForm(f=>({...f,interviewer:e.target.value}))} className="input-field"><option value="">Select</option>{interviewers.map(u=><option key={u._id} value={u._id}>{u.name}</option>)}</select></div>
        <F l="Meeting Link" v={form.link} s={v=>setForm(f=>({...f,link:v}))} placeholder="https://meet.google.com/..."/>
      </div></Modal>}

      {modal==='offer'&&<Modal t="Create Offer" onClose={()=>setModal(null)} onSave={saveOffer}><div className="space-y-3">
        <F l="Salary (₹/month) *" v={form.salary} s={v=>setForm(f=>({...f,salary:v}))} type="number"/>
        <div><label className="block text-sm font-medium text-gray-700 mb-1">Location</label><select value={form.location} onChange={e=>setForm(f=>({...f,location:e.target.value}))} className="input-field"><option value="">Select</option>{locations.map(l=><option key={l._id} value={l._id}>{l.name} ({l.city})</option>)}</select></div>
        <F l="Joining Date" v={form.joiningDate} s={v=>setForm(f=>({...f,joiningDate:v}))} type="date"/>
      </div></Modal>}

      {modal==='salary'&&<Modal t="Salary Negotiation" onClose={()=>setModal(null)} onSave={saveSalary}><div className="space-y-3">
        <div className="bg-blue-50 rounded-lg p-3 text-sm"><span className="text-blue-600">Offered:</span> <b className="text-blue-900">₹{c.offerSalary?.toLocaleString('en-IN')}/mo</b></div>
        <F l="Counter Offer (₹/month)" v={form.counterOffer} s={v=>setForm(f=>({...f,counterOffer:v}))} type="number"/>
        <F l="Final Salary (₹/month) *" v={form.finalSalary} s={v=>setForm(f=>({...f,finalSalary:v}))} type="number"/>
      </div></Modal>}

      {(modal==='scorePersonal'||modal==='scoreTechnical')&&<Modal t={modal==='scorePersonal'?'Score Personal Interview':'Score Technical Interview'} onClose={()=>setModal(null)} onSave={modal==='scorePersonal'?saveScorePersonal:saveScoreTechnical} wide>
        <div className="space-y-4">
          <div className="bg-gray-50 rounded-lg p-3 text-sm grid grid-cols-2 gap-2">
            <div><span className="text-gray-500">Name:</span> <b>{c.fullName}</b></div>
            <div><span className="text-gray-500">Qualification:</span> <b>{c.qualification?.replace(/_/g,' ')}</b></div>
            <div><span className="text-gray-500">Experience:</span> <b>{c.experienceYears||0} years</b></div>
            <div><span className="text-gray-500">City:</span> <b>{c.currentLocation?.city||'-'}</b></div>
          </div>
          {[['technical','Technical Knowledge'],['practical','Practical Skills'],['communication','Communication & Attitude'],['experience','Relevant Experience'],['locationAvailability','Location Willingness'],['teamLeading','Team Leading']].map(([key,label])=>(
            <div key={key}><label className="block text-sm font-medium text-gray-700 mb-2">{label}</label>
              <div className="flex gap-2">{[{v:1,l:'Poor'},{v:2,l:'Average'},{v:3,l:'Good'},{v:4,l:'Excellent'}].map(opt=>(
                <button key={opt.v} type="button" onClick={()=>setForm(f=>({...f,[key]:opt.v}))}
                  className={'flex-1 py-2 px-2 rounded-lg border-2 text-sm font-medium transition '+(form[key]===opt.v?SCORE_COLORS[opt.v]+' border-current':'bg-gray-50 text-gray-400 border-gray-200 hover:bg-gray-100')}>{opt.l}</button>
              ))}</div>
            </div>
          ))}
          <div className="pt-3 border-t text-center"><span className="text-lg font-bold text-primary-700">Total: {Object.entries(form).filter(([k])=>!['notes','recommendedLocation'].includes(k)).reduce((s,[,v])=>s+Number(v),0)}/24</span></div>
          <F l="Recommended Location (if different from preferred)" v={form.recommendedLocation} s={v=>setForm(f=>({...f,recommendedLocation:v}))} placeholder="e.g., Jaipur instead of Delhi"/>
          <div><label className="block text-sm font-medium text-gray-700 mb-1">Notes</label><textarea value={form.notes} onChange={e=>setForm(f=>({...f,notes:e.target.value}))} className="input-field" rows={3} placeholder="Observations..."/></div>
        </div>
      </Modal>}

      {modal==='deploy'&&<Modal t="Deploy Candidate" onClose={()=>setModal(null)} onSave={deployCandidate}>
        <div className="space-y-3">
          <div className="text-sm font-medium text-gray-800 mb-2">Pre-deployment checklist:</div>
          <div className={'flex items-center gap-2 p-2 rounded '+(allDocsVerified?'bg-green-50':'bg-red-50')}>{allDocsVerified?<CheckCircle size={16} className="text-green-500"/>:<XCircle size={16} className="text-red-500"/>}<span className="text-sm">{allDocsVerified?'All mandatory documents verified':'Documents not complete ('+mandatoryDocsVerified+'/'+mandatoryDocsTotal+')'}</span></div>
          <div className={'flex items-center gap-2 p-2 rounded '+(c.status==='Training_Completed'?'bg-green-50':'bg-yellow-50')}>{c.status==='Training_Completed'?<CheckCircle size={16} className="text-green-500"/>:<Clock size={16} className="text-yellow-500"/>}<span className="text-sm">{c.status==='Training_Completed'?'Training completed':'Training: '+c.trainingStatus?.replace(/_/g,' ')}</span></div>
          <div className="flex items-center gap-2 p-2 rounded bg-blue-50"><MapPin size={16} className="text-blue-500"/><span className="text-sm">Location: {c.offerLocation?.name||c.preferredLocation?.name||c.recommendedLocation||'Not assigned'}</span></div>
          {!canDeploy&&<div className="bg-red-50 border border-red-200 rounded-lg p-3 text-sm text-red-700">Cannot deploy — complete all requirements above first.</div>}
        </div>
      </Modal>}
    </div>
  );
}

function Modal({t,children,onClose,onSave,wide}) { return(<div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4"><div className={'bg-white rounded-xl shadow-xl w-full max-h-[90vh] overflow-y-auto '+(wide?'max-w-lg':'max-w-md')}><div className="flex items-center justify-between p-5 border-b"><h3 className="text-lg font-bold text-gray-900">{t}</h3><button onClick={onClose} className="text-gray-400 hover:text-gray-600"><X size={20}/></button></div><div className="p-5">{children}</div><div className="flex gap-3 justify-end p-5 border-t"><button onClick={onClose} className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 text-sm">Cancel</button><button onClick={onSave} className="btn-primary py-2 text-sm"><Save size={14} className="inline mr-1"/>Save</button></div></div></div>); }
function F({l,v,s,type='text',placeholder}) { return(<div><label className="block text-sm font-medium text-gray-700 mb-1">{l}</label><input type={type} value={v} onChange={e=>s(e.target.value)} placeholder={placeholder} className="input-field"/></div>); }
